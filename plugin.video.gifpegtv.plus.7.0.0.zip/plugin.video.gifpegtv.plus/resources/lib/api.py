# -*- coding: utf-8 -*-

import xbmcgui
import xbmc
from doh_client import requests

class XtreamAPI:
    def __init__(self, server, username, password):
        self.base_url = f"{server}"
        self.username = username
        self.password = password
        self.session = requests.session
        self.session.headers.update({'User-Agent': 'Mozilla/5.0'})

    def _make_request(self, params):
        params['username'] = self.username
        params['password'] = self.password
        try:
            response = self.session.get(f"{self.base_url}/player_api.php", params=params, timeout=15)
            response.raise_for_status()
            if response.text.strip() == "[]":
                return []
            data = response.json()
            if isinstance(data, dict) and data.get('user_info', {}).get('auth') == 0:
                xbmcgui.Dialog().ok("Erro de Autenticação", "Usuário ou senha inválidos.")
                return None
            return data
        except requests.exceptions.RequestException as e:
            xbmc.log(f"[XtreamProxy] Erro de API: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Conexão", f"Não foi possível conectar ao servidor: {e}")
            return None
        except ValueError:
            xbmc.log(f"[XtreamProxy] Erro de API: Resposta não é JSON válido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Servidor", "O servidor retornou uma resposta inválida.")
            return None

    def get_live_categories(self):
        return self._make_request({'action': 'get_live_categories'})

    def get_live_streams(self, category_id=None):
        params = {'action': 'get_live_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_vod_categories(self):
        return self._make_request({'action': 'get_vod_categories'})

    def get_vod_streams(self, category_id=None):
        params = {'action': 'get_vod_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_categories(self):
        return self._make_request({'action': 'get_series_categories'})

    def get_series(self, category_id=None):
        params = {'action': 'get_series'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_info(self, series_id):
        return self._make_request({'action': 'get_series_info', 'series_id': series_id})

    def get_live_stream_url(self, stream_id):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.m3u8"

    def get_vod_stream_url(self, stream_id):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.mp4"

    def get_series_stream_url(self, stream_id):
        return f"{self.base_url}/series/{self.username}/{self.password}/{stream_id}.mp4"