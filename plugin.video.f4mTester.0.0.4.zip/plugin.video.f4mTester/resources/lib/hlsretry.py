# hlsretry.py
# -*- coding: utf-8 -*-
import os
import requests
import six
if six.PY3:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import urlparse, parse_qs, quote, unquote, unquote_plus, urljoin, quote_plus
    import queue # Python 3
else:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from urlparse import urlparse, parse_qs, urljoin
    from urllib import quote, unquote, unquote_plus
    import Queue as queue # Python 2
import threading
import time
import re
import logging

# Configuração de logging para depuração
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def log(msg):
    logger.info(msg)

# --- Configurações do Servidor Proxy ---
HOST_NAME = '127.0.0.1'
# Escolha uma porta que seja improvável de conflitar. 55894 é comum para proxies.
PORT_NUMBER = 55894 

# Definindo URLs do proxy
url_proxy_base = 'http://'+HOST_NAME+':'+str(PORT_NUMBER)
url_proxy = url_proxy_base + '/proxy_m3u8?url=' # Para playlists M3U8
url_segment_proxy_prefix = url_proxy_base + '/proxy_segment/' # Para segmentos TS
url_stop = url_proxy_base + '/stop'
url_reset = url_proxy_base + '/reset'
url_check = url_proxy_base + '/check' # Adicionado para verificar o status do servidor

# --- Variáveis Globais para o Estado do Proxy ---
URL_BASE = '' # Base da URL do conteúdo original (e.g., http://example.com/live/)
LAST_URL = '' # Última URL de playlist original que foi proxyficada
HEADERS_BASE = {} # Headers para usar nas requisições ao servidor de origem
STOP_SERVER = False # Flag para sinalizar o encerramento do servidor
CACHE_M3U8 = '' # Conteúdo da última playlist M3U8 proxyficada

# Variáveis relacionadas ao cache e pré-busca
SEGMENT_CACHE = {} # Dicionário para armazenar segmentos: {url: content}
SEGMENT_CACHE_LOCK = threading.Lock() # Lock para acesso thread-safe ao cache
PREFETCH_QUEUE = queue.Queue() # Fila para URLs de segmentos a serem pré-buscados
PREFETCH_WORKERS = 3 # Número de threads de pré-busca (ajustável)
PREFETCH_STOP_EVENT = threading.Event() # Evento para sinalizar o fim das threads de pré-busca

REQUESTS_SESSION = requests.Session() # Sessão persistente para requisições HTTP

# --- Thread de Pré-busca (Prefetch) ---
class PrefetchThread(threading.Thread):
    def __init__(self, queue, cache, lock, stop_event, headers):
        super(PrefetchThread, self).__init__()
        self.daemon = True # Garante que a thread termine com o programa principal
        self.queue = queue
        self.cache = cache
        self.lock = lock
        self.stop_event = stop_event
        self.headers = headers.copy() # Copia os headers para uso da thread
        log("Prefetch thread initialized.")

    def run(self):
        while not self.stop_event.is_set():
            try:
                # Obter URL da fila com timeout para poder verificar stop_event
                segment_url_to_prefetch = self.queue.get(timeout=1)
            except queue.Empty:
                if self.stop_event.is_set():
                    break # Sair se a fila estiver vazia e o evento de parada for definido
                time.sleep(0.1) # Pequena pausa para evitar CPU alta em fila vazia
                continue

            # Verificar se o segmento já está no cache antes de tentar buscar
            with self.lock:
                if segment_url_to_prefetch in self.cache:
                    log(f"Segment already in cache, skipping prefetch: {segment_url_to_prefetch}")
                    self.queue.task_done()
                    continue

            log(f"Prefetching segment: {segment_url_to_prefetch}")
            try:
                r = REQUESTS_SESSION.get(segment_url_to_prefetch, headers=self.headers, stream=True, timeout=10)
                r.raise_for_status() # Levanta um erro para códigos de status HTTP ruins
                content = r.content # Ler todo o conteúdo do segmento
                with self.lock:
                    self.cache[segment_url_to_prefetch] = content
                log(f"Prefetched and cached: {segment_url_to_prefetch} ({len(content)} bytes)")
            except requests.exceptions.RequestException as e:
                log(f"Error prefetching {segment_url_to_prefetch}: {e}")
            finally:
                self.queue.task_done() # Sinalizar que a tarefa foi concluída

# --- Handler das Requisições HTTP (ProxyHandler) ---
class ProxyHandler(BaseHTTPRequestHandler):

    def basename(self, p):
        i = p.rfind('/') + 1
        return p[i:]

    def fetch_m3u8(self, url, headers):
        """Busca o conteúdo da playlist M3U8."""
        log(f"Fetching M3U8: {url}")
        try:
            r = REQUESTS_SESSION.get(url, headers=headers, timeout=10)
            r.raise_for_status()
            log(f"Successfully fetched M3U8 from {url}. Status: {r.status_code}")
            return r.text, r.url # Retorna o conteúdo e a URL final (após redirecionamentos)
        except requests.exceptions.RequestException as e:
            log(f"Error fetching M3U8 from {url}: {e}")
            return None, None

    def fetch_chunk(self, url, headers):
        """Busca um segmento de vídeo, priorizando o cache."""
        with SEGMENT_CACHE_LOCK:
            if url in SEGMENT_CACHE:
                log(f"Serving segment from cache: {url}")
                # Criar um objeto de resposta simulado para compatibilidade com o retorno de requests
                class MockResponse:
                    def __init__(self, content):
                        self._content = content
                        self.headers = {'Content-Length': str(len(content)), 'Content-Type': 'video/mp2t'} # Assumir tipo TS
                        self.status_code = 200
                    def iter_content(self, chunk_size):
                        # Retorna o conteúdo inteiro como um chunk para simplificar
                        yield self._content 
                    def close(self):
                        pass 
                return MockResponse(SEGMENT_CACHE[url])

        log(f"Fetching segment (not in cache): {url}")
        try:
            r = REQUESTS_SESSION.get(url, headers=headers, stream=True, timeout=10)
            r.raise_for_status()
            
            # Lê todo o conteúdo e armazena no cache antes de retornar
            content = r.content
            with SEGMENT_CACHE_LOCK:
                SEGMENT_CACHE[url] = content
            log(f"Successfully fetched and cached segment: {url} ({len(content)} bytes)")
            
            return r # Retorna a resposta original para streaming (se 'stream=True' for necessário)
        except requests.exceptions.RequestException as e:
            log(f"Error fetching segment from {url}: {e}")
            return None

    def modify_m3u8_for_proxy(self, m3u8_content, base_url):
        """Modifica a playlist M3U8 para apontar para o proxy e enfileira segmentos para pré-busca."""
        lines = m3u8_content.splitlines()
        modified_lines = []
        segment_urls_for_prefetch = []

        for line in lines:
            # Manter linhas de metadados HLS como estão
            if line.startswith('#EXTINF') or \
               line.startswith('#EXT-X-TARGETDURATION') or \
               line.startswith('#EXT-X-MEDIA-SEQUENCE') or \
               line.startswith('#EXT-X-VERSION') or \
               line.startswith('#EXT-X-PLAYLIST-TYPE') or \
               line.startswith('#EXT-X-ENDLIST') or \
               line.startswith('#EXT-X-DISCONTINUITY'):
                modified_lines.append(line)
            # Modificar #EXT-X-MAP ou #EXT-X-BYTERANGE se necessário (geralmente não precisam de proxy direto)
            elif line.startswith('#EXT-X-MAP') or line.startswith('#EXT-X-BYTERANGE'):
                modified_lines.append(line)
            # Tratar chaves de criptografia para URLs relativas
            elif line.startswith('#EXT-X-KEY'):
                key_match = re.search(r'URI="([^"]+)"', line)
                if key_match:
                    key_uri = key_match.group(1)
                    if not urlparse(key_uri).scheme: # Se a URI for relativa
                        absolute_key_uri = urljoin(base_url, key_uri)
                        line = line.replace(key_uri, absolute_key_uri)
                modified_lines.append(line)
            # Processar URLs de segmentos
            elif not line.strip().startswith('#') and line.strip(): # É uma URL de segmento
                segment_url = line.strip()
                if not urlparse(segment_url).scheme: # Se a URL do segmento for relativa
                    segment_url = urljoin(base_url, segment_url)

                # Criar a URL proxyficada para o segmento
                proxied_segment_url = url_segment_proxy_prefix + quote_plus(segment_url)
                
                # Adicionar headers como parâmetros de query para o proxy de segmento, se necessário
                header_params = []
                for key, value in HEADERS_BASE.items():
                    # Evitar adicionar headers padrão ou desnecessários para a URL do segmento
                    if key.lower() not in ['connection', 'host']: 
                        header_params.append(f"{quote_plus(key)}={quote_plus(value)}")
                
                if header_params:
                    proxied_segment_url += '&' + '&'.join(header_params)

                modified_lines.append(proxied_segment_url)
                segment_urls_for_prefetch.append(segment_url) # Adicionar para pré-busca

            else: # Outras linhas (comentários desconhecidos, etc.)
                modified_lines.append(line)
        
        # Enfileirar os segmentos para pré-busca
        log(f"Queueing {len(segment_urls_for_prefetch)} segments for prefetch.")
        for url in segment_urls_for_prefetch:
            PREFETCH_QUEUE.put(url)
        
        return "\n".join(modified_lines)

    # --- Métodos HTTP ---
    def do_HEAD(self):
        self.handle_request('HEAD')

    def do_GET(self):
        self.handle_request('GET')

    def handle_request(self, method):
        """Lida com as requisições HTTP para o proxy."""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query_params = parse_qs(parsed_path.query)

        if path == '/proxy_m3u8':
            if 'url' in query_params and query_params['url']:
                global URL_BASE, LAST_URL, HEADERS_BASE, CACHE_M3U8
                
                url_to_fetch = unquote_plus(query_params['url'][0])
                
                # Extrair e armazenar headers fornecidos na URL
                extracted_headers = {}
                for key, values in query_params.items():
                    if key not in ['url'] and values:
                        extracted_headers[key] = unquote_plus(values[0])

                HEADERS_BASE = {}
                # Priorizar headers comuns
                for h_key in ['User-Agent', 'Referer', 'Origin', 'Connection', 'Host']:
                    if h_key in extracted_headers:
                        HEADERS_BASE[h_key] = extracted_headers[h_key]
                        del extracted_headers[h_key] # Remover para não adicionar duplicado
                
                # Adicionar um Connection: keep-alive se não estiver presente
                if 'Connection' not in HEADERS_BASE:
                    HEADERS_BASE['Connection'] = 'keep-alive'
                
                # Adicionar quaisquer outros headers extraídos
                HEADERS_BASE.update(extracted_headers)

                log(f"Received proxy request for URL: {url_to_fetch}")
                log(f"Headers to use: {HEADERS_BASE}")

                # Se a URL base mudou, reiniciar o estado do proxy
                if url_to_fetch != LAST_URL:
                    log("URL changed, resetting cache and state.")
                    URL_BASE = ''
                    LAST_URL = ''
                    CACHE_M3U8 = ''
                    # LIMPAR CACHE DE SEGMENTOS E REINICIAR THREADS DE PRÉ-BUSCA
                    with SEGMENT_CACHE_LOCK:
                        SEGMENT_CACHE.clear()
                    # Limpar fila de pré-busca
                    while not PREFETCH_QUEUE.empty():
                        try:
                            PREFETCH_QUEUE.get_nowait()
                            PREFETCH_QUEUE.task_done()
                        except queue.Empty:
                            pass
                    PREFETCH_STOP_EVENT.clear() # Limpa o evento para novas threads se o servidor for reiniciado
                                                # ou se novas threads forem criadas explicitamente.

                LAST_URL = url_to_fetch
                
                m3u8_content, final_url = self.fetch_m3u8(url_to_fetch, HEADERS_BASE)

                if m3u8_content:
                    if not URL_BASE or (final_url and not final_url.startswith(URL_BASE)):
                        # Derivar a URL_BASE da URL final após redirecionamentos
                        URL_BASE = os.path.dirname(final_url) + '/' if '/' in os.path.dirname(final_url) else final_url
                        log(f"Updated URL_BASE to: {URL_BASE}")
                    
                    CACHE_M3U8 = m3u8_content
                    modified_m3u8 = self.modify_m3u8_for_proxy(m3u8_content, URL_BASE)
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/x-mpegURL')
                    self.end_headers()
                    self.wfile.write(modified_m3u8.encode('utf-8'))
                else:
                    log(f"Failed to fetch M3U8 for {url_to_fetch}")
                    self.send_response(404)
                    self.end_headers()
            else:
                log("Missing 'url' parameter in proxy request.")
                self.send_response(400)
                self.end_headers()

        elif path.startswith('/proxy_segment/'):
            # Decodificar a URL do segmento e extrair headers adicionais
            encoded_segment_url_and_params = self.path[len('/proxy_segment/'):]
            
            # Separar a URL base do segmento dos parâmetros de header
            parts = encoded_segment_url_and_params.split('&', 1)
            segment_url_decoded = unquote_plus(parts[0])
            
            segment_query_params = {}
            if len(parts) > 1:
                # Reconstruir query string para parse_qs
                temp_query_string = parts[1]
                segment_query_params = parse_qs(temp_query_string)

            segment_headers = {}
            for key, values in segment_query_params.items():
                if values:
                    segment_headers[key] = unquote_plus(values[0])
            
            # Combinar headers base com headers específicos do segmento
            current_segment_headers = HEADERS_BASE.copy()
            current_segment_headers.update(segment_headers)

            log(f"Received proxy request for segment: {segment_url_decoded}")
            log(f"Headers for segment: {current_segment_headers}")

            segment_response = self.fetch_chunk(segment_url_decoded, current_segment_headers)
            if segment_response:
                self.send_response(200)
                # Copiar headers da resposta original, exceto alguns que podem causar problemas
                for header, value in segment_response.headers.items():
                    if header.lower() not in ['transfer-encoding', 'content-encoding', 'connection', 'content-length']:
                        self.send_header(header, value)
                
                # Adicionar Content-Length se o conteúdo for do cache (MockResponse)
                if hasattr(segment_response, '_content'):
                    self.send_header('Content-Length', str(len(segment_response._content)))
                
                self.end_headers()
                
                try:
                    # Serve o conteúdo do segmento
                    if hasattr(segment_response, '_content'): # É um MockResponse (do cache)
                        self.wfile.write(segment_response._content)
                    else: # É um requests.Response (busca em tempo real)
                        for chunk in segment_response.iter_content(chunk_size=8192):
                            self.wfile.write(chunk)
                except Exception as e:
                    log(f"Error streaming segment content: {e}")
                finally:
                    segment_response.close()
            else:
                self.send_response(404)
                self.end_headers()
        
        elif path == '/check':
            log("HEAD /check received. Server is responsive.")
            self.send_response(200)
            self.end_headers()

        elif path == '/stop':
            log("HEAD /stop received. Initiating server shutdown.")
            global STOP_SERVER
            STOP_SERVER = True
            
            # Limpar todas as variáveis globais
            URL_BASE = ''
            LAST_URL = ''
            HEADERS_BASE = {}
            CACHE_M3U8 = ''
            
            # Sinalizar threads de pré-busca para parar e limpar cache
            PREFETCH_STOP_EVENT.set()
            # Limpar fila (threads deverão parar de consumir, mas limpar garante estado limpo)
            while not PREFETCH_QUEUE.empty():
                try:
                    PREFETCH_QUEUE.get_nowait()
                    PREFETCH_QUEUE.task_done()
                except queue.Empty:
                    pass
            with SEGMENT_CACHE_LOCK:
                SEGMENT_CACHE.clear()
            log("All global proxy variables and segment cache have been reset. Prefetch threads signaled to stop.")
            
            self.send_response(200)
            self.end_headers()

        elif path == '/reset':
            log("HEAD /reset received. Resetting global states.")
            # Limpar todas as variáveis globais, mas não parar o servidor HTTP
            URL_BASE = ''
            LAST_URL = ''
            HEADERS_BASE = {}
            CACHE_M3U8 = ''

            # Sinalizar threads de pré-busca para parar e limpar cache
            PREFETCH_STOP_EVENT.set() # Sinaliza threads atuais para parar
            # Limpar fila
            while not PREFETCH_QUEUE.empty():
                try:
                    PREFETCH_QUEUE.get_nowait()
                    PREFETCH_QUEUE.task_done()
                except queue.Empty:
                    pass
            with SEGMENT_CACHE_LOCK:
                SEGMENT_CACHE.clear()
            
            # Reiniciar threads de pré-busca com novo estado de HEADERS_BASE (vazio por enquanto)
            PREFETCH_STOP_EVENT.clear() # Limpa o evento para permitir que novas threads rodem
            # Não reiniciar threads aqui, elas são iniciadas pelo ThreadedHTTPServer quando ele é iniciado ou restartado
            # se o servidor principal não estiver em execução, ele será reiniciado no server.start()
            
            log("All global proxy variables and segment cache have been reset.")
            
            self.send_response(200)
            self.end_headers()
        else:
            log(f"{method} request for unknown path: {self.path}")
            self.send_response(404)
            self.end_headers()

# --- Classe do Servidor HTTP Threaded ---
class ThreadedHTTPServer(threading.Thread):
    def __init__(self, host, port):
        super(ThreadedHTTPServer, self).__init__()
        self.daemon = True # Permite que a thread termine quando o programa principal termina
        self.host = host
        self.port = port
        self.server = None
        self.running = False
        self.prefetch_threads = [] # Lista para manter referências às threads de pré-busca
        log("Server thread initialized.")

    def run(self):
        try:
            # Iniciar threads de pré-busca ANTES do servidor HTTP
            PREFETCH_STOP_EVENT.clear() # Garante que o evento está limpo para novas threads
            self.prefetch_threads = []
            for i in range(PREFETCH_WORKERS):
                # Passa uma cópia dos HEADERS_BASE para cada thread
                thread = PrefetchThread(PREFETCH_QUEUE, SEGMENT_CACHE, SEGMENT_CACHE_LOCK, PREFETCH_STOP_EVENT, HEADERS_BASE.copy())
                thread.start()
                self.prefetch_threads.append(thread)
            log(f"{PREFETCH_WORKERS} prefetch threads started.")

            self.server = HTTPServer((self.host, self.port), ProxyHandler)
            log(f"Server initialized and listening on {self.host}:{self.port}")
            self.running = True
            # Iniciar o servidor HTTP
            self.server.serve_forever()
        except Exception as e:
            log(f"Error starting HTTP server: {e}")
        finally:
            self.running = False
            if self.server:
                self.server.server_close() # Fechar o socket do servidor
            # Sinalizar threads de pré-busca para parar ao fechar o servidor
            PREFETCH_STOP_EVENT.set()
            for thread in self.prefetch_threads:
                thread.join(timeout=2) # Esperar um pouco pelas threads
                if thread.is_alive():
                    log(f"Warning: Prefetch thread {thread.name} did not terminate gracefully.")
            log("HTTP server stopped and prefetch threads joined.")

# --- Classe de Controle do Servidor ---
class Server:
    def __init__(self):
        global STOP_SERVER
        STOP_SERVER = False # Garante que a flag de parada seja False ao inicializar
        self.server_thread = ThreadedHTTPServer(HOST_NAME, PORT_NUMBER)
        self.server_thread_ok = True # Flag para indicar se a thread do servidor foi criada com sucesso
        log("Server controller initialized, thread created.")

    def in_use(self):
        """Verifica se o servidor proxy já está em execução e respondendo."""
        url = url_check # Usa a URL de check definida globalmente
        try:
            r = REQUESTS_SESSION.head(url, timeout=1)
            if r.status_code == 200:
                log("Server is already in use.")
                r.close()
                return True
            r.close()
        except requests.exceptions.RequestException as e:
            log(f"Server not responsive or not running: {e}")
        return False

    def start(self):
        """Inicia o servidor proxy ou reinicia seu estado se já estiver em uso."""
        if not self.in_use():
            if self.server_thread_ok:
                log("Starting new server thread.")
                self.server_thread.start()
                # Dê um momento para o servidor inicializar e as threads de pré-busca começarem
                time.sleep(1.0) # Aumentado para 1 segundo para maior robustez
                # Verifica se o servidor realmente iniciou
                if not self.in_use():
                    log("Warning: Server thread started but not responding to /check immediately. Retrying start or checking.")
                    # Pode adicionar lógica de retentativa aqui se for crítico
            else:
                log("Server thread not initialized successfully, cannot start.")
        else:
            log("Server already in use. Resetting global states for a new session.")
            url = url_reset # Usa a URL de reset definida globalmente
            try:
                r = REQUESTS_SESSION.head(url, timeout=2)
                r.close()
                log("Sent reset command to existing server.")
            except requests.exceptions.RequestException as e:
                log(f"Failed to send reset command to existing server: {e}. Consider restarting Kodi or checking port.")

# --- Funções de Utilitário para o Kodi ---
def get_hls_url(url, headers=None):
    """
    Constrói a URL proxyficada para playlists M3U8, incluindo headers.
    """
    global url_proxy, HEADERS_BASE
    
    # Certifica-se de que os HEADERS_BASE globais sejam atualizados com os headers passados
    # para esta função, que viriam do item da lista do Kodi.
    if headers:
        HEADERS_BASE.update(headers)
    
    proxied_url = url_proxy + quote_plus(url)
    
    # Adicionar todos os HEADERS_BASE como parâmetros de query para o proxy_m3u8
    for key, value in HEADERS_BASE.items():
        proxied_url += f"&{quote_plus(key)}={quote_plus(value)}"
    
    log(f"Constructed proxied HLS URL: {proxied_url}")
    return proxied_url

def stop_all_proxies():
    """Tenta parar o servidor proxy."""
    global STOP_SERVER
    STOP_SERVER = True
    log("Attempting to stop proxy server...")
    try:
        r = REQUESTS_SESSION.head(url_stop, timeout=5)
        r.close()
        log(f"Stop command sent to proxy server. Status: {r.status_code}")
    except requests.exceptions.RequestException as e:
        log(f"Failed to send stop command to proxy server: {e}")
    
    # Limpar explicitamente a fila e o cache também no lado do cliente (redundante, mas seguro)
    while not PREFETCH_QUEUE.empty():
        try:
            PREFETCH_QUEUE.get_nowait()
            PREFETCH_QUEUE.task_done()
        except queue.Empty:
            pass
    with SEGMENT_CACHE_LOCK:
        SEGMENT_CACHE.clear()
    
    # Limpar o evento de parada para que possa ser reiniciado
    PREFETCH_STOP_EVENT.clear() 

# Instanciar o servidor principal (Server controller)
# Ele será iniciado/gerenciado pelo plugin.py
iniciavideo = Server()
