import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
import re
import queue
from collections import OrderedDict
from typing import Optional, Dict, Any, List, Tuple, Type, Union

# ==============================================================================

# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO ---
# ==============================================================================

MAX_STICKY_SEGMENT_RETRIES = 0
MAX_CONSECUTIVE_SEGMENT_FAILURES = 3
FETCHER_MAX_RETRIES = 2
RETRY_BACKOFF_FACTOR = 0.2
CONNECTION_TIMEOUT = 10.0
STREAM_TIMEOUT = 10.0
DEFAULT_CHUNK_SIZE = 1024 * 1024
MAX_STREAM_LIFETIME_SECONDS = 2
MAX_CACHE_MB = 128
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
MAX_SEGMENT_SIZE_MB = 8
MAX_SEGMENT_SIZE_BYTES = MAX_SEGMENT_SIZE_MB * 1024 * 1024
PREFETCH_SEGMENTS_COUNT = 3
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 10
LIMIT_COOLDOWN_SECONDS = 15
SPOOF_X_FORWARDED_FOR = True
FIXED_X_FORWARDED_FOR_IP = "1.1.1.1"
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
]
LOG_MAX_BYTES = 1048576 * 1
LOG_BACKUP_COUNT = 1
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
LOG_LEVEL = logging.INFO

_SENSITIVE_HEADERS = {'X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                      'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP',
                      'Content-Length', 'Connection'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}

# ==============================================================================

def setup_logging():
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s',
        force=True
    )

setup_logging()

# ==============================================================================

def is_valid_ip(address: str) -> bool:
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def join_host_port(host: str, port: int) -> str:
    return f'[{host}]:{port}' if ':' in host and is_valid_ip(host) else f'{host}:{port}'

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    headers = {
        "User-Agent": USER_AGENTS[0],
        "Accept": "*/*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": origin
    }
    return headers

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith('.m3u8') or path.endswith('.m3u'):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.aac'):
        return 'audio/aac'
    if path.endswith('.mp4'):
        return 'video/mp4'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content:
        return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u":
        return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections",
                "max session", "#error", "offline", "geoblocked", "stream not found",
                "access denied", "blocked", "forbidden", "unavailable", "invalid"]
    return any(keyword in txt for keyword in keywords)

# ==============================================================================

class DoHDNSResolver:
    def __init__(self, cache_ttl: int = 300, doh_url: str = 'https://1.1.1.1/dns-query'):
        self._cache: Dict[str, Tuple[str, float]] = {}
        self._lock = threading.Lock()
        self.cache_ttl = cache_ttl
        self.doh_url = doh_url
        self.session = requests.Session()

    def _query_doh(self, hostname: str) -> Optional[str]:
        headers = {
            "Accept": "application/dns-json"
        }
        params = {
            "name": hostname,
            "type": "A"
        }
        try:
            response = self.session.get(self.doh_url, params=params, headers=headers, timeout=CONNECTION_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            if data and 'Answer' in data:
                for answer in data['Answer']:
                    if answer['type'] == 1:
                        logging.debug(f"[DoHDNSResolver] DoH resolveu {hostname} para {answer['data']}")
                        return answer['data']
            logging.warning(f"[DoHDNSResolver] Nenhuma resposta IP válida de DoH para {hostname}.")
            return None
        except requests.exceptions.Timeout:
            logging.warning(f"[DoHDNSResolver] Tempo limite excedido ao consultar DoH para {hostname}.")
            return None
        except requests.exceptions.RequestException as e:
            logging.warning(f"[DoHDNSResolver] Erro ao consultar DoH para {hostname}: {e}")
            return None
        except Exception as e:
            logging.error(f"[DoHDNSResolver] Erro inesperado na resolução DoH para {hostname}: {e}", exc_info=True)
            return None

    def resolve(self, hostname: str) -> Optional[str]:
        if is_valid_ip(hostname):
            return hostname
        with self._lock:
            cached_entry = self._cache.get(hostname)
            if cached_entry and time.time() < cached_entry[1]:
                logging.debug(f"[DoHDNSResolver] Usando cache para {hostname}: {cached_entry[0]}")
                return cached_entry[0]
        ip = self._query_doh(hostname)
        if ip:
            self._add_to_cache(hostname, ip, self.cache_ttl)
            return ip
        else:
            return None

    def _add_to_cache(self, hostname: str, ip: str, ttl: int):
        with self._lock:
            self._cache[hostname] = (ip, time.time() + ttl)

    def clear_cache_for_host(self, hostname: str):
        with self._lock:
            if hostname in self._cache:
                del self._cache[hostname]
                logging.info(f"[RECONEXÃO] Cache de DNS limpo para o host: {hostname}")

    def clear_cache(self):
        with self._lock:
            self._cache.clear()
            logging.info("[RECONEXÃO] Todo o cache de DNS foi limpo.")

# ==============================================================================

class RotatingChunkCache:
    def __init__(self_obj, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self_obj.max_bytes = max_bytes
        self_obj.lock = threading.Lock()
        self_obj.chunks: OrderedDict[str, bytes] = OrderedDict()
        self_obj.total_bytes = 0

    def get(self_obj, url: str) -> Optional[bytes]:
        with self_obj.lock:
            data = self_obj.chunks.get(url)
            if data:
                self_obj.chunks.move_to_end(url)
                logging.debug(f"[Cache] Hit para {url}, tamanho {len(data)} bytes.")
            else:
                logging.debug(f"[Cache] Miss para {url}.")
            return data

    def add(self_obj, url: str, data: bytes):
        with self_obj.lock:
            if url in self_obj.chunks:
                self_obj.total_bytes -= len(self_obj.chunks.pop(url))
            chunk_size = len(data)
            if chunk_size > self_obj.max_bytes:
                logging.warning(f"[Cache] Segmento muito grande para cache: {url}, tamanho {chunk_size} bytes.")
                return
            self_obj.chunks[url] = data
            self_obj.total_bytes += chunk_size
            logging.debug(f"[Cache] Adicionado {url}, tamanho {chunk_size} bytes. Total: {self_obj.total_bytes / (1024*1024):.2f}MB")
            while self_obj.total_bytes > self_obj.max_bytes:
                _, old_data = self_obj.chunks.popitem(last=False)
                self_obj.total_bytes -= len(old_data)
                logging.debug(f"[Cache] Removido do LRU. Total: {self_obj.total_bytes / (1024*1024):.2f}MB")

    def clear(self_obj):
        with self_obj.lock:
            self_obj.chunks.clear()
            self_obj.total_bytes = 0
            logging.info("[RECONEXÃO] Cache de segmentos de vídeo limpo.")

    def has(self_obj, url: str) -> bool:
        with self_obj.lock:
            return url in self_obj.chunks

class StreamCache:
    def __init__(self_obj, chunk_cache: RotatingChunkCache):
        self_obj.manifest_cache: Dict[str, Dict[str, Any]] = {}
        self_obj.chunk_cache = chunk_cache
        self_obj.lock = threading.Lock()

    def get_manifest(self_obj, url: str) -> Optional[str]:
        with self_obj.lock:
            entry = self_obj.manifest_cache.get(url)
            if entry and time.time() < entry['expires']:
                logging.debug(f"[ManifestCache] Hit para {url}")
                return entry['content']
            logging.debug(f"[ManifestCache] Miss ou expirado para {url}")
            return None

    def add_manifest(self_obj, url: str, content: str, ttl: int):
        with self_obj.lock:
            self_obj.manifest_cache[url] = {
                'content': content,
                'expires': time.time() + ttl,
                'last_refresh_time': time.time()
            }
            logging.debug(f"[ManifestCache] Adicionado {url} com TTL {ttl}s.")

    def invalidate_manifest(self_obj, url: str):
        with self_obj.lock:
            if url in self_obj.manifest_cache:
                del self_obj.manifest_cache[url]
                logging.info(f"[RECONEXÃO] Manifesto {url} invalidado do cache.")

    def is_manifest_expired(self_obj, url: str) -> bool:
        with self_obj.lock:
            entry = self_obj.manifest_cache.get(url)
            return not entry or time.time() - entry.get('last_refresh_time', 0) >= MAX_STREAM_LIFETIME_SECONDS

    def get_segment(self_obj, url: str) -> Optional[bytes]:
        return self_obj.chunk_cache.get(url)

    def add_segment(self_obj, url: str, data: bytes):
        self_obj.chunk_cache.add(url, data)

    def has_segment(self_obj, url: str) -> bool:
        return self_obj.chunk_cache.has(url)

    def clear(self_obj):
        with self_obj.lock:
            self_obj.manifest_cache.clear()
        self_obj.chunk_cache.clear()

# ==============================================================================

class UpstreamFetcher:
    def __init__(self, session: requests.Session, dns_resolver: 'DoHDNSResolver'):
        self.session = session
        self.dns_resolver = dns_resolver

    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        headers = get_player_headers(url)
        if original_headers:
            cleaned_original = clean_headers(original_headers)
            headers.update({k: v for k, v in cleaned_original.items() if k in ['Authorization', 'Cookie']})
        if SPOOF_X_FORWARDED_FOR:
            headers['X-Forwarded-For'] = FIXED_X_FORWARDED_FOR_IP
        req_url = url
        logging.debug(f"[Fetcher] Requisição para: {req_url} (Host Header: {headers.get('Host', 'N/A')}, Stream: {stream})")
        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                resp = self.session.get(
                    req_url, stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                resp.raise_for_status()
                logging.debug(f"[Fetcher] Sucesso ({resp.status_code}) para {url} na tentativa {attempt + 1}.")
                return resp
            except requests.RequestException as e:
                logging.warning(f"[Fetcher] Tentativa {attempt + 1}/{FETCHER_MAX_RETRIES + 1} falhou para {url}: {e}")
                if attempt < FETCHER_MAX_RETRIES:
                    time.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt) + random.uniform(0, 0.1))
                else:
                    raise

class ManifestRewriter:
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        self.original_manifest_url = manifest_url

    def rewrite(self) -> str:
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri:
                if not item.key.uri.startswith("data:"):
                    item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self) -> int:
        target_duration = getattr(self.m3u8_obj, 'target_duration', 10)
        if self.is_live:
            return max(1, int(target_duration * 0.6))
        return 3600

# ==============================================================================

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, request: bytes, client_address: Tuple[str, int], server: socketserver.BaseServer,
                 stream_cache: 'StreamCache', fetcher: 'UpstreamFetcher', proxy_manager: 'HLSProxyManager'):
        self.stream_cache = stream_cache
        self.fetcher = fetcher
        self.proxy_manager = proxy_manager
        super().__init__(request, client_address, server)

    def log_message(self, format: str, *args: Any):
        pass

    def _send_response(self, status_code: int, content: bytes, content_type: str):
        self.send_response(status_code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        if content:
            self.wfile.write(content)
        self.wfile.flush()

    def do_GET(self):
        try:
            query_params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            original_url = query_params.get('url', [''])[0]
            if not original_url:
                logging.error(f"[{self.address_string()}] Parâmetro 'url' ausente na requisição: {self.path}")
                return self.send_error(400, "Parâmetro 'url' ausente")
            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            logging.info(f"[{self.address_string()}] Cliente desconectou.")
        except Exception as e:
            logging.error(f"[{self.address_string()}] Erro geral no proxy para {self.path}: {e}", exc_info=True)
            if not self.wfile.closed:
                self.send_error(500, "Erro interno do servidor")

    def _handle_manifest(self, url: str):
        logging.info(f"[{self.address_string()}] Manipulando manifesto: {url}")
        if self.proxy_manager.is_in_cooldown(url):
            cooldown = LIMIT_COOLDOWN_SECONDS
            logging.warning(f"Manifesto em cooldown por {cooldown}s. Enviando playlist vazia.")
            return self._send_response(200, b"#EXTM3U\n", 'application/vnd.apple.mpegurl')
        if self.stream_cache.is_manifest_expired(url):
            logging.info(f"Manifesto expirou (> {MAX_STREAM_LIFETIME_SECONDS}s). Forçando reconexão para refresh.")
            self.proxy_manager.force_reconnection(url)
        cached_content = self.stream_cache.get_manifest(url)
        if cached_content:
            return self._send_response(200, cached_content.encode('utf-8'), 'application/vnd.apple.mpegurl')
        try:
            response = self.fetcher.fetch(url, original_headers=self.headers)
            content = response.text
            start_time = time.time()
            if is_manifest_limit_error(content):
                logging.warning(f"Erro de limite/bloqueio detectado para {url}. Forçando reconexão.")
                self.proxy_manager.record_limit_hit(url)
                self.proxy_manager.force_reconnection(url)
                return self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")
            proxy_base = f"http://{join_host_port(self.server.server_address[0], self.server.server_address[1])}/?url="
            rewriter = ManifestRewriter(content, response.url, proxy_base)
            rewritten_content = rewriter.rewrite()
            ttl = rewriter.get_ttl()
            self.stream_cache.add_manifest(url, rewritten_content, ttl)
            self.proxy_manager.clear_limit_hit(url)
            self._send_response(200, rewritten_content.encode('utf-8'), 'application/vnd.apple.mpegurl')
            if rewriter.is_live:
                logging.debug(f"Manifesto {url} é ao vivo. Pré-buscando os últimos {PREFETCH_SEGMENTS_COUNT} segmentos.")
                segments_to_prefetch = rewriter.m3u8_obj.segments[-PREFETCH_SEGMENTS_COUNT:]
                for segment in segments_to_prefetch:
                    absolute_segment_uri = segment.absolute_uri
                    if not self.stream_cache.has_segment(absolute_segment_uri):
                        self.proxy_manager.queue_segment_for_prefetch(absolute_segment_uri)
                        logging.debug(f"Segmento {absolute_segment_uri} adicionado à fila de pré-busca (LIVE).")
            else:
                logging.info(f"Manifesto {url} é VOD. Pré-buscando TODOS os segmentos e reiniciando a sessão.")
                for segment in rewriter.m3u8_obj.segments:
                    absolute_segment_uri = segment.absolute_uri
                    if not self.stream_cache.has_segment(absolute_segment_uri):
                        self.proxy_manager.queue_segment_for_prefetch(absolute_segment_uri)
                        logging.debug(f"Segmento {absolute_segment_uri} adicionado à fila de pré-busca (VOD).")
                self.proxy_manager.force_reconnection(url)
                logging.info(f"Sessão HTTP reiniciada após processar manifesto VOD para {url}.")
            logging.debug(f"Manifesto {url} processado em {time.time() - start_time:.4f}s")
        except Exception as e:
            logging.error(f"Falha ao buscar ou processar manifesto {url}: {e}", exc_info=False)
            self.proxy_manager.force_reconnection(url)
            self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

    def _handle_segment(self, url: str):
        mime_type = safe_mime_type(url)
        start_time = time.time()
        cached_segment = self.stream_cache.get_segment(url)
        if cached_segment:
            self.proxy_manager.reset_failure_count()
            logging.debug(f"Segmento {url} servido do cache em {time.time() - start_time:.4f}s")
            return self._send_response(200, cached_segment, mime_type)
        logging.debug(f"Iniciando download de segmento {url}")
        try:
            response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
            segment_data = bytearray()
            for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                segment_data.extend(chunk)
                if len(segment_data) > MAX_SEGMENT_SIZE_BYTES:
                    raise IOError(f"Segmento excedeu o tamanho máximo de {MAX_SEGMENT_SIZE_MB}MB.")
            final_data = bytes(segment_data)
            self.stream_cache.add_segment(url, final_data)
            self.proxy_manager.reset_failure_count()
            logging.info(f"Segmento {url} baixado e servido em {time.time() - start_time:.4f}s, tamanho {len(final_data)} bytes.")
            self._send_response(200, final_data, mime_type)
        except Exception as e:
            logging.warning(f"Falha ao baixar segmento {url}: {e}")
            self.proxy_manager.increment_failure_count()
            if self.proxy_manager.should_force_reconnect():
                logging.error(f"Limite de falhas consecutivas atingido. FORÇANDO RECONEXÃO TOTAL.")
                self.proxy_manager.force_reconnection(url)
                self.proxy_manager.reset_failure_count()
            self.send_error(503, "Segmento indisponível ou falha na rede.")

class HLSProxyManager:
    def __init__(self):
        self.server: Optional[socketserver.ThreadingTCPServer] = None
        self.server_thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None
        self._http_session: requests.Session = self._create_http_session()
        self.dns_resolver = DoHDNSResolver()
        self.chunk_cache = RotatingChunkCache()
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(self._http_session, self.dns_resolver)
        self._failure_lock = threading.Lock()
        self._consecutive_failures = 0
        self._limit_hits: Dict[str, float] = {}
        self._segment_prefetch_queue = queue.Queue(maxsize=100)
        self._prefetch_thread: Optional[threading.Thread] = None
        self._prefetch_stop_event = threading.Event()

    def _create_http_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({
            'User-Agent': USER_AGENTS[0],
            'Accept': '*/*',
            'Connection': 'keep-alive'
        })
        session.trust_env = False
        return session

    def reset_http_session(self):
        logging.info("[RECONEXÃO] Recriando sessão HTTP.")
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher.session = self._http_session
        self.dns_resolver.clear_cache()
        with self._segment_prefetch_queue.mutex:
            self._segment_prefetch_queue.queue.clear()
        logging.info("[RECONEXÃO] Fila de pré-busca limpa.")

    def force_reconnection(self, url: str):
        logging.info(f"[RECONEXÃO] Forçando reconexão para URL base: {url}")
        parsed_url = urllib.parse.urlparse(url)
        if parsed_url.hostname:
            self.dns_resolver.clear_cache_for_host(parsed_url.hostname)
        self.stream_cache.clear()
        self.reset_http_session()

    def increment_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures += 1
            logging.debug(f"Contador de falhas consecutivas: {self._consecutive_failures}")

    def reset_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures = 0
            logging.debug("Contador de falhas consecutivas resetado.")

    def should_force_reconnect(self) -> bool:
        with self._failure_lock:
            return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES

    def record_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        self._limit_hits[base_url] = time.time()
        logging.warning(f"Limite de conexão registrado para {base_url}.")

    def is_in_cooldown(self, url: str) -> bool:
        base_url = self._get_base_url(url)
        hit_time = self._limit_hits.get(base_url)
        is_cooldown = hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS
        if is_cooldown:
            logging.info(f"URL {base_url} em cooldown.")
        return is_cooldown

    def clear_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        if base_url in self._limit_hits:
            del self._limit_hits[base_url]
            logging.info(f"Cooldown limpo para {base_url}.")

    @staticmethod
    def _get_base_url(url: str) -> str:
        parts = urllib.parse.urlparse(url)
        return f"{parts.scheme}://{parts.netloc}"

    def queue_segment_for_prefetch(self, segment_url: str):
        try:
            if segment_url not in self._segment_prefetch_queue.queue:
                self._segment_prefetch_queue.put_nowait(segment_url)
            else:
                logging.debug(f"[Prefetch] Segmento {segment_url} já na fila.")
        except queue.Full:
            logging.warning("Fila de pré-busca cheia. Descartando segmento.")
        except Exception as e:
            logging.error(f"[Prefetch] Erro ao enfileirar segmento {segment_url}: {e}", exc_info=False)

    def _prefetch_worker(self):
        logging.info("Thread de pré-busca iniciada.")
        while not self._prefetch_stop_event.is_set():
            try:
                segment_url = self._segment_prefetch_queue.get(timeout=1)
                if self._prefetch_stop_event.is_set():
                    break
                if self.stream_cache.has_segment(segment_url):
                    logging.debug(f"[Prefetch] Segmento {segment_url} já em cache, pulando.")
                    self._segment_prefetch_queue.task_done()
                    continue
                logging.debug(f"[Prefetch] Iniciando pré-busca de {segment_url}")
                try:
                    response = self.fetcher.fetch(segment_url)
                    segment_data = response.content
                    self.stream_cache.add_segment(segment_url, segment_data)
                    logging.debug(f"[Prefetch] Pré-busca de {segment_url} concluída e adicionada ao cache.")
                except Exception as e:
                    logging.warning(f"[Prefetch] Falha na pré-busca de {segment_url}: {e}")
                finally:
                    self._segment_prefetch_queue.task_done()
            except queue.Empty:
                pass
            except Exception as e:
                logging.error(f"[Prefetch] Erro inesperado na thread de pré-busca: {e}", exc_info=True)
        logging.info("Thread de pré-busca encerrada.")

    def start(self) -> Optional[int]:
        self.stop()
        def handler_factory(*args, **kwargs):
            return HLSProxyHandler(*args, **kwargs,
                                   stream_cache=self.stream_cache,
                                   fetcher=self.fetcher,
                                   proxy_manager=self)
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                server = socketserver.ThreadingTCPServer((PROXY_HOST, port), handler_factory)
                server.allow_reuse_address = True
                self.server = server
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"HLS Proxy Avançado iniciado em {PROXY_HOST}:{port}.")
                self._prefetch_stop_event.clear()
                self._prefetch_thread = threading.Thread(target=self._prefetch_worker, daemon=True)
                self._prefetch_thread.start()
                return port
            except Exception as e:
                logging.warning(f"Falha ao iniciar proxy na porta {port}: {e}.")
        logging.error("Falha ao iniciar HLS Proxy após todas as tentativas.")
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o proxy",5000)')
        return None

    def stop(self):
        if self._prefetch_thread and self._prefetch_thread.is_alive():
            logging.info("Sinalizando para a thread de pré-busca parar.")
            self._prefetch_stop_event.set()
            try:
                self._segment_prefetch_queue.join(timeout=5)
            except threading.BrokenBarrierError:
                logging.warning("Fila de pré-busca com deadlock ou timeout excedido no join.")
            self._prefetch_thread.join(timeout=2)
            if self._prefetch_thread.is_alive():
                logging.warning("Thread de pré-busca não parou a tempo.")
            self._prefetch_thread = None
        if self.server:
            logging.info(f"Parando HLS Proxy na porta {self.active_port}")
            self.server.shutdown()
            self.server.server_close()
            self.server = None
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2)
        self.stream_cache.clear()
        self.reset_http_session()
        self.active_port = None
        logging.info("Proxy parado e recursos liberados.")

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        if not self.active_port:
            return None
        encoded_url = urllib.parse.quote_plus(original_url)
        return f"http://{join_host_port(PROXY_HOST, self.active_port)}/?url={encoded_url}"

# ==============================================================================

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event

    def onPlayBackEnded(self):
        logging.info("Playback finalizado.")
        self.stop_event.set()

    def onPlayBackError(self):
        logging.error("Erro no Playback.")
        self.stop_event.set()

    def onPlayBackStopped(self):
        logging.info("Playback parado pelo usuário.")
        self.stop_event.set()

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)

    def convert_to_m3u8(self, url: str) -> str:
        """
        Converte URLs de IPTV ou segmentos em URLs de manifesto M3U8, se necessário.
        """
        try:
            if '|' in url:
                url = url.split('|')[0]
            elif '%7C' in url:
                url = url.split('%7C')[0]
            # Se já é .m3u8, /hl, .mp4, .avi, retorna como está
            if ('.m3u8' in url) or ('/hl' in url) or ('.mp4' in url) or ('.avi' in url):
                return url
            # Se tem muitos segmentos, não é .m3u8 ou /hl, nem .mp4/.avi
            if (int(url.count("/")) > 4) and (not '.m3u8' in url) and (not '/hl' in url) and (not '.mp4' in url) and (not '.avi' in url):
                parsed_url = urllib.parse.urlparse(url)
                host_part1 = '%s://%s' % (parsed_url.scheme, parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                url = host_part1 + '/live' + host_part2
                # basename
                file = url.split('/')[-1]
                if '.ts' in file:
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                else:
                    url = url + '.m3u8'
            return url
        except Exception as e:
            logging.warning(f"Falha na conversão para m3u8 (usando URL original): {e}", exc_info=True)
        return url

    def _convert_to_m3u8(self, url: str) -> str:
        
        return self.convert_to_m3u8(url)

    def play_stream(self, url: str, channel_name: Optional[str] = None):
        logging.info(f"Iniciando stream para: {url}")
        processed_url = self._convert_to_m3u8(url)
        logging.info(f"URL processada para HLS: {processed_url}")

        if not self.proxy_manager.start():
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if not proxy_url:
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        display_name = f"{channel_name or 'Stream'} [COLOR cyan](HLS Tester)[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_name)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType('application/vnd.apple.mpegurl')

        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
        logging.info(f"Kodi resolvido para a URL do proxy: {proxy_url}")

        threading.Thread(target=self.monitor_playback, daemon=True).start()

    def monitor_playback(self):
        logging.info("Monitor de playback iniciado.")
        self.playback_stop_event.wait()
        logging.info("Evento de parada de playback recebido. Liberando proxy.")
        self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Big Buck Bunny (VOD - Teste de download completo)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Exemplo Live (Pode estar offline, teste de atualização manifesto)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
        ]
        for name, url in test_streams:
            list_item = xbmcgui.ListItem(label=name)
            list_item.setProperty('IsPlayable', 'true')
            list_item.setMimeType(safe_mime_type(url))
            plugin_url_params = urllib.parse.urlencode({'action': 'play', 'url': url, 'title': name})
            plugin_url = f"plugin://{ADDON_ID}/?{plugin_url_params}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, list_item, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

def main():
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get('action')
        addon = HLSProxyAddon(handle)
        if action == 'play':
            url_to_play = params.get('url')
            title = params.get('title')
            if url_to_play:
                addon.play_stream(url_to_play, title)
        else:
            addon.show_test_streams()
    except Exception as e:
        logging.error(f"Erro na execução principal do addon: {e}", exc_info=True)

if __name__ == '__main__':
    main()
