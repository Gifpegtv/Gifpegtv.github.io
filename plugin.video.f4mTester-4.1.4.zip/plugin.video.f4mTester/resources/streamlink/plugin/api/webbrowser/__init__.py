"""
Similar to the APIs of the ``streamlink.webbrowser`` package, this subpackage is considered unstable and may change at any time.
Use at your own risk!
"""
