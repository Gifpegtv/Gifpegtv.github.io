# -*- coding: utf-8 -*-
import sys
import os
import threading
import logging
import urllib.parse
import warnings
import time
import random
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
import xbmc
import xbmcgui
import xbmcplugin
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import HTTPError, RequestException
from urllib3.util.retry import Retry
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import socket
import io
from urllib.parse import urlparse
from datetime import datetime, timedelta

# ---------------- RESOLVEDOR DNS OVER HTTPS (API JSON DO GOOGLE) ----------------
class DOHResolver:
    """
    Resolve nomes de domínio usando DNS over HTTPS (DoH) através da API JSON do Google.
    Esta abordagem é mais simples e robusta do que analisar pacotes DNS binários.
    """
    def __init__(self):
        # Usando a API de JSON do Google DNS
        self.google_doh_url = "https://dns.google/resolve"
        self.cache = {}
        self.default_ttl = 3600  # 1 hora em segundos para cache
        self.session = None
        
    def initialize_session(self):
        """Inicializa a sessão HTTP para o resolvedor DoH."""
        if self.session is None:
            # A função create_session é definida mais tarde no arquivo
            self.session = create_session()
    
    def is_ip_address(self, hostname):
        """Verifica se o hostname já é um endereço IP."""
        try:
            socket.inet_aton(hostname)
            return True
        except socket.error:
            return False

    def resolve(self, hostname):
        """
        Resolve um nome de domínio para um endereço IP usando a API DoH do Google.
        Mantém um cache local para evitar consultas repetidas.
        """
        # Se já for um IP, retorna o próprio hostname
        if self.is_ip_address(hostname):
            return hostname
            
        # Verifica se está no cache e ainda é válido
        if hostname in self.cache:
            cached_data = self.cache[hostname]
            if datetime.now() < cached_data['expires']:
                xbmc.log(f"Usando DNS cache para {hostname}: {cached_data['ip']}", xbmc.LOGDEBUG)
                return cached_data['ip']
        
        # Se não estiver no cache ou expirou, faz uma nova consulta
        try:
            self.initialize_session()
            
            # Parâmetros para a API do Google DNS
            params = {
                'name': hostname,
                'type': 'A'  # Pedimos um registro A (IPv4)
            }
            
            headers = {
                'Accept': 'application/dns-json'
            }
            
            xbmc.log(f"Fazendo consulta DoH para {hostname}", xbmc.LOGDEBUG)
            response = self.session.get(
                self.google_doh_url,
                params=params,
                headers=headers,
                timeout=5
            )
            response.raise_for_status()
            
            # Analisa a resposta JSON
            data = response.json()
            
            # Verifica se a consulta foi bem-sucedida (Status 0 = NOERROR)
            if data.get('Status') != 0:
                xbmc.log(f"Consulta DNS falhou para {hostname}. Status: {data.get('Status')}", xbmc.LOGWARNING)
                return hostname

            # Procura por um registro A na resposta
            answers = data.get('Answer', [])
            for answer in answers:
                if answer.get('type') == 1:  # Type 1 = A record
                    ip_address = answer.get('data')
                    ttl = answer.get('TTL', self.default_ttl)
                    
                    if ip_address:
                        # Armazena no cache
                        expires = datetime.now() + timedelta(seconds=ttl)
                        self.cache[hostname] = {
                            'ip': ip_address,
                            'expires': expires
                        }
                        
                        xbmc.log(f"DNS resolvido via DoH: {hostname} -> {ip_address} (TTL: {ttl}s)", xbmc.LOGDEBUG)
                        return ip_address
            
            xbmc.log(f"Registro A não encontrado para {hostname} na resposta DoH", xbmc.LOGWARNING)
            return hostname
            
        except requests.exceptions.RequestException as e:
            xbmc.log(f"Erro de requisição ao resolver {hostname} via DoH: {e}", xbmc.LOGERROR)
        except ValueError as e: # Erro ao decodificar JSON
            xbmc.log(f"Resposta JSON inválida ao resolver {hostname} via DoH: {e}", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"Erro inesperado ao resolver {hostname} via DoH: {e}", xbmc.LOGERROR)
            
        return hostname

# ---------------- CONFIGURAÇÃO DO PROXY ----------------
@dataclass(frozen=True)
class ProxyConfig:
    max_retries: int = 3
    retry_backoff_factor: float = 0.5
    connection_timeout: int = 15
    stream_timeout: float = 30
    # Configurações de buffer otimizadas
    chunk_size: int = 1024  # 1KB por chunk
    buffer_size: int = 50 * 1024  # 50KB de buffer total
    max_reconnect_attempts: int = 3  # Máximo de tentativas de reconexão
    default_headers: Dict[str, str] = field(default_factory=lambda: {
        'User-Agent': 'VLC/3.0.20 (Windows; x86_64)',
        'Accept': '*/*',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
        'Accept-Ranges': 'bytes',
    })
    verify_ssl: bool = False

# Lista de User-Agents para rotacionar
USER_AGENTS = [
    'VLC/3.0.20 (Windows; x86_64)',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Lavf/58.76.100',
    'AppleCoreMedia/1.0.0.19H524 (Apple TV; U; CPU OS 15_5 like Mac OS X; en_us)',
    'curl/7.68.0',
]

# ---------------- VARIÁVEIS GLOBAIS ----------------
PROXY_CONFIG = ProxyConfig()
PROXY_MANAGER = None
DOH_RESOLVER = DOHResolver()

# ---------------- FUNÇÕES AUXILIARES ----------------
def create_session(user_agent: str = None) -> requests.Session:
    """Cria uma sessão de requisições com retentativas configuradas."""
    session = requests.Session()
    retry_strategy = Retry(
        total=PROXY_CONFIG.max_retries,
        backoff_factor=PROXY_CONFIG.retry_backoff_factor,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    
    # Desativa completamente a verificação SSL e avisos
    session.verify = False
    warnings.filterwarnings('ignore', 'Unverified HTTPS request')
    
    # Configurações adicionais para melhor performance
    session.stream = True
    session.trust_env = False
    
    # Usar User-Agent específico ou padrão
    if user_agent:
        session.headers.update({'User-Agent': user_agent})
    
    return session

def get_random_user_agent() -> str:
    """Retorna um User-Agent aleatório da lista"""
    return random.choice(USER_AGENTS)

def process_m3u8_content(content: str, final_url: str) -> str:
    """Processa o conteúdo M3U8 para reescrever URLs através do proxy."""
    lines = content.split('\n')
    processed_lines = []
    
    if '#EXT-X-KEY' in content:
        xbmc.log("Manifesto M3U8 contém chave de criptografia (EXT-X-KEY).", xbmc.LOGINFO)
    
    parsed_url = urllib.parse.urlparse(final_url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
    base_path = final_url.rsplit('/', 1)[0]
    
    for line in lines:
        stripped_line = line.strip()
        if not stripped_line:
            processed_lines.append(line)
            continue

        if stripped_line.startswith('#EXT-X-KEY'):
            uri_pos = stripped_line.find('URI="')
            if uri_pos != -1:
                quote_start = uri_pos + 5
                quote_end = stripped_line.find('"', quote_start)
                key_uri = stripped_line[quote_start:quote_end]
                
                if key_uri.startswith('http'):
                    absolute_key_url = key_uri
                elif key_uri.startswith('/'):
                    absolute_key_url = base_url + key_uri
                else:
                    absolute_key_url = f"{base_path}/{key_uri}"
                
                proxied_key_url = PROXY_MANAGER.get_proxy_url(absolute_key_url)
                new_key_line = f'{stripped_line[:quote_start]}{proxied_key_url}{stripped_line[quote_end:]}'
                processed_lines.append(new_key_line)
            else:
                 processed_lines.append(line)
        elif stripped_line.startswith('#'):
             processed_lines.append(line)
        else:
            if stripped_line.startswith('http'):
                absolute_url = stripped_line
            elif stripped_line.startswith('/'):
                absolute_url = base_url + stripped_line
            else:
                absolute_url = f"{base_path}/{stripped_line}"
            
            proxy_url = PROXY_MANAGER.get_proxy_url(absolute_url)
            processed_lines.append(proxy_url if proxy_url else line)
            
    return '\n'.join(processed_lines)

# ---------------- GERENCIADOR DO PROXY ----------------
class HLSProxyManager:
    def __init__(self):
        self._server = None
        self._thread: Optional[threading.Thread] = None
        self._port: Optional[int] = None
        self._lock = threading.Lock()
        self._session_stats = {}  # Estatísticas de sessão por URL

    def start(self, port_range: Tuple[int, int] = (15000, 15099)) -> bool:
        with self._lock:
            if self._server: return True
            for port in range(port_range[0], port_range[1] + 1):
                try:
                    self._port = port
                    self._server = ThreadedHTTPServer(('127.0.0.1', port), ProxyHandler)
                    self._thread = threading.Thread(target=self._run_server, name="HLSProxyThread")
                    self._thread.daemon = True
                    self._thread.start()
                    time.sleep(0.5)
                    xbmc.log(f"HLS Proxy iniciado com sucesso na porta {self._port}", xbmc.LOGINFO)
                    xbmc.log(f"Configuração: chunk_size={PROXY_CONFIG.chunk_size}KB, buffer_size={PROXY_CONFIG.buffer_size}KB", xbmc.LOGINFO)
                    return True
                except OSError: continue
                except Exception as e:
                    xbmc.log(f"Erro crítico ao iniciar o proxy: {e}", xbmc.LOGERROR, exc_info=True)
                    return False
            xbmc.log(f"Não foi possível encontrar porta livre no range {port_range}", xbmc.LOGERROR)
            return False

    def _run_server(self):
        if not self._server: return
        try:
            self._server.serve_forever()
        except Exception as e:
            xbmc.log(f"Erro fatal no servidor proxy: {e}", xbmc.LOGERROR, exc_info=True)
        finally:
            self._server.server_close()

    def stop(self):
        if self._server:
            try:
                self._server.shutdown()
                self._server.server_close()
            except:
                pass
            self._server = None

    def get_proxy_url(self, target_url: str) -> Optional[str]:
        if not self._port: 
            xbmc.log("Proxy não inicializado", xbmc.LOGERROR)
            return None
        return f"http://127.0.0.1:{self._port}/?url={urllib.parse.quote_plus(target_url)}"

    def convert_to_m3u8(self, url):
        """Converte URLs não padrão para formato M3U8"""
        if '|' in url:
            url = url.split('|')[0]
        elif '%7C' in url:
            url = url.split('%7C')[0]
        if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
            parsed_url = urlparse(url)
            try:
                host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                url = host_part1 + '/live' + host_part2
                file = os.path.basename(url)
                if '.ts' in file:
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                else:
                    url = url + '.m3u8'
            except:
                pass
        return url

# ---------------- SERVIDOR HTTP ----------------
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Servidor HTTP com suporte a threading"""
    daemon_threads = True
    allow_reuse_address = True
    
    # Aumentar o tamanho do buffer do socket
    socket_buffer_size = PROXY_CONFIG.buffer_size

class ProxyHandler(BaseHTTPRequestHandler):
    """Handler para requisições do proxy"""
    
    # Configurar timeout para evitar conexões penduradas
    timeout = 30
    
    def log_message(self, format, *args):
        """Sobrescreve para usar o log do Kodi"""
        xbmc.log(f"Proxy: {format % args}", xbmc.LOGDEBUG)
    
    def do_GET(self):
        self.handle_request()
    
    def do_HEAD(self):
        self.handle_request()
    
    def handle_request(self):
        """Processa a requisição HTTP com buffer otimizado e reconexão automática"""
        try:
            # Extrair a URL do parâmetro 'url'
            parsed_path = urllib.parse.urlparse(self.path)
            query_params = urllib.parse.parse_qs(parsed_path.query)
            
            if 'url' not in query_params:
                self.send_error(400, "URL não especificada")
                return
            
            encoded_url = query_params['url'][0]
            target_url = urllib.parse.unquote_plus(encoded_url)
            
            # Aplicar conversão para M3U8 se necessário
            target_url = PROXY_MANAGER.convert_to_m3u8(target_url)
            
            xbmc.log(f"Proxying request to: {target_url}", xbmc.LOGDEBUG)
            
            # Verificar se é um manifesto M3U8 ou um segmento
            is_manifest = '.m3u8' in target_url.lower()
            
            # Tentar processar a requisição com reconexão se necessário
            response = self._process_with_retry(target_url, is_manifest)
            
            if response is None:
                self.send_error(502, "Falha após todas as tentativas")
                return
            
            # Enviar resposta
            self.send_response(response.status_code)
            
            # Copiar headers, excluindo os problemáticos
            excluded_headers = ['connection', 'keep-alive', 'proxy-authenticate', 
                              'proxy-authorization', 'te', 'trailers', 'transfer-encoding', 'upgrade',
                              'content-encoding']
            for key, value in response.headers.items():
                if key.lower() not in excluded_headers:
                    self.send_header(key, value)
            
            self.end_headers()
            
            # Se for HEAD, não enviamos o corpo
            if self.command == 'HEAD':
                response.close()
                return
            
            # Processar conteúdo
            content_type = response.headers.get('content-type', '').lower()
            is_m3u8 = '.m3u8' in response.url.lower() or 'mpegurl' in content_type
            
            if is_m3u8:
                # Processar M3U8
                content = response.text
                processed_content = process_m3u8_content(content, response.url)
                self.wfile.write(processed_content.encode('utf-8'))
            else:
                # Streaming de conteúdo binário com buffer otimizado
                try:
                    buffer = io.BytesIO()
                    bytes_sent = 0
                    
                    for chunk in response.iter_content(chunk_size=PROXY_CONFIG.chunk_size):
                        if chunk:
                            buffer.write(chunk)
                            bytes_sent += len(chunk)
                            
                            # Enviar buffer quando atingir o tamanho máximo
                            if buffer.tell() >= PROXY_CONFIG.buffer_size:
                                try:
                                    self.wfile.write(buffer.getvalue())
                                    self.wfile.flush()
                                    buffer.seek(0)
                                    buffer.truncate()
                                except (ConnectionResetError, BrokenPipeError):
                                    xbmc.log("Cliente fechou a conexão durante o streaming", xbmc.LOGDEBUG)
                                    break
                    
                    # Enviar qualquer dado restante no buffer
                    if buffer.tell() > 0:
                        try:
                            self.wfile.write(buffer.getvalue())
                            self.wfile.flush()
                        except (ConnectionResetError, BrokenPipeError):
                            xbmc.log("Cliente fechou a conexão no final do streaming", xbmc.LOGDEBUG)
                    
                    xbmc.log(f"Streaming concluído. Bytes enviados: {bytes_sent}", xbmc.LOGDEBUG)
                    
                except Exception as e:
                    xbmc.log(f"Erro durante o streaming: {e}", xbmc.LOGDEBUG)
            
            response.close()
            
        except requests.exceptions.Timeout:
            xbmc.log(f"Timeout no proxy para {target_url}", xbmc.LOGERROR)
            self.send_error(504, "Timeout")
        except requests.exceptions.ConnectionError:
            xbmc.log(f"Erro de conexão no proxy para {target_url}", xbmc.LOGERROR)
            self.send_error(502, "Erro de conexão")
        except Exception as e:
            xbmc.log(f"Erro no proxy: {e}", xbmc.LOGERROR)
            self.send_error(500, str(e))
    
    def _process_with_retry(self, target_url: str, is_manifest: bool):
        """Processa a requisição com reconexão automática e troca de User-Agent"""
        attempt = 0
        last_error = None
        resolved_ip = None # Variável para armazenar o IP resolvido
        
        # Extrai o hostname da URL para resolução DNS
        parsed_url = urllib.parse.urlparse(target_url)
        hostname = parsed_url.hostname
        original_url = target_url
        
        # Resolve o hostname usando DoH
        if hostname:
            resolved_ip = DOH_RESOLVER.resolve(hostname)
            if resolved_ip != hostname:
                # Substitui o hostname pelo IP resolvido
                target_url = target_url.replace(hostname, resolved_ip)
                xbmc.log(f"URL atualizada com IP resolvido: {target_url}", xbmc.LOGDEBUG)
        
        while attempt < PROXY_CONFIG.max_reconnect_attempts:
            try:
                # Para cada tentativa, usar um User-Agent diferente
                user_agent = get_random_user_agent()
                xbmc.log(f"Tentativa {attempt + 1}/{PROXY_CONFIG.max_reconnect_attempts} com User-Agent: {user_agent}", xbmc.LOGDEBUG)
                
                # Criar nova sessão com User-Agent específico
                session = create_session(user_agent)
                
                # Preparar headers
                headers = PROXY_CONFIG.default_headers.copy()
                headers['User-Agent'] = user_agent
                
                # Adicionar o header Host original se substituirmos por IP
                if hostname and resolved_ip != hostname:
                    headers['Host'] = hostname
                
                # Adicionar headers da requisição original, exceto os problemáticos
                for key, value in self.headers.items():
                    key_lower = key.lower()
                    if key_lower not in ['host', 'connection', 'accept-encoding', 'user-agent']:
                        headers[key] = value
                
                # Adicionar Referer se não existir
                if 'Referer' not in headers:
                    parsed_target = urllib.parse.urlparse(original_url)
                    referer = f"{parsed_target.scheme}://{parsed_target.netloc}/"
                    headers['Referer'] = referer
                
                # Se for um manifesto e não for a primeira tentativa, forçar recarregamento
                if is_manifest and attempt > 0:
                    headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
                    headers['Pragma'] = 'no-cache'
                
                # Fazer a requisição
                response = session.request(
                    method=self.command,
                    url=target_url,
                    headers=headers,
                    timeout=(PROXY_CONFIG.connection_timeout, PROXY_CONFIG.stream_timeout),
                    stream=True,
                    verify=False,
                    allow_redirects=True
                )
                
                # Se chegou aqui, a requisição foi bem sucedida
                xbmc.log(f"Requisição bem sucedida na tentativa {attempt + 1}", xbmc.LOGDEBUG)
                return response
                
            except Exception as e:
                last_error = e
                xbmc.log(f"Erro na tentativa {attempt + 1}: {e}", xbmc.LOGDEBUG)
                attempt += 1
                
                # Se não for a última tentativa, esperar antes de tentar novamente
                if attempt < PROXY_CONFIG.max_reconnect_attempts:
                    wait_time = 2 ** attempt  # Backoff exponencial
                    xbmc.log(f"Aguardando {wait_time} segundos antes da próxima tentativa...", xbmc.LOGDEBUG)
                    time.sleep(wait_time)
        
        # Se chegou aqui, todas as tentativas falharam
        xbmc.log(f"Todas as {PROXY_CONFIG.max_reconnect_attempts} tentativas falharam. Último erro: {last_error}", xbmc.LOGERROR)
        return None

# ---------------- ADDON PRINCIPAL ----------------
class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle

    def play_stream(self, url: str, title: str = ''):
        global PROXY_MANAGER
        if not PROXY_MANAGER:
            PROXY_MANAGER = HLSProxyManager()
            if not PROXY_MANAGER.start():
                xbmcgui.Dialog().notification("Erro de Proxy", "Falha ao iniciar o servidor proxy HLS.", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(self.handle, succeeded=False)
                return
        
        # Aplicar conversão para M3U8 se necessário
        url = PROXY_MANAGER.convert_to_m3u8(url)
        
        proxy_url = PROXY_MANAGER.get_proxy_url(url)
        if not proxy_url:
            xbmcgui.Dialog().notification("Erro de Proxy", "Não foi possível gerar a URL do proxy.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        xbmc.log(f"URL Proxy   : {proxy_url}", xbmc.LOGINFO)
        
        # Cria o ListItem. Se um título for fornecido, ele será usado.
        # Caso contrário, o título será em branco para que o Kodi possa ler o título original do stream.
        li = xbmcgui.ListItem(label=title, path=proxy_url)
        
        # Se um título foi fornecido, define-o também na InfoTag
        if title:
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(title)
            
        li.setProperty('IsPlayable', 'true')
        
        xbmcplugin.setResolvedUrl(self.handle, True, li)
        xbmc.log("Item enviado para reprodução via proxy.", xbmc.LOGINFO)

# ---------------- PONTO DE ENTRADA ----------------
if __name__ == '__main__':
    handle = -1
    try:
        handle = int(sys.argv[1])
        raw_args = sys.argv[2][1:] if len(sys.argv) > 2 else ''
        args = urllib.parse.parse_qs(raw_args)
        
        action = args.get('action', [None])[0]
        url = args.get('url', [None])[0]
        
        if action == 'play' and url:
            # Pega o título dos argumentos, mas não usa mais um padrão fixo.
            # Se não for fornecido, será uma string vazia.
            title = args.get('title', [''])[0]
            addon = HLSProxyAddon(handle)
            addon.play_stream(url, title)
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            
    except Exception as e:
        xbmc.log(f"Erro fatal no addon: {e}", xbmc.LOGERROR, exc_info=True)
        if handle != -1:
            xbmcplugin.endOfDirectory(handle, succeeded=False)