# hlsretry.py (versão aprimorada)
# -*- coding: utf-8 -*-
import os
import threading
import time
import logging
import re
from queue import Queue, Empty
from collections import deque
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, quote, unquote, urljoin, quote_plus
from typing import Dict, Any, Deque, Optional, Tuple

import requests

# --- Configuração de Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(threadName)s - %(message)s')
logger = logging.getLogger(__name__)

def log(msg: str):
    logger.info(msg)

# --- Classe de Configuração ---
class Config:
    """Centraliza todas as configurações ajustáveis do proxy."""
    HOST_NAME: str = '127.0.0.1'
    PORT_NUMBER: int = 55894
    PREFETCH_WORKERS: int = 4  # Aumentado para mais agressividade na pré-busca
    TIMESHIFT_BUFFER_SIZE: int = 30  # Número de segmentos a manter em memória (buffer timeshift)
    PREFETCH_RETRY_COUNT: int = 3 # Número de tentativas para baixar um segmento
    PREFETCH_RETRY_DELAY: float = 0.5 # Segundos de espera entre as tentativas
    SEGMENT_FETCH_TIMEOUT: int = 10 # Timeout para baixar um segmento
    PLAYER_WAIT_TIMEOUT: float = 5.0 # Segundos que o player espera por um segmento do prefetcher

# --- URLs do Proxy (construídas a partir da Config) ---
url_proxy_base = f'http://{Config.HOST_NAME}:{Config.PORT_NUMBER}'
url_proxy = f'{url_proxy_base}/proxy_m3u8?url='
url_segment_proxy_prefix = f'{url_proxy_base}/proxy_segment/'
url_stop = f'{url_proxy_base}/stop'
url_reset = f'{url_proxy_base}/reset'
url_check = f'{url_proxy_base}/check'

# --- Classe de Estado Global ---
class ProxyState:
    """Encapsula o estado dinâmico do proxy para evitar o uso excessivo de 'global'."""
    def __init__(self):
        self.url_base: str = ''
        self.last_url: str = ''
        self.headers_base: Dict[str, str] = {}
        self.cache_m3u8: str = ''
        
        # O buffer de segmentos agora é um deque com tamanho máximo (timeshift buffer)
        self.segment_cache: Deque[Tuple[str, bytes]] = deque(maxlen=Config.TIMESHIFT_BUFFER_SIZE)
        self.segment_cache_map: Dict[str, bytes] = {} # Mapa para acesso rápido O(1)
        self.segment_cache_lock: threading.Lock = threading.Lock()
        
        self.prefetch_queue: Queue = Queue()
        self.prefetch_stop_event: threading.Event = threading.Event()
        self.stop_server_event: threading.Event = threading.Event()

    def reset(self):
        """Reseta o estado para uma nova sessão de streaming."""
        log("Resetting proxy state.")
        self.url_base = ''
        self.last_url = ''
        self.headers_base = {}
        self.cache_m3u8 = ''
        with self.segment_cache_lock:
            self.segment_cache.clear()
            self.segment_cache_map.clear()
        
        # Limpa a fila de pré-busca
        while not self.prefetch_queue.empty():
            try:
                self.prefetch_queue.get_nowait()
            except Empty:
                continue

# Instância única do estado
STATE = ProxyState()
REQUESTS_SESSION = requests.Session()

# --- Threads de Pré-busca (Prefetch) ---
class PrefetchThread(threading.Thread):
    """Worker que baixa segmentos de vídeo em segundo plano e os armazena no buffer."""
    def __init__(self):
        super().__init__(name=f"PrefetchWorker-{threading.active_count()}", daemon=True)
        log("Prefetch thread initialized.")

    def run(self):
        """Loop principal da thread: obtém URL da fila e baixa o segmento."""
        while not STATE.prefetch_stop_event.is_set():
            try:
                segment_url = STATE.prefetch_queue.get(timeout=1)
            except Empty:
                continue # Loop novamente para verificar o stop_event

            with STATE.segment_cache_lock:
                if segment_url in STATE.segment_cache_map:
                    STATE.prefetch_queue.task_done()
                    continue

            log(f"Prefetching segment: {segment_url}")
            content = self._fetch_segment_with_retries(segment_url)

            if content:
                with STATE.segment_cache_lock:
                    # Se o deque estiver cheio, a adição removerá o item mais antigo automaticamente
                    # Precisamos remover manualmente do nosso mapa de acesso rápido.
                    if len(STATE.segment_cache) == Config.TIMESHIFT_BUFFER_SIZE:
                        old_url, _ = STATE.segment_cache[0]
                        del STATE.segment_cache_map[old_url]

                    STATE.segment_cache.append((segment_url, content))
                    STATE.segment_cache_map[segment_url] = content
                log(f"Prefetched and cached: {segment_url} ({len(content) / 1024:.2f} KB). Buffer: {len(STATE.segment_cache)}/{Config.TIMESHIFT_BUFFER_SIZE}")
            
            STATE.prefetch_queue.task_done()

    def _fetch_segment_with_retries(self, url: str) -> Optional[bytes]:
        """Tenta baixar um segmento, com um número configurável de tentativas."""
        for attempt in range(Config.PREFETCH_RETRY_COUNT):
            try:
                r = REQUESTS_SESSION.get(url, headers=STATE.headers_base, stream=True, timeout=Config.SEGMENT_FETCH_TIMEOUT)
                r.raise_for_status()
                return r.content
            except requests.exceptions.RequestException as e:
                log(f"Error prefetching {url} on attempt {attempt + 1}: {e}")
                if attempt < Config.PREFETCH_RETRY_COUNT - 1:
                    time.sleep(Config.PREFETCH_RETRY_DELAY)
        log(f"Failed to prefetch {url} after {Config.PREFETCH_RETRY_COUNT} attempts.")
        return None

# --- Handler das Requisições HTTP ---
class ProxyHandler(BaseHTTPRequestHandler):
    """Lida com as requisições HTTP para o proxy, servindo M3U8 e segmentos."""

    def fetch_m3u8(self, url: str) -> Optional[Tuple[str, str]]:
        """Busca o conteúdo da playlist M3U8."""
        log(f"Fetching M3U8: {url} with headers: {STATE.headers_base}")
        try:
            r = REQUESTS_SESSION.get(url, headers=STATE.headers_base, timeout=10)
            r.raise_for_status()
            log(f"Successfully fetched M3U8 from {url}. Status: {r.status_code}")
            return r.text, r.url
        except requests.exceptions.RequestException as e:
            log(f"Error fetching M3U8 from {url}: {e}")
            return None

    def serve_segment_from_cache(self, url: str) -> Optional[bytes]:
        """
        Serve um segmento diretamente do cache. Se não estiver disponível,
        espera um pouco pelo prefetcher. NÃO baixa diretamente.
        """
        start_time = time.monotonic()
        while time.monotonic() - start_time < Config.PLAYER_WAIT_TIMEOUT:
            with STATE.segment_cache_lock:
                if url in STATE.segment_cache_map:
                    log(f"Serving segment from cache: {url}")
                    return STATE.segment_cache_map[url]
            # Espera um pouco para o prefetcher fazer seu trabalho
            time.sleep(0.1)

        log(f"TIMEOUT: Segment {url} not found in cache after {Config.PLAYER_WAIT_TIMEOUT}s.")
        return None

    def modify_m3u8_for_proxy(self, m3u8_content: str, base_url: str) -> str:
        """Modifica a playlist para apontar para o proxy e enfileira segmentos para pré-busca."""
        lines = m3u8_content.splitlines()
        modified_lines = []
        segment_urls_for_prefetch = []

        for line in lines:
            line_strip = line.strip()
            if not line_strip:
                continue
            
            if line_strip.startswith('#EXT-X-KEY'):
                key_match = re.search(r'URI="([^"]+)"', line)
                if key_match:
                    key_uri = key_match.group(1)
                    if not urlparse(key_uri).scheme: # URI relativa
                        absolute_key_uri = urljoin(base_url, key_uri)
                        line = line.replace(key_uri, absolute_key_uri)
                modified_lines.append(line)

            elif not line_strip.startswith('#'):
                segment_url = urljoin(base_url, line_strip)
                proxied_segment_url = f"{url_segment_proxy_prefix}{quote_plus(segment_url)}"
                modified_lines.append(proxied_segment_url)
                segment_urls_for_prefetch.append(segment_url)
            else:
                modified_lines.append(line)
        
        log(f"Queueing {len(segment_urls_for_prefetch)} segments for prefetch.")
        for url in segment_urls_for_prefetch:
            STATE.prefetch_queue.put(url)
        
        return "\n".join(modified_lines)

    def do_GET(self):
        """Lida com todas as requisições GET."""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query_params = parse_qs(parsed_path.query)

        if path == '/proxy_m3u8':
            self.handle_m3u8_request(query_params)
        elif path.startswith('/proxy_segment/'):
            self.handle_segment_request()
        elif path in ['/check', '/stop', '/reset']:
            self.handle_control_request(path)
        else:
            self.send_error(404, "Not Found")

    def handle_m3u8_request(self, query_params: Dict[str, Any]):
        """Processa um pedido para uma playlist M3U8."""
        url_to_fetch = query_params.get('url', [None])[0]
        if not url_to_fetch:
            self.send_error(400, "Missing 'url' parameter")
            return

        url_to_fetch = unquote_plus(url_to_fetch)
        
        # Extrai e armazena headers fornecidos na URL
        headers = {k: unquote_plus(v[0]) for k, v in query_params.items() if k != 'url'}
        if 'User-Agent' not in headers:
            headers['User-Agent'] = 'VLC/3.0.0' # Agente de usuário padrão
        STATE.headers_base = headers
        
        # Se a URL mudou, reseta o estado
        if url_to_fetch != STATE.last_url:
            STATE.reset()
            STATE.last_url = url_to_fetch
        
        result = self.fetch_m3u8(url_to_fetch)
        if result:
            m3u8_content, final_url = result
            STATE.url_base = os.path.dirname(final_url) + '/'
            modified_m3u8 = self.modify_m3u8_for_proxy(m3u8_content, STATE.url_base)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()
            self.wfile.write(modified_m3u8.encode('utf-8'))
        else:
            self.send_error(502, "Bad Gateway: Could not fetch M3U8")

    def handle_segment_request(self):
        """Processa um pedido para um segmento de vídeo."""
        try:
            encoded_segment_url = self.path[len('/proxy_segment/'):]
            segment_url = unquote_plus(encoded_segment_url)
        except Exception:
            self.send_error(400, "Invalid segment URL")
            return

        content = self.serve_segment_from_cache(segment_url)
        if content:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        else:
            self.send_error(404, "Segment not found in cache")
    
    def handle_control_request(self, path: str):
        """Lida com comandos de controle como /check, /stop, /reset."""
        self.send_response(200)
        self.end_headers()
        
        if path == '/stop':
            log("Stop command received. Initiating server shutdown.")
            STATE.stop_server_event.set()
        elif path == '/reset':
            log("Reset command received. Resetting state.")
            STATE.prefetch_stop_event.set() # Para threads antigas
            STATE.reset()
            STATE.prefetch_stop_event.clear() # Permite que novas threads iniciem
            # As threads serão reiniciadas pelo `Server.start()`
    
    def log_message(self, format: str, *args: Any):
        """Redireciona o log do servidor HTTP para o nosso logger."""
        logger.debug(f"{self.address_string()} - {args[0]} {args[1]}")

# --- Classe de Controle do Servidor ---
class Server:
    """Gerencia o ciclo de vida do servidor HTTP e das threads de pré-busca."""
    def __init__(self):
        self.server_thread = None
        self.prefetch_threads = []
        log("Server controller initialized.")

    def is_running(self) -> bool:
        """Verifica se o servidor proxy está em execução e respondendo."""
        try:
            r = requests.get(url_check, timeout=0.5)
            return r.status_code == 200
        except requests.exceptions.RequestException:
            return False

    def start(self):
        """Inicia o servidor proxy ou reseta seu estado se já estiver em uso."""
        if self.is_running():
            log("Server already running. Sending reset command.")
            try:
                requests.get(url_reset, timeout=2)
                # Reinicia as threads de prefetch do lado do cliente
                self._start_prefetch_workers()
            except requests.exceptions.RequestException as e:
                log(f"Failed to send reset command to existing server: {e}")
            return
        
        log("Starting new server instance.")
        STATE.stop_server_event.clear()
        
        self.server_thread = threading.Thread(target=self._run_server, daemon=True, name="WebServerThread")
        self.server_thread.start()
        
        # Espera o servidor iniciar de forma confiável
        start_time = time.monotonic()
        while not self.is_running():
            time.sleep(0.1)
            if time.monotonic() - start_time > 5:
                log("FATAL: Server failed to start within 5 seconds.")
                return
        
        log("Server started successfully.")

    def _run_server(self):
        """Método executado na thread do servidor."""
        with HTTPServer((Config.HOST_NAME, Config.PORT_NUMBER), ProxyHandler) as httpd:
            log(f"HTTP server listening on {Config.HOST_NAME}:{Config.PORT_NUMBER}")
            
            # Inicia as threads de pré-busca
            self._start_prefetch_workers()

            # Loop principal do servidor
            while not STATE.stop_server_event.is_set():
                httpd.handle_request() # Processa uma única requisição
            
            log("Server shutdown signal received.")
        
        self._stop_prefetch_workers()
        log("HTTP server has been shut down.")

    def _start_prefetch_workers(self):
        """Para quaisquer workers antigos e inicia novos."""
        self._stop_prefetch_workers() # Garante que os antigos parem
        STATE.prefetch_stop_event.clear()
        self.prefetch_threads = []
        for _ in range(Config.PREFETCH_WORKERS):
            thread = PrefetchThread()
            thread.start()
            self.prefetch_threads.append(thread)
        log(f"{len(self.prefetch_threads)} prefetch workers started.")

    def _stop_prefetch_workers(self):
        """Sinaliza e aguarda a finalização das threads de pré-busca."""
        if not self.prefetch_threads:
            return
        
        log("Stopping prefetch workers...")
        STATE.prefetch_stop_event.set()
        for thread in self.prefetch_threads:
            thread.join(timeout=2)
        self.prefetch_threads = []
        log("Prefetch workers stopped.")

    def stop(self):
        """Para o servidor proxy enviando um comando HTTP."""
        log("Attempting to stop proxy server...")
        try:
            requests.get(url_stop, timeout=2)
            log("Stop command sent successfully.")
        except requests.exceptions.RequestException as e:
            log(f"Failed to send stop command to proxy server: {e}")

# --- Funções de Utilitário para o Kodi ---
def get_hls_url(url: str, headers: Optional[Dict[str, str]] = None) -> str:
    """Constrói a URL proxyficada para playlists M3U8, incluindo headers."""
    final_headers = headers.copy() if headers else {}
    
    # Adicionar todos os headers como parâmetros de query
    encoded_url = quote_plus(url)
    params = [f"url={encoded_url}"]
    for key, value in final_headers.items():
        params.append(f"{quote_plus(key)}={quote_plus(value)}")
    
    proxied_url = f"{url_proxy_base}/proxy_m3u8?{'&'.join(params)}"
    log(f"Constructed proxied HLS URL: {proxied_url}")
    return proxied_url

def stop_all_proxies():
    """Tenta parar o servidor proxy."""
    server_controller.stop()

# --- Ponto de Entrada ---
# Instancia o controlador do servidor. Ele será gerenciado pelo seu plugin.
server_controller = Server()

# Exemplo de como usar (simulando o que um plugin do Kodi faria)
if __name__ == '__main__':
    log("--- INICIANDO TESTE LOCAL ---")
    
    # 1. Iniciar o servidor
    server_controller.start()

    # 2. Simular uma URL de HLS que o Kodi iria tocar
    # Substitua pela URL HLS que você quer testar
    test_hls_url = "URL_DA_SUA_LIVE_STREAM_HLS_AQUI" 
    test_headers = {'User-Agent': 'MinhaApp/1.0'}
    
    if "URL_DA_SUA_LIVE_STREAM_HLS_AQUI" in test_hls_url:
        log("Por favor, edite o script e substitua 'URL_DA_SUA_LIVE_STREAM_HLS_AQUI' por uma URL real para testar.")
    else:
        # 3. Obter a URL do proxy
        proxy_url_for_player = get_hls_url(test_hls_url, test_headers)
        print("\n\n")
        log(f">>> URL para colocar no seu player de vídeo (VLC, ffplay, etc.):")
        log(f">>> {proxy_url_for_player}")
        print("\n\n")

    log("O servidor está rodando. Pressione Ctrl+C para parar.")
    
    try:
        # Mantém o script principal vivo para o servidor continuar rodando em background
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        log("Ctrl+C pressionado. Desligando o servidor.")
        # 4. Parar o servidor
        server_controller.stop()
        # Espera um pouco para a thread do servidor terminar
        time.sleep(2)
        log("--- TESTE LOCAL FINALIZADO ---")