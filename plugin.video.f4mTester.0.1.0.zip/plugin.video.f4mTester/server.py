import six
import os
import threading
import socket
import requests
import time
import json
import collections
import re
from datetime import datetime, timedelta

try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode  # Python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # Python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from SimpleHTTPServer import SimpleHTTPRequestHandler

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 65321
DOH_SERVER_URL = "https://cloudflare-dns.com/dns-query"
DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

# Globais para estado do stream atual. Serão resetados para novos canais.
GLOBAL_HEADERS = {}
GLOBAL_URL = '' # Base URL para segmentos relativos

# Instância global do servidor para acesso externo e gerenciamento de parada
_media_server_instance = None # Será inicializado em __main__

# --- Novo: Gerenciamento de Buffer de Stream ---
class StreamBuffer:
    def __init__(self, max_segments=50): # Limite de segmentos na memória (ajustável)
        self.segments = collections.OrderedDict() # {segment_url: (data, timestamp)}
        self.max_segments = max_segments
        self.lock = threading.Lock()
        self.playlist_sequence = -1 # Para rastrear a sequência da playlist HLS
        self.segment_duration = 0 # Duração média dos segmentos para cálculo de timeshift

    def add_segment(self, url, data, timestamp=None):
        with self.lock:
            self.segments[url] = (data, timestamp if timestamp else time.time())
            if len(self.segments) > self.max_segments:
                # Remove o segmento mais antigo
                self.segments.popitem(last=False)
            # print(f"DEBUG: Segmento adicionado/atualizado no buffer: {url}")

    def get_segment(self, url):
        with self.lock:
            return self.segments.get(url)

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.playlist_sequence = -1
            self.segment_duration = 0
            print("INFO: Buffer de stream limpo.")

    def get_buffered_segment_urls(self):
        with self.lock:
            return list(self.segments.keys())

    def get_segment_by_timeshift(self, target_time):
        """
        Tenta encontrar um segmento no buffer que esteja próximo do target_time.
        target_time: timestamp (float) ou datetime object.
        """
        if isinstance(target_time, datetime):
            target_time = target_time.timestamp()

        with self.lock:
            # Encontra o segmento mais próximo ou anterior ao target_time
            best_match_url = None
            min_diff = float('inf')

            for url, (data, segment_ts) in reversed(self.segments.items()): # Busca dos mais recentes para os mais antigos
                if segment_ts is None:
                    continue # Não pode comparar sem timestamp

                diff = abs(target_time - segment_ts)
                if diff < min_diff:
                    min_diff = diff
                    best_match_url = url
                
                # Se o segmento atual é mais antigo que o target_time e a diferença está crescendo,
                # significa que já passamos do ponto ideal (assumindo segmentos ordenados por tempo)
                if segment_ts < target_time and diff > self.segment_duration * 1.5: # Um pouco além da duração do segmento
                    break # Podemos parar de procurar, não vamos encontrar algo melhor mais antigo

            if best_match_url:
                print(f"INFO: Timeshift: Encontrado segmento '{best_match_url}' com timestamp {self.segments[best_match_url][1]:.2f} para target {target_time:.2f} (diff {min_diff:.2f}s)")
                return self.segments[best_match_url]
            else:
                print(f"AVISO: Timeshift: Nenhum segmento encontrado no buffer para o tempo alvo {target_time:.2f}s.")
                return None


stream_buffer = StreamBuffer() # Instância global do buffer

# Cache para resultados DoH para reduzir requisições repetidas
doh_cache = collections.OrderedDict()
DOH_CACHE_MAX_SIZE = 100
DOH_CACHE_TTL = 300 # 5 minutos de TTL

def query_doh(domain, record_type="A", doh_server=DOH_SERVER_URL):
    """Resolve um domínio usando DNS over HTTPS e retorna o endereço IP, com caching."""
    # Verifica o cache primeiro
    if domain in doh_cache:
        ip, timestamp = doh_cache[domain]
        if (time.time() - timestamp) < DOH_CACHE_TTL:
            # print(f"INFO: Usando DoH cache para {domain}: {ip}")
            return ip
        else:
            # print(f"INFO: Cache DoH expirado para {domain}")
            doh_cache.pop(domain) # Remove item expirado

    headers = {
        "Accept": "application/dns-json",
        "User-Agent": DEFAULT_USER_AGENT
    }
    params = {
        "name": domain,
        "type": record_type
    }
    
    try:
        response = requests.get(doh_server, headers=headers, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        if "Answer" in data:
            for answer in data["Answer"]:
                if answer["type"] == 1:  # Type 1 is A record
                    ip = answer["data"]
                    # Adiciona ao cache
                    doh_cache[domain] = (ip, time.time())
                    if len(doh_cache) > DOH_CACHE_MAX_SIZE:
                        doh_cache.popitem(last=False) # Remove o mais antigo
                    return ip
        print(f"Nenhum registro A encontrado para {domain} via DoH.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Falha na resolução DoH para {domain}: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"Erro ao decodificar JSON da resposta DoH para {domain}: {e}")
        return None

class Handler(SimpleHTTPRequestHandler):
    def log_message(format, *args):
        pass

    def _reset_stream_state(self):
        """Reseta o estado global para um novo stream."""
        global GLOBAL_HEADERS, GLOBAL_URL
        print("INFO: Resetando estado do stream global (headers e base URL).")
        GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}
        GLOBAL_URL = ''
        stream_buffer.clear() # Limpa o buffer ao mudar de canal

    def _get_parsed_url_param(self):
        """Extrai e decodifica o parâmetro 'url' do caminho da requisição."""
        try:
            # Usar parse_qs para lidar corretamente com múltiplos parâmetros na query string
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            
            raw_param = query_params.get('url', [None])[0]
            if raw_param:
                # Decodificar em etapas pode ser mais robusto para URLs duplamente codificadas
                decoded_param = unquote_plus(raw_param)
                decoded_param = unquote(decoded_param) # Adicional para casos sem o '+'
                return decoded_param
            return None
        except Exception as e:
            print(f"Erro ao decodificar parâmetro URL '{self.path}': {e}")
            return None

    def _get_timeshift_param(self):
        """Extrai o parâmetro 'timeshift' do caminho da requisição."""
        try:
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            timeshift_str = query_params.get('timeshift', [None])[0]
            if timeshift_str:
                return int(timeshift_str)
            return 0 # Padrão: sem timeshift
        except (ValueError, TypeError):
            return 0
        except Exception as e:
            print(f"Erro ao extrair parâmetro timeshift: {e}")
            return 0


    def get_headers_from_url_params(self, url_with_params):
        """
        Extrai cabeçalhos (Referer, Origin, Cookie) de uma string de URL que os contém como parâmetros.
        Retorna um dicionário com os cabeçalhos extraídos.
        """
        custom_headers = {}
        # Tenta extrair 'url=' para isolar os parâmetros de cabeçalho, se estiverem no valor do parâmetro 'url'
        try:
            # A URL real pode estar antes dos parâmetros de cabeçalho, ou os parâmetros podem estar sozinhos
            param_part = url_with_params
            
            # Verifica se os delimitadores de cabeçalho customizados estão presentes
            if '|' in param_part or '&h123' in param_part or any(k+'=' in param_part for k in ['Referer', 'Origin', 'Cookie']):
                # Se a URL_com_params contiver o realce, a query string deve ser extraída da parte APÓS a URL real.
                # A lógica abaixo assume que headers são adicionados como query params.
                # Ex: http://stream.com/live.m3u8?key=val&Referer=http://site.com
                parsed_param_url = urlparse(f"http://dummy?{param_part.split('?',1)[-1] if '?' in param_part else param_part}")
                params_qs = parse_qs(parsed_param_url.query)

                referer = params_qs.get('Referer', [None])[0] or params_qs.get('referer', [None])[0]
                origin = params_qs.get('Origin', [None])[0] or params_qs.get('origin', [None])[0]
                cookie = params_qs.get('Cookie', [None])[0] or params_qs.get('cookie', [None])[0]

                if referer:
                    custom_headers['Referer'] = unquote_plus(referer)
                if origin:
                    custom_headers['Origin'] = unquote_plus(origin)
                if cookie:
                    custom_headers['Cookie'] = unquote_plus(cookie)
        except Exception as e:
            print(f"DEBUG: Erro ao parsear cabeçalhos de '{url_with_params}': {e}")

        return custom_headers

    def convert_to_m3u8_url(self, url):
        """Converte uma URL de stream genérica para uma URL .m3u8 se aplicável."""
        if '|' in url:
            url = url.split('|')[0]
        elif '&h123' in url:
            url = url.split('&h123')[0]

        is_potential_livestream_url = not ('.m3u8' in url or '/hl' in url or '.ts' in url) and \
                                      url.count(":") == 2 and url.count("/") > 4
        
        if is_potential_livestream_url:
            try:
                parsed_url = urlparse(url)
                base_path = f"{parsed_url.scheme}://{parsed_url.netloc}"
                path_segment = url.split(base_path, 1)[1]
                
                if not path_segment.startswith('/live/'):
                     path_segment = '/live' + path_segment

                new_url = base_path + path_segment
                
                if os.path.splitext(new_url)[1] != '.ts':
                    filename = os.path.basename(new_url)
                    if '.' in filename:
                        new_filename = os.path.splitext(filename)[0] + '.m3u8'
                    else:
                        new_filename = filename + '.m3u8'
                    url = new_url.replace(filename, new_filename)
                else:
                    url = new_url.replace('.ts', '.m3u8')

                print(f"INFO: URL convertida para M3U8: {url}")
            except Exception as e:
                print(f"ERRO: Falha ao converter URL para M3U8 ({url}): {e}")
                pass
        return url

    def _make_request_with_doh(self, url, headers, stream=False, head=False, timeout=10):
        """Faz uma requisição HTTP(S), opcionalmente usando DoH e com retries."""
        parsed_original_url = urlparse(url)
        hostname = parsed_original_url.hostname
        
        ip = query_doh(hostname) if hostname else None
        
        req_url = url
        effective_headers = headers.copy()

        if ip:
            req_url = parsed_original_url._replace(netloc=ip).geturl()
            effective_headers["Host"] = hostname
            print(f"INFO: Usando IP {ip} (via DoH) para {hostname}. URL: {req_url}")
        else:
            print(f"AVISO: Falha ao resolver {hostname} via DoH ou hostname ausente. Usando DNS do sistema para {url}.")

        max_retries = 3
        for attempt in range(max_retries):
            try:
                if head:
                    response = requests.head(req_url, headers=effective_headers, timeout=timeout)
                else:
                    response = requests.get(req_url, headers=effective_headers, stream=stream, timeout=timeout)
                response.raise_for_status()
                return response
            except requests.exceptions.RequestException as e:
                print(f"ERRO na requisição para {req_url} (tentativa {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(0.5 * (attempt + 1))
                else:
                    raise

    def _handle_ts_request(self, target_url, current_headers):
        """Lida com requisições de segmentos .ts, buscando no buffer ou na origem."""
        global GLOBAL_URL

        # Tenta resolver a URL completa do segmento
        if not target_url.startswith('http') and GLOBAL_URL:
            # Combina GLOBAL_URL (base) com target_url (relativa)
            # handle 'segment.ts' and '/path/segment.ts'
            if target_url.startswith('/'):
                parsed_global = urlparse(GLOBAL_URL)
                full_url = f"{parsed_global.scheme}://{parsed_global.netloc}{target_url}"
            else:
                full_url = f"{GLOBAL_URL}/{target_url}"
            # Limpa barras duplicadas
            full_url = re.sub(r'(?<!:)/{2,}', '/', full_url)
            print(f"INFO: Resolvendo URL relativa do TS: {target_url} -> {full_url}")
        else:
            full_url = target_url
        
        # --- NOVO: Tenta pegar do buffer primeiro ---
        buffered_data = stream_buffer.get_segment(full_url)
        if buffered_data:
            print(f"INFO: Servindo segmento TS do buffer: {full_url}")
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                self.wfile.write(buffered_data[0]) # Envia os dados do segmento
            except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                print(f"ERRO: Conexão interrompida ao enviar TS do buffer: {e}")
            return # Segmento servido do buffer

        print(f"INFO: Segmento TS não encontrado no buffer, buscando na origem: {full_url}")
        try:
            r = self._make_request_with_doh(full_url, current_headers, stream=True)
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            segment_data = b''
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    segment_data += chunk
                    try:
                        self.wfile.write(chunk)
                    except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                        print(f"ERRO: Conexão interrompida ao enviar TS: {e}")
                        break
            r.close()
            # Adiciona o segmento recém-baixado ao buffer
            stream_buffer.add_segment(full_url, segment_data, time.time())
        except requests.exceptions.RequestException as e:
            print(f"ERRO: Falha ao buscar segmento TS {full_url}: {e}")
            self.send_error(404, f"Falha ao buscar TS: {e}")
        except Exception as e:
            print(f"ERRO inesperado ao processar TS {full_url}: {e}")
            self.send_error(500, f"Erro interno ao processar TS: {e}")

    def _handle_m3u8_request(self, target_url, current_headers):
        """Lida com requisições de playlists .m3u8, aplicando timeshift se solicitado."""
        global GLOBAL_URL

        timeshift_seconds = self._get_timeshift_param()
        if timeshift_seconds > 0:
            print(f"INFO: Timeshift de {timeshift_seconds} segundos solicitado para {target_url}")

        try:
            r = self._make_request_with_doh(target_url, current_headers, timeout=10)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            playlist_content = r.text
            
            parsed_response_url = urlparse(r.url)
            
            # Tenta obter o caminho base da URL do M3U8
            path_parts = parsed_response_url.path.split('/')
            if len(path_parts) > 1 and ('.' in path_parts[-1] or path_parts[-1] == ''):
                base_path_for_segments = '/'.join(path_parts[:-1])
            else:
                base_path_for_segments = parsed_response_url.path

            if not base_path_for_segments.startswith('/'):
                 base_path_for_segments = '/' + base_path_for_segments
            if len(base_path_for_segments) > 1 and base_path_for_segments.endswith('/'):
                 base_path_for_segments = base_path_for_segments[:-1]
            
            GLOBAL_URL = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{base_path_for_segments}"
            print(f"INFO: GLOBAL_URL base para segmentos definida como: {GLOBAL_URL}")

            processed_lines = []
            current_segment_duration = 0.0
            media_sequence_found = False
            first_media_sequence = -1 # Para rastrear o primeiro MS da playlist original

            lines = playlist_content.splitlines()
            for i, line in enumerate(lines):
                line = line.strip()
                if not line:
                    continue

                if line.startswith('#EXTINF:'):
                    try:
                        duration_match = re.search(r'#EXTINF:([\d.]+),', line)
                        if duration_match:
                            current_segment_duration = float(duration_match.group(1))
                            if stream_buffer.segment_duration == 0:
                                stream_buffer.segment_duration = current_segment_duration
                    except ValueError:
                        pass # Ignora erro de parsing de duração
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                    # Captura a sequência de mídia atual da playlist
                    try:
                        seq = int(line.split(':')[1])
                        if not media_sequence_found:
                            first_media_sequence = seq
                            media_sequence_found = True
                        processed_lines.append(line) # Mantém a linha original por enquanto
                    except ValueError:
                        processed_lines.append(line)
                elif line.startswith('#EXT-X-TARGETDURATION:'):
                    # Captura a target duration
                    try:
                        td = int(line.split(':')[1])
                        if stream_buffer.segment_duration == 0:
                            stream_buffer.segment_duration = float(td)
                    except ValueError:
                        pass
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-KEY'):
                    if 'URI="' in line and not '://' in line.split('URI="')[1].split('"')[0]:
                        key_uri_part = line.split('URI="')[1].split('"')[0]
                        if key_uri_part.startswith('/'):
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={parsed_response_url.scheme}://{parsed_response_url.netloc}{key_uri_part}"
                        else:
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={GLOBAL_URL}/{key_uri_part}"
                        line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri}"')
                        print(f"INFO: Chave URI proxyada: {line}")
                    processed_lines.append(line)
                elif line.startswith('#'):
                    processed_lines.append(line)
                else: # Linha é um segmento de mídia (geralmente .ts)
                    # Constrói a URL original completa do segmento
                    full_original_segment_url = ""
                    if line.startswith('http://') or line.startswith('https://'):
                        full_original_segment_url = line
                    elif line.startswith('/'):
                        full_original_segment_url = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{line}"
                    else:
                        full_original_segment_url = f"{GLOBAL_URL}/{line}"
                    
                    # --- NOVO: Lógica de Timeshift para a playlist ---
                    # Se timeshift_seconds > 0, precisamos ajustar a playlist.
                    # Isso é MUITO simplificado e pode não funcionar perfeitamente para todos os streams HLS.
                    # A ideia é "backtrack" na playlist com base no tempo de segmento.
                    if timeshift_seconds > 0 and stream_buffer.segment_duration > 0 and first_media_sequence != -1:
                        # Estima quantos segmentos precisamos retroceder
                        num_segments_to_backtrack = int(timeshift_seconds / stream_buffer.segment_duration)
                        adjusted_sequence = first_media_sequence - num_segments_to_backtrack
                        
                        # A maneira ideal de fazer timeshift é ter acesso a um índice de segmentos bufferizados
                        # e ajustar a MEDIA-SEQUENCE e a lista de URLs de segmentos para o ponto no tempo.
                        # Esta implementação atual apenas reescreve a playlist do servidor original.
                        # Para um timeshift real, precisaríamos de uma playlist *gerada* a partir do buffer.

                        # Para o POC, vamos reescrever a URL do segmento para apontar para o nosso proxy
                        # com o timeshift no caminho (que será ignorado para o segmento em si,
                        # mas serve para indicar a intenção do cliente).
                        
                        # O timeshift será aplicado mais na seleção do segmento pelo cliente, se ele entender o `start_time`
                        # ou se o proxy reescrever a playlist dinamicamente.
                        # A forma mais simples de "timeshift" aqui é forçar o cliente a buscar um segmento mais antigo
                        # se o buffer o tiver.
                        # No entanto, HLS players esperam uma playlist com MEDIA-SEQUENCE crescente.
                        # Reescrever a playlist é mais complexo.

                        # Vamos apenas proxyar o segmento, e o timeshift será uma requisição posterior do player.
                        # A ideia de timeshift na playlist M3U8 é mais complexa e envolve gerar uma nova playlist
                        # com uma MEDIA-SEQUENCE e URLs de segmentos que refletem o ponto de timeshift.
                        # Por enquanto, mantemos o proxy simples para o segmento.
                        pass # Timeshift não afeta diretamente a reescrita de URL aqui para o segmento individual

                    # Proxyar a URL do segmento
                    proxied_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(full_original_segment_url)}"
                    processed_lines.append(proxied_url)
            
            # --- NOVO: Ajuste de MEDIA-SEQUENCE para Timeshift (Experimental) ---
            # Se um timeshift foi solicitado, tentamos ajustar a MEDIA-SEQUENCE na playlist.
            # Isso é uma heurística e pode não funcionar para todos os players ou streams.
            # Um HLS player robusto deve solicitar a playlist e depois os segmentos.
            # Nosso buffer pode ser usado para servir segmentos antigos.
            if timeshift_seconds > 0 and stream_buffer.segment_duration > 0 and media_sequence_found:
                num_segments_to_backtrack = int(timeshift_seconds / stream_buffer.segment_duration)
                
                # A nova MEDIA-SEQUENCE deve ser a sequência do segmento mais antigo que podemos servir
                # que ainda está no buffer, ajustada para trás.
                # Isso requer que o stream_buffer mantenha o controle de sequência.
                
                # Para simplificar, vamos tentar ajustar a MEDIA-SEQUENCE com base no tempo de retrocesso.
                # Isso pode fazer o player pular para o início do buffer.
                
                # Percorrer as linhas processadas para encontrar e ajustar MEDIA-SEQUENCE
                final_playlist_lines = []
                for line in processed_lines:
                    if line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                        current_seq = int(line.split(':')[1])
                        # Acha o primeiro segmento que estaria presente no buffer (se todos fossem adicionados)
                        # e ajusta a sequence para o ponto desejado de timeshift.
                        # Isso é uma simplificação. O ideal seria:
                        # 1. Pegar o timestamp atual do stream.
                        # 2. Calcular o timestamp desejado (atual - timeshift).
                        # 3. Encontrar a MEDIA-SEQUENCE correspondente ao timestamp desejado.
                        # Como não temos um index de tempo/sequência fácil, vamos retroceder por segmentos.
                        
                        # Se o buffer tiver segmentos, podemos pegar o mais antigo para estimar o "início" do timeshift
                        # ou usar a sequence atual menos o retrocesso.
                        
                        # WARNING: Esta lógica pode causar problemas de reprodução se a sequência for muito baixa
                        # ou se o player não conseguir encontrar os segmentos.
                        if stream_buffer.segments:
                            # Pega a sequência do segmento mais antigo no buffer
                            oldest_segment_url = list(stream_buffer.segments.keys())[0]
                            # Isso exige que saibamos a sequência real do segmento.
                            # Para simplificar, vamos apenas tentar reduzir a MEDIA-SEQUENCE.
                            
                            # Ajuste simples: apenas subtrair a quantidade de segmentos calculada
                            # Se o player pedir um segmento muito antigo, o _handle_ts_request vai para o buffer.
                            adjusted_seq = max(0, current_seq - num_segments_to_backtrack)
                            final_playlist_lines.append(f"#EXT-X-MEDIA-SEQUENCE:{adjusted_seq}")
                            print(f"INFO: MEDIA-SEQUENCE ajustada para {adjusted_seq} (timeshift {timeshift_seconds}s)")
                        else:
                            final_playlist_lines.append(line)
                    else:
                        final_playlist_lines.append(line)
                final_playlist = "\n".join(final_playlist_lines)
            else:
                final_playlist = "\n".join(processed_lines)

            self.wfile.write(final_playlist.encode("utf-8"))
            r.close()

        except requests.exceptions.RequestException as e:
            print(f"ERRO: Falha ao buscar M3U8 {target_url}: {e}")
            self.send_error(404, f"Falha ao buscar M3U8: {e}")
        except Exception as e:
            print(f"ERRO inesperado ao processar M3U8 {target_url}: {e}")
            self.send_error(500, f"Erro interno ao processar M3U8: {e}")

    def _handle_generic_request(self, target_url, current_headers):
        """Lida com requisições genéricas (ex: .html) como se fossem TS (tentativa de stream)."""
        print(f"AVISO: Lidando com requisição genérica {target_url} como se fosse TS.")
        self._handle_ts_request(target_url, current_headers)

    def _shutdown_server(self):
        """Agenda o desligamento do servidor."""
        print("INFO: Agendando desligamento do servidor...")
        # Agora chamamos a função de nível de módulo `req_shutdown`
        req_shutdown()

    def _process_request(self, method_is_head=False):
        """Lida com a lógica principal da requisição GET ou HEAD."""
        global GLOBAL_HEADERS, GLOBAL_URL

        original_path = self.path

        if original_path == '/check':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"OK")
            return
        elif original_path == '/stop':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"Stopping server...")
            self._shutdown_server() # Chama o método que invoca o req_shutdown global
            return
        elif original_path == '/buffer_info': # Novo endpoint para depuração
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            if method_is_head: return
            
            info = {
                "buffered_segments_count": len(stream_buffer.segments),
                "max_segments_capacity": stream_buffer.max_segments,
                "first_segment_url": list(stream_buffer.segments.keys())[0] if stream_buffer.segments else None,
                "last_segment_url": list(stream_buffer.segments.keys())[-1] if stream_buffer.segments else None,
                "global_url": GLOBAL_URL,
                "segment_duration": stream_buffer.segment_duration
            }
            self.wfile.write(json.dumps(info, indent=2).encode('utf-8'))
            return

        target_url_from_param = self._get_parsed_url_param()
        
        current_headers = GLOBAL_HEADERS.copy()

        if original_path.startswith('/?url=') and target_url_from_param:
            potential_m3u8_url = self.convert_to_m3u8_url(target_url_from_param)
            if '.m3u8' in potential_m3u8_url:
                print(f"INFO: Nova URL M3U8 principal detectada: {target_url_from_param}. Resetando estado.")
                self._reset_stream_state()
                current_headers = GLOBAL_HEADERS.copy()
            
            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
            
            if '|' in target_url_from_param or '&h123' in target_url_from_param:
                 target_url_for_fetching = target_url_from_param.split('|')[0].split('&h123')[0]
            else:
                 target_url_for_fetching = target_url_from_param
        elif target_url_from_param:
            target_url_for_fetching = target_url_from_param
            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
            if '|' in target_url_from_param or '&h123' in target_url_from_param:
                 target_url_for_fetching = target_url_from_param.split('|')[0].split('&h123')[0]
        else:
            target_url_for_fetching = original_path

        if target_url_for_fetching.startswith('http'):
            processed_target_url = self.convert_to_m3u8_url(target_url_for_fetching)
        else:
            processed_target_url = target_url_for_fetching
        
        if not processed_target_url.startswith('http') and not GLOBAL_URL and not original_path.startswith('/'):
            self.send_error(400, "URL base não definida para caminho relativo e sem parâmetro 'url'.")
            return

        if '.m3u8' in processed_target_url:
            print(f"DEBUG: Roteando para M3U8: {processed_target_url}")
            if method_is_head: self.send_response(200); self.send_header('Content-Type', 'application/vnd.apple.mpegurl'); self.end_headers(); return
            self._handle_m3u8_request(processed_target_url, current_headers)
        elif '.ts' in processed_target_url or ('/hl' in processed_target_url and not processed_target_url.endswith(".m3u8")):
            print(f"DEBUG: Roteando para TS: {processed_target_url}")
            if method_is_head: self.send_response(200); self.send_header('Content-type', 'video/mp2t'); self.end_headers(); return
            self._handle_ts_request(processed_target_url, current_headers)
        elif target_url_from_param and target_url_from_param.endswith(".html"):
            print(f"DEBUG: Roteando para genérico (original .html): {processed_target_url}")
            if method_is_head: self.send_response(200); self.end_headers(); return
            self._handle_generic_request(processed_target_url, current_headers)
        elif not target_url_from_param and ('.m3u8' in original_path or '.ts' in original_path):
            if '.m3u8' in original_path:
                print(f"DEBUG: Roteando para M3U8 (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-Type', 'application/vnd.apple.mpegurl'); self.end_headers(); return
                self._handle_m3u8_request(original_path, current_headers)
            elif '.ts' in original_path:
                print(f"DEBUG: Roteando para TS (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-type', 'video/mp2t'); self.end_headers(); return
                self._handle_ts_request(original_path, current_headers)
        else:
            if target_url_from_param:
                 print(f"AVISO: Tipo de URL não explicitamente tratado via ?url=: {target_url_from_param}. Tentando como genérico.")
                 if method_is_head: self.send_response(200); self.end_headers(); return
                 self._handle_generic_request(processed_target_url, current_headers)
            else:
                 print(f"ERRO: Path não reconhecido: {original_path}")
                 self.send_error(404, "Recurso não encontrado ou tipo não suportado.")

    def do_HEAD(self):
        self._process_request(method_is_head=True)
    
    def do_GET(self):
        self._process_request(method_is_head=False)

GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}

# Variável httpd é agora usada apenas internamente pelo MediaServer
httpd = None 

class MediaServer:
    def __init__(self):
        self.server_thread = None
        self.httpd_instance = None
        self._stop_event = threading.Event() # Evento para sinalizar parada

    def is_in_use(self):
        """Verifica se a porta do servidor está em uso."""
        if not self.httpd_instance or not self.server_thread or not self.server_thread.is_alive():
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.1)
            try:
                s.connect((HOST_NAME, PORT_NUMBER))
                s.close()
                if self.httpd_instance and self.server_thread and self.server_thread.is_alive():
                    return True
                print(f"AVISO: Porta {PORT_NUMBER} em uso, mas não pelo servidor gerenciado ou estado inconsistente.")
                return True
            except (socket.timeout, socket.error):
                return False
            finally:
                s.close()
        return True

    def start(self):
        global httpd # Referencia o global httpd para uso interno
        if not self.is_in_use():
            print("INFO: Iniciando servidor HTTP MediaServer...")
            self.httpd_instance = HTTPServer(('', PORT_NUMBER), Handler)
            httpd = self.httpd_instance # Atribui ao global httpd para ser usado pela _serve_forever_wrapper
            
            self.server_thread = threading.Thread(target=_serve_forever_wrapper, args=(self.httpd_instance, self._stop_event))
            self.server_thread.daemon = True
            self.server_thread.start()
            # Removido time.sleep(0.5)
            if self.server_thread.is_alive():
                print("INFO: MediaServer iniciado com sucesso.")
            else:
                print("ERRO: Falha ao iniciar MediaServer.")
                self.httpd_instance = None
                httpd = None
        else:
            print("INFO: MediaServer já está em execução ou a porta está ocupada.")

    def stop(self):
        """Para o servidor HTTP se estiver em execução."""
        global httpd # Referencia o global httpd
        print("INFO: Solicitando parada do MediaServer...")
        if self.httpd_instance:
            self._stop_event.set() # Sinaliza para o wrapper parar
            self.httpd_instance.shutdown() # Inicia o processo de desligamento
            self.httpd_instance.server_close()
            print("INFO: Aguardando thread do servidor finalizar...")
            if self.server_thread and self.server_thread.is_alive():
                 self.server_thread.join(timeout=5)
            if self.server_thread and not self.server_thread.is_alive():
                 print("INFO: Thread do servidor finalizada.")
            else:
                 print("AVISO: Timeout ao esperar thread do servidor, ou thread não encontrada.")

            self.httpd_instance = None
            httpd = None
            self.server_thread = None
            self._stop_event.clear() # Limpa o evento para próximo uso
            print("INFO: MediaServer parado.")
        else:
            print("INFO: MediaServer não estava em execução (instância httpd não encontrada).")
            # Tenta um shutdown "externo" via HTTP para casos de estado inconsistente
            try:
                requests.get(f'http://{HOST_NAME}:{PORT_NUMBER}/stop', timeout=0.5)
            except requests.exceptions.ConnectionError:
                pass # Se a conexão falhar, o servidor já pode estar parado ou inacessível

def _serve_forever_wrapper(server_instance, stop_event):
    """Wrapper para server_forever para facilitar o gerenciamento de threads."""
    try:
        print(f"INFO: Servidor HTTP iniciado em {HOST_NAME}:{PORT_NUMBER}")
        # server_instance.serve_forever() # substituído por loop com verificação de evento
        while not stop_event.is_set():
            server_instance.handle_request() # Processa uma requisição por vez
    except KeyboardInterrupt:
        print("\nINFO: Desligamento solicitado pelo usuário (KeyboardInterrupt).")
    except Exception as e:
        print(f"ERRO CRÍTICO: Falha no loop principal do servidor: {e}")
    finally:
        server_instance.server_close()
        print("INFO: Servidor HTTP finalizado.")

def req_shutdown():
    """Função de nível de módulo para solicitar o desligamento do servidor."""
    global _media_server_instance
    if _media_server_instance:
        print("INFO: req_shutdown() chamado. Solicitando parada do MediaServer.")
        _media_server_instance.stop()
    else:
        print("AVISO: req_shutdown() chamado, mas MediaServer não está ativo ou inicializado.")


def prepare_url(url_to_proxy, custom_headers_dict=None, timeshift_seconds=0):
    """
    Prepara a URL para ser usada com o servidor proxy local.
    Adiciona cabeçalhos customizados à URL de forma codificada e timeshift.
    """
    try:
        url_to_proxy = unquote_plus(url_to_proxy)
        url_to_proxy = unquote(url_to_proxy)
    except Exception as e:
        print(f"AVISO: Erro ao decodificar URL de entrada '{url_to_proxy}': {e}")

    parsed_original = urlparse(url_to_proxy)
    url_base_original = parsed_original._replace(query='', fragment='').geturl()
    
    combined_query_params = parse_qs(parsed_original.query) # Start with original query params

    if custom_headers_dict:
        for key, value in custom_headers_dict.items():
            combined_query_params[key] = [value] # Overwrite or add

    if timeshift_seconds > 0:
        combined_query_params['timeshift'] = [str(timeshift_seconds)]

    # Reconstruct the query string for the URL that will be the 'url' parameter value
    # Only if there are custom headers or timeshift to pass in the encoded 'url' value
    if custom_headers_dict or timeshift_seconds > 0:
        # Build query string from combined_query_params
        temp_query_list = []
        for key, values in combined_query_params.items():
            for value in values:
                temp_query_list.append(f"{quote_plus(key)}={quote_plus(value)}")
        
        if temp_query_list:
            effective_url_to_proxy = f"{url_base_original}?{'&'.join(temp_query_list)}"
        else:
            effective_url_to_proxy = url_base_original
    else:
        effective_url_to_proxy = url_to_proxy # No custom headers or timeshift, use original

    encoded_target_url = quote_plus(effective_url_to_proxy)
    
    final_proxy_url = f'http://{HOST_NAME}:{PORT_NUMBER}/?url={encoded_target_url}'
    return final_proxy_url


if __name__ == '__main__':
    _media_server_instance = MediaServer() # Atribui a instância à variável global
    _media_server_instance.start()

    # Exemplo de uso:
    test_m3u8_url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    proxied_url = prepare_url(test_m3u8_url)
    print(f"URL do Proxy para o cliente (VLC, Kodi): {proxied_url}")

    # Exemplo com timeshift de 60 segundos
    proxied_url_timeshift = prepare_url(test_m3u8_url, timeshift_seconds=60)
    print(f"URL do Proxy com Timeshift de 60s: {proxied_url_timeshift}")

    print(f"\nServidor rodando. Acesse http://{HOST_NAME}:{PORT_NUMBER}/check para verificar.")
    print(f"Para ver informações do buffer: http://{HOST_NAME}:{PORT_NUMBER}/buffer_info")
    print(f"Para parar o servidor, acesse http://{HOST_NAME}:{PORT_NUMBER}/stop ou pressione Ctrl+C.")

    try:
        # O thread principal espera passivamente o thread do servidor terminar.
        # Isso reduz drasticamente o uso de CPU quando o servidor está ocioso.
        if _media_server_instance.server_thread:
            _media_server_instance.server_thread.join()
    except KeyboardInterrupt:
        print("\nINFO: Interrupção de teclado no script principal. Parando o servidor...")
    finally:
        _media_server_instance.stop()
        print("INFO: Script principal finalizado.")