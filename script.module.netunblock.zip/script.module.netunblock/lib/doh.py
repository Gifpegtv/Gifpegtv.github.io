# -*- coding: utf-8 -*-
import socket
import sys
import logging
import requests
import random

addon_id = 'script.module.netunblock'
PY2 = sys.version_info[0] == 2
if PY2:
    from urlparse import urlparse
else:
    from urllib.parse import urlparse

logging.basicConfig(level=logging.DEBUG)
# Silencia logs do requests e urllib3
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

def get_doh_urls():
    """
    Retorna a lista de URLs DoH configuradas no ambiente.
    Se não estiver configurada, retorna a URL da Cloudflare por padrão.
    """
    from kodi_six import xbmcaddon
    addon = xbmcaddon.Addon(addon_id)
    doh_urls_str = addon.getSetting("doh_urls")
    if doh_urls_str:
        return [url.strip() for url in doh_urls_str.split(',')]
    
    # Retorna a URL da Cloudflare se nenhuma estiver configurada
    return ['https://cloudflare-dns.com/dns-query']

def get_mode():
    """
    Retorna o modo de operação do addon.
    """
    from kodi_six import xbmcaddon
    addon = xbmcaddon.Addon(addon_id)
    mode = addon.getSetting("debug_mode")
    return mode == "true"

class DNSOverrideDoH:
    def __init__(self):
        self.doh_urls = self._prepare_urls(get_doh_urls())
        self.doh_hosts = [urlparse(url).netloc for url in self.doh_urls]
        self.original_getaddrinfo = socket.getaddrinfo
        self.cache = {}
        self.mode_logger = get_mode()
        self.debug_mode = False

        if not self.doh_urls:
            if self.mode_logger:
                logging.error("Nenhuma URL DoH foi configurada.")
            return

        # Override DNS
        socket.getaddrinfo = self._resolver

    def _prepare_urls(self, urls):
        """
        Formata as URLs para o padrão correto, adicionando o sufixo de resolução.
        """
        prepared_urls = []
        for url in urls:
            if not url.startswith('http'):
                url = 'https://' + url
            
            # Adiciona o caminho de resolução correto
            prepared_urls.append(url.replace('/dns-query', '') + '/dns-query')

        return prepared_urls
    
    def get_next_doh_url(self):
        """
        Retorna a URL da lista de forma aleatória para rotação.
        """
        return random.choice(self.doh_urls)

    def is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False    

    def resolve(self, domain):
        if domain in self.cache:
            if self.mode_logger:
                logging.info("Cache hit for {0}: {1}".format(domain, self.cache[domain]))
            return self.cache[domain]

        doh_url = self.get_next_doh_url()
        try:
            domain_target = domain.strip(".")

            # Constrói a URL de consulta para Cloudflare
            params = {'name': domain_target, 'type': 'A'}
            headers = {'accept': 'application/dns-json'}
            response = requests.get(doh_url, params=params, headers=headers, timeout=5)

            if response.status_code == 200:
                data = response.json()
                
                # Extrai o IP com base na estrutura da resposta (padrão RFC 8484)
                ip = None
                if 'Answer' in data:
                    for answer in data['Answer']:
                        if answer['type'] == 1: # Tipo A
                            ip = answer['data']
                            break
                elif "ip" in data: # Resposta customizada (Baby-beamup)
                    ip = data.get("ip")

                if ip:
                    self.cache[domain] = ip
                    if self.mode_logger:
                        logging.debug("Resolved {0} to {1} using {2}".format(domain, ip, doh_url))
                    return ip

            if self.mode_logger:
                logging.warning("Falha ao resolver {0} usando {1}. Status: {2}".format(domain, doh_url, response.status_code))
            return None
        except requests.exceptions.RequestException as e:
            if self.mode_logger:
                logging.error("Erro ao resolver {0} via DoH ({1}): {2}".format(domain, doh_url, e))
            return None

    def _resolver(self, host, port, *args, **kwargs):
        try:
            # Evita resolver os próprios servidores DoH para não causar recursão
            if host in self.doh_hosts:
                return self.original_getaddrinfo(host, port, *args, **kwargs)

            if self.is_valid_ipv4(host):
                if self.mode_logger:
                    logging.debug("Bypass DNS: {0} já é um IP".format(host))
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (host, port))]

            ip = self.resolve(host)
            if ip:
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))]
            
            if self.mode_logger:
                logging.warning("Falha ao resolver {0}, usando getaddrinfo original".format(host))
            return self.original_getaddrinfo(host, port, *args, **kwargs)
        except Exception as e:
            if self.mode_logger:
                logging.error("Erro no resolver para {0}: {1}".format(host, e))
            return self.original_getaddrinfo(host, port, *args, **kwargs)