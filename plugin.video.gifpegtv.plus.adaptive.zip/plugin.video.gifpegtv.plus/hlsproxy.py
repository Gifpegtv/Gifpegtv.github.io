# -*- coding: utf-8 -*-
"""
Proxy HLS Ultra-Resiliente para Kodi e InputStream Adaptive

Otimizações Aplicadas:
- Resiliência Máxima: O proxy agora trata qualquer exceção de rede ou de servidor (4xx, 5xx, timeouts) como um sinal para
  reconstruir a conexão desde o manifesto, garantindo que o Kodi nunca receba um erro.
- Invalidação de Cache Agressiva: Em qualquer falha de segmento, o cache do manifesto é limpo forçadamente.
  Isso assegura que, se a fonte mudar as URLs dos segmentos ou tokens, o proxy se adapte instantaneamente.
- Segmento Dummy Aprimorado: O segmento de fallback agora é maior (2MB de pacotes TS válidos),
  simulando um segmento de áudio/vídeo de curta duração.
- Suporte a Chaves de Criptografia (EXT-X-KEY): O proxy agora também reescreve as URLs das chaves de criptografia.
- Gerenciamento de Cache (LRU): Implementada a limpeza automática do cache (Least Recently Used).
- Propriedades ISA Otimizadas: Ajustado o conjunto de propriedades para o InputStream Adaptive.
- Backoff Exponencial: Atraso progressivo nas tentativas de reconexão.
- Reconexão Pós-Sucesso: A sessão é reiniciada a cada manifesto baixado com sucesso.
- Manifesto Dummy: Retorna um manifesto falso (200 OK) após falhas persistentes.
- Streaming de Segmentos (Chunked Transfer): Os segmentos de vídeo são transmitidos em tempo real para o player.
- Otimização do Buffer do Player: Buffer de memória maior (20 MB) e buffer inicial mais longo (20 segundos).
- **Contorno 429/502/RemoteDisconnected CRÍTICO**: Implementação de **User-Agent Cycling** em cada falha de conexão
  e **Tempo de Espera Extremo Adaptativo** (45s) para 429 persistente.
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import re
from collections import OrderedDict

# Bibliotecas de requisição
try:
    import requests as real_requests
    import requests.exceptions as req_exc
except ImportError:
    print("Erro: A biblioteca 'requests' é necessária. Instale com: pip install requests")
    sys.exit(1)

# Cliente DNS-over-HTTPS (DoH) para maior resiliência
try:
    from doh_client import requests as doh_requests
except ImportError:
    logging.warning("doh_client não encontrado. Usando requests padrão, o que pode ser menos resiliente a bloqueios de DNS.")
    doh_requests = real_requests

# Mock para o ambiente Kodi, permitindo testes fora dele
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    class XBMCMock:
        def translatePath(self, path): return os.getcwd()
        def log(self, msg, level=0): print(f"[KODI-MOCK] {msg}")
    xbmc = XBMCMock()
    xbmcgui = xbmcplugin = xbmc

# ---------------- CONFIGURAÇÕES GLOBAIS DE RESILIÊNCIA ----------------
PROXY_HOST = "127.0.0.1"
CONNECTION_TIMEOUT = 15     # Timeout para estabelecer conexão
STREAM_TIMEOUT = 30         # Timeout para baixar cada segmento/manifesto
SEGMENT_TTL = 300           # Tempo de vida do cache de segmentos (5 min)
MANIFEST_TTL = 6.0          # TTL padrão para manifestos
MAX_CACHE_SIZE = 100 * 1024 * 1024  # 100 MB de cache máximo
MAX_MANIFEST_RETRIES = 10   # Máximo de tentativas antes de enviar o dummy 
MAX_BACKOFF_DELAY = 15      # Máximo de atraso do backoff em segundos (Para 502/RemoteDisconnected)
EXTREME_429_WAIT_SECONDS = 45 # Tempo de espera dedicado para 429 persistente
CHUNK_SIZE = 8 * 1024       # 8 KB por pedaço para o streaming de segmentos

# Caches e Segmento Dummy (Inalterados)
manifest_cache = OrderedDict()
segment_cache = OrderedDict()
current_cache_size = 0
DUMMY_TS = bytes([0x47] + [0x1F] * 187) * (2 * 1024 * 1024 // 188)
DUMMY_MANIFEST = (
    "#EXTM3U\n"
    "#EXT-X-VERSION:3\n"
    "#EXT-X-TARGETDURATION:3\n"
    "#EXT-X-MEDIA-SEQUENCE:0\n"
    "#EXTINF:3.0,\n"
    "dummy_segment.ts"
)

# Pool de User-Agents para o cycling
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Android 14; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0"
]

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- GERENCIADOR DE SESSÃO COM USER-AGENT CYCLING ----------------
class SessionManager:
    """Gerencia as sessões de requests, implementando o User-Agent Cycling."""
    
    def _create_session(self):
        session = doh_requests
        if not hasattr(session, "headers"):
            session.headers = {}
            
        # User-Agent Cycling: Muda a identidade em cada nova sessão
        session.headers["User-Agent"] = random.choice(USER_AGENTS)
        session.headers["Accept"] = "*/*"
        session.headers["Accept-Language"] = "en-US,en;q=0.9"
        session.headers["Connection"] = "keep-alive"
        return session

    def get_session(self, sid):
        return self._create_session() 

    def reset_session(self, sid):
        logging.warning(f"[{sid}] Resetando (simulando nova) sessão de conexão e mudando User-Agent.")
        return self._create_session()

session_manager = SessionManager()

# ---------------- GERENCIADOR DE CACHE (Inalterado) ----------------
def _evict_cache_if_needed():
    global current_cache_size
    while current_cache_size > MAX_CACHE_SIZE:
        if segment_cache:
            _, (ts, data, _) = segment_cache.popitem(last=False)
            current_cache_size -= len(data)
        elif manifest_cache:
            key_to_pop, (ts, data, _, _) = manifest_cache.popitem(last=False)
            current_cache_size -= len(data.encode("utf-8"))
        else:
            break

def cache_get(url):
    now = time.time()
    if url in segment_cache:
        ts, data, headers = segment_cache[url]
        if now - ts < SEGMENT_TTL:
            segment_cache.move_to_end(url)
            return data, headers
    if url in manifest_cache:
        ts, data, base_url, ttl = manifest_cache[url]
        if now - ts < ttl:
            manifest_cache.move_to_end(url)
            return data, base_url
    return None

def cache_set_manifest(url, data, base_url, ttl):
    global current_cache_size
    size = len(data.encode("utf-8"))
    manifest_cache[url] = (time.time(), data, base_url, ttl)
    manifest_cache.move_to_end(url)
    current_cache_size += size
    _evict_cache_if_needed()

def cache_set_segment(url, data, headers):
    global current_cache_size
    size = len(data)
    segment_cache[url] = (time.time(), data, headers)
    segment_cache.move_to_end(url)
    current_cache_size += size
    _evict_cache_if_needed()

def clear_manifest_cache():
    global current_cache_size
    logging.warning("Limpando cache de manifestos para forçar atualização.")
    keys_to_remove = list(manifest_cache.keys())
    for key in keys_to_remove:
        if key in manifest_cache:
            _, data, _, _ = manifest_cache.pop(key)
            current_cache_size -= len(data.encode("utf-8"))

# ---------------- UTILITÁRIOS ----------------
def _obfuscate_url_for_log(url):
    try:
        parsed = urllib.parse.urlparse(url)
        return "***" + os.path.basename(parsed.path) + ("?..." if parsed.query else "")
    except Exception:
        return "****"

# ---------------- MANIPULADOR DO PROXY HLS ----------------
class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if "?url=" not in self.path:
            self.send_response(200)
            self.end_headers()
            return

        params = urllib.parse.parse_qs(self.path.split("?", 1)[1])
        url = urllib.parse.unquote_plus(params.get("url", [None])[0])
        sid = params.get("session_id", ["default"])[0]

        if not url:
            self.send_response(200)
            self.end_headers()
            return

        if url.lower().endswith(".m3u8"):
            self._handle_manifest(url, sid)
        elif ".key" in url.lower() or "/key/" in url.lower():
            self._handle_key(url, sid)
        else:
            self._handle_segment(url, sid)

    def _handle_manifest(self, url, sid, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        
        cached = cache_get(url)
        if cached and retry_count == 0:
            content, base_url = cached
            return self._send_manifest(content, base_url, sid)

        if retry_count >= MAX_MANIFEST_RETRIES:
            logging.error(f"[{sid}] Falha persistente ao baixar manifesto {log_url}. Enviando manifesto dummy.")
            return self._send_manifest(DUMMY_MANIFEST, url, sid)

        try:
            sess = session_manager.get_session(sid)
            r = sess.get(url, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
            
            if r.status_code == 429:
                # Contorno Avançado 429:
                wait_time = 0
                if 'Retry-After' in r.headers:
                    try:
                        wait_time = int(r.headers['Retry-After'])
                        logging.warning(f"[{sid}] 429 Detectado! Servidor solicitou espera de {wait_time} segundos (Retry-After).")
                    except ValueError:
                        pass
                
                if wait_time == 0:
                    calculated_delay = min(2 ** retry_count, MAX_BACKOFF_DELAY)
                    if retry_count >= 5: # Espera Extrema após 5 falhas 429
                        wait_time = EXTREME_429_WAIT_SECONDS
                        logging.error(f"[{sid}] 429 Persistente (Tentativa {retry_count + 1}). Aplicando espera extrema de {wait_time} segundos.")
                    else:
                        # Para 429 não persistente, usamos um backoff menor para tentar mais rápido
                        wait_time = min(calculated_delay, 5) 
                
                logging.error(f"[{sid}] Erro ao baixar manifesto {log_url} (Tentativa {retry_count + 1}/{MAX_MANIFEST_RETRIES}): [429 Detectado] HTTP Status 429. User-Agent será trocado.")
                session_manager.reset_session(sid) # Troca User-Agent
                time.sleep(wait_time)
                return self._handle_manifest(url, sid, retry_count + 1)
            
            if r.status_code >= 400:
                # Trata outros erros 4xx/5xx que não sejam 429
                logging.error(f"[{sid}] Servidor retornou status {r.status_code} para o manifesto {log_url}. Iniciando reconexão.")
                # Força a exceção para cair no bloco 'except RequestException' para o tratamento de reset+backoff
                r.raise_for_status() 
            
            r.raise_for_status()
            content, base_url = r.text, r.url
            ttl = self._detect_manifest_ttl(content)
            
            logging.info(f"[{sid}] Manifesto {log_url} baixado com status 200 OK. Resetando sessão para garantir nova conexão.")
            session_manager.reset_session(sid) 

            cache_set_manifest(url, content, base_url, ttl)
            return self._send_manifest(content, base_url, sid)

        except req_exc.RequestException as e:
            # Captura exceções de rede (timeouts, RemoteDisconnected) e erros de status (400, 502, 503, etc.)
            error_msg = str(e)
            
            # Contorno de 502 e RemoteDisconnected: Logging explícito + Reset + Backoff
            if 'Remote end closed connection' in error_msg:
                 log_type = "[RemoteDisconnected]"
            elif '502 error responses' in error_msg or 'HTTPError: 502' in error_msg:
                 log_type = "[502 Bad Gateway Detectado]"
            else:
                 log_type = "[Erro de Rede/HTTP]"

            logging.error(f"[{sid}] Erro ao baixar manifesto {log_url} (Tentativa {retry_count + 1}/{MAX_MANIFEST_RETRIES}): {log_type} {e}. User-Agent será trocado.")
                
            session_manager.reset_session(sid) # Força a troca de User-Agent/Nova Conexão
            # Backoff exponencial com limite de 15s (MAX_BACKOFF_DELAY)
            delay = min(2 ** retry_count, MAX_BACKOFF_DELAY)
            time.sleep(delay) 
            return self._handle_manifest(url, sid, retry_count + 1)
        
        except Exception as e:
            # Captura outras exceções inesperadas
            logging.error(f"[{sid}] Erro inesperado ao baixar manifesto {log_url} (Tentativa {retry_count + 1}/{MAX_MANIFEST_RETRIES}): [ERRO INESPERADO] {e}")
            session_manager.reset_session(sid)
            delay = min(2 ** retry_count, MAX_BACKOFF_DELAY)
            time.sleep(delay)
            return self._handle_manifest(url, sid, retry_count + 1)

    def _detect_manifest_ttl(self, content):
        match = re.search(r"#EXT-X-TARGETDURATION:([\d\.]+)", content)
        if match:
            return float(match.group(1)) * 0.8 
        
        matches = re.findall(r"#EXTINF:([\d\.]+)", content)
        if matches:
            avg = sum(float(x) for x in matches) / len(matches)
            return max(3.0, avg * 2.5)
        return MANIFEST_TTL

    def _send_manifest(self, content, base_url, sid):
        proxy_lines = []
        for line in content.splitlines():
            if line.startswith("#EXT-X-ENDLIST"):
                continue

            if line.startswith("#EXT-X-KEY"):
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    key_url = urllib.parse.urljoin(base_url, match.group(1))
                    proxy_key_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(key_url)}&session_id={sid}"
                    line = line.replace(match.group(1), proxy_key_url)
                proxy_lines.append(line)
            elif line.startswith("#") or not line.strip():
                proxy_lines.append(line)
            else:
                if line.strip() == "dummy_segment.ts" and content.strip() == DUMMY_MANIFEST.strip():
                    full_url = "DUMMY_FAIL_SEGMENT"
                else:
                    full_url = urllib.parse.urljoin(base_url, line)
                
                proxy_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={sid}"
                proxy_lines.append(proxy_url)

        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        self.wfile.write("\n".join(proxy_lines).encode("utf-8"))

    def _handle_key(self, url, sid, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        if retry_count >= 3:
            logging.critical(f"[{sid}] Falha CRÍTICA e persistente ao buscar chave {log_url}. Abortando.")
            self.send_response(502) 
            self.end_headers()
            return

        try:
            sess = session_manager.get_session(sid)
            r = sess.get(url, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
            if r.status_code >= 400:
                raise req_exc.RequestException(f"Erro HTTP ao buscar chave: {r.status_code}")
            r.raise_for_status()
            headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding"]}
            self._send_response(r.content, headers)
        except Exception as e:
            logging.error(f"[{sid}] Falha ao buscar chave {log_url} (Tentativa {retry_count + 1}/3): {e}.")
            session_manager.reset_session(sid)
            time.sleep(min(2 ** retry_count, 5))
            return self._handle_key(url, sid, retry_count + 1)

    def _handle_segment(self, url, sid):
        if url == "DUMMY_FAIL_SEGMENT":
            logging.info(f"[{sid}] Servindo segmento dummy devido a manifesto dummy anterior.")
            return self._send_response(DUMMY_TS, {"Content-Type": "video/mp2t"})
        
        log_url = _obfuscate_url_for_log(url)
        try:
            cached = cache_get(url)
            if cached:
                data, headers = cached
                return self._send_response(data, headers)

            sess = session_manager.get_session(sid)
            r = sess.get(url, stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
            
            if r.status_code >= 400:
                raise req_exc.RequestException(f"Erro HTTP no segmento: {r.status_code}")
            
            r.raise_for_status()
            headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding", "content-length"]}
            
            return self._stream_response_and_cache(r, url, headers)

        except Exception as e:
            logging.warning(f"[{sid}] Falha no segmento {log_url}: {e}. Forçando atualização do manifesto e enviando dummy.")
            clear_manifest_cache()
            session_manager.reset_session(sid)
            return self._send_response(DUMMY_TS, {"Content-Type": "video/mp2t"})

    def _send_response(self, content, headers):
        """Envia uma resposta completa de uma só vez (bom para dados pequenos como chaves ou dummies)."""
        self.send_response(200)
        headers["Content-Length"] = str(len(content))
        
        for k, v in headers.items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(content)
        except BrokenPipeError:
            pass
    
    def _stream_response_and_cache(self, response, url, headers):
        """
        Transmite a resposta em pedaços (chunks) para o cliente e, ao mesmo tempo,
        monta o conteúdo completo para armazenar em cache.
        """
        self.send_response(200)
        for k, v in headers.items():
            self.send_header(k, v)
        self.end_headers()
        
        data_chunks = []
        try:
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                self.wfile.write(chunk)
                data_chunks.append(chunk)
        except (BrokenPipeError, ConnectionResetError):
             logging.warning("Conexão com o player foi fechada durante o streaming do segmento.")
        finally:
            response.close()

        if data_chunks:
            full_data = b"".join(data_chunks)
            cache_set_segment(url, full_data, headers)

    def log_message(self, format, *args):
        return

# ---------------- GERENCIADOR DO PROXY ----------------
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.port = None

    def start(self):
        for _ in range(20): # MAX_PORT_ATTEMPTS
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.port = port
                xbmc.log(f"Proxy HLS Resiliente iniciado em http://{PROXY_HOST}:{port}", xbmc.LOGINFO)
                return True
            except OSError:
                continue
        xbmc.log("FALHA: Não foi possível iniciar o proxy HLS. Nenhuma porta disponível.", xbmc.LOGERROR)
        return False

    def stop(self):
        if self.server:
            xbmc.log("Parando proxy HLS...", xbmc.LOGINFO)
            self.server.shutdown()
            self.server.server_close()

# ---------------- INTEGRAÇÃO COM O ADDON KODI ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype="live"):
        if not self.proxy.start():
            xbmcgui.Dialog().notification("Erro de Proxy", "Não foi possível iniciar o proxy local.", xbmcgui.NOTIFICATION_ERROR)
            return

        sid = f"stream_{int(time.time())}"
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.port}/?url={urllib.parse.quote_plus(url)}&session_id={sid}"
        
        li = xbmcgui.ListItem(path=proxy_url)
        li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)

        if stype == "live":
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            li.setProperty("IsLive", "true")
            
            li.setProperty("inputstream.adaptive.live_delay", "99")
            li.setProperty("inputstream.adaptive.live_delay_automatic", "true")
            
            # Aumenta drasticamente o buffer de memória do player (20 MB)
            li.setProperty("inputstream.adaptive.stream_buffer_size", "20971520") 
            
            # Aumenta o buffer inicial para 20 segundos
            li.setProperty("inputstream.adaptive.initial_buffer_duration", "20")
            
            li.setProperty("inputstream.adaptive.play_segment_stall_timeout", "60")
            
            li.setProperty("inputstream.adaptive.max_bandwidth", "0")
            li.setProperty("inputstream.adaptive.max_resolution_switch", "0")

        xbmcplugin.setResolvedUrl(self.handle, True, li)

# ---------------- PONTO DE ENTRADA ----------------
def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s T:%(thread)d %(levelname)s <general>: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

def main():
    setup_logging()
    if len(sys.argv) < 3:
        pass

    handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    addon = HLSAddon(handle)
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}

    if args.get("action", [None])[0] == "play_stream":
        stream_url = args.get("stream_url", [None])[0]
        if stream_url:
            addon.play_stream(stream_url)
        else:
            xbmc.log("Nenhuma URL de stream fornecida.", xbmc.LOGERROR)

if __name__ == "__main__":
    if 'xbmc' not in sys.modules:
        setup_logging() 
    main()