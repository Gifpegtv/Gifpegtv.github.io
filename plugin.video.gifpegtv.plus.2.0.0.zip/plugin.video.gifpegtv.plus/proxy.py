# --- CÓDIGO COMPLETO E CORRIGIDO (PLAYER PADRÃO KODI) ---
import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
from collections import OrderedDict
from typing import Optional, Dict
import warnings
import socket

# Importa o cliente DoH que sobrescreve a resolução de DNS
# Este módulo deve ser adicionado ao Kodi como 'script.module.netunblock'
try:
    from doh_client import requests
except ImportError:
    # Fallback para o módulo requests padrão se o DoH não estiver disponível
    import requests

# Importação de requests.exceptions de forma separada para corrigir o AttributeError
import requests.exceptions

from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import m3u8
from werkzeug.serving import make_server
from flask import Flask, request, Response, stream_with_context

# Configurações principais
MAX_SEGMENT_RETRIES = 8
RETRY_BACKOFF_FACTOR = 0.5
MAX_BACKOFF_TIME = 10
CONNECTION_TIMEOUT = 5.0
STREAM_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 64 * 1024
MAX_CACHE_MB = 128
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
MAX_SEGMENT_SIZE_BYTES = 25 * 1024 * 1024
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
SESSION_MAX_AGE = 60
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "VLC/3.0.20 LibVLC/3.0.20 (X11; Linux x86_64)",
    "AppleCoreMedia/1.0.0.20G75 (iPhone; U; CPU OS 16_6 like Mac OS X; en_us)",
    "Lavf59.27.100",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.2 Safari/605.1.15",
]

warnings.filterwarnings("ignore", message="Unverified HTTPS request")
LOG_FILE = "hlsproxy_iptv_proactive_default_player.log"

def setup_logging():
    handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    logging.basicConfig(
        handlers=[handler, logging.StreamHandler(sys.stdout)],
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] (%(threadName)s) - %(message)s"
    )

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith((".m3u8", ".m3u")):
        return "application/vnd.apple.mpegurl"
    if path.endswith((".ts")) or "auth/" in path or "stream/" in path:
        return "video/mp2t"
    if path.endswith(".aac"):
        return "audio/aac"
    if path.endswith(".mp4"):
        return "video/mp4"
    return "application/octet-stream"

def get_random_user_agent() -> str:
    return random.choice(USER_AGENTS)

def resolve_domain_to_ip(domain: str) -> Optional[str]:
    """Resolve um nome de domínio para um endereço IP, com fallback utilizando um socket bruto."""
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        logging.warning(f"Não foi possível resolver o domínio via gethostbyname: {domain}")
        # Fallback usando um socket manual
        try:
            infos = socket.getaddrinfo(domain, None)
            # Pega o primeiro endereço IPv4 encontrado
            for info in infos:
                if info[0] == socket.AF_INET:
                    return info[4][0]
            # Caso não encontre IPv4, retorna o primeiro disponível
            if infos:
                return infos[0][4][0]
        except Exception as e:
            logging.error(f"Falha no fallback de resolução de DNS por socket para {domain}: {e}")
            return None

def get_headers(url: str, user_agent: Optional[str] = None, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    ua = user_agent if user_agent else get_random_user_agent()
    headers = {
        "User-Agent": ua, "Accept": "*/*", "Referer": origin, "Origin": origin,
        "Connection": "keep-alive",
        "X-Forwarded-For": '.'.join(str(random.randint(0, 255)) for _ in range(4)),
    }
    
    # Adiciona o IP resolvido no cabeçalho
    host_ip = resolve_domain_to_ip(parts.netloc.split(':')[0])
    if host_ip:
        headers["X-IP-Resolvido"] = host_ip
    
    if extra: headers.update(extra)
    return headers

class RotatingCache:
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.store = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            item = self.store.get(url)
            if not item: return None
            data, expire = item
            if expire and expire < time.time():
                self._pop(url)
                return None
            self.store.move_to_end(url)
            return data

    def add(self, url: str, data: bytes, ttl: int):
        with self.lock:
            if url in self.store: self._pop(url)
            size = len(data)
            if size > self.max_bytes: return
            while self.total_bytes + size > self.max_bytes: self._popitem(last=False)
            expire = time.time() + ttl if ttl else None
            self.store[url] = (data, expire)
            self.total_bytes += size

    def _pop(self, url: str):
        if url in self.store:
            data, _ = self.store.pop(url)
            self.total_bytes -= len(data)

    def _popitem(self, last: bool):
        try:
            _, (data, _) = self.store.popitem(last=last)
            self.total_bytes -= len(data)
        except KeyError: pass

    def clear(self):
        """Limpa todo o cache."""
        with self.lock:
            self.store.clear()
            self.total_bytes = 0

class IPTVHLSProxyManager:
    def __init__(self):
        self.cache = RotatingCache()
        self.active_port = None
        self.server = None
        self.server_thread = None
        self.lock = threading.Lock()
        self.session_user_agent = get_random_user_agent()
        self.app = self._create_flask_app()

    def force_reconnect(self, reason: str = "Unknown"):
        with self.lock:
            logging.info(f"Forçando RECONEXÃO ({reason}). Descartando sessão antiga e cache.")
            self.session_user_agent = get_random_user_agent()
            self.cache.clear()

    def _create_flask_app(self):
        app = Flask("IPTVHLSProxy")
        
        @app.route("/", methods=["GET"])
        def proxy():
            url = request.args.get("url")
            if not url: return Response("Missing 'url' parameter", 400)
            decoded_url = urllib.parse.unquote_plus(url)
            
            if decoded_url.endswith((".m3u8", ".m3u")):
                return self.handle_manifest(decoded_url)
            else:
                return self.handle_segment_stream(decoded_url)
        return app

    def _create_session(self):
        """Cria e configura uma nova sessão de requests com retentativas."""
        session = requests.Session()
        retry_strategy = Retry(
            total=MAX_SEGMENT_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[404, 500, 502, 503, 504, 520, 521, 522],
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session


    def _make_request(self, url: str, method: str = "GET", headers=None, **kwargs):
        """Método unificado para fazer requisições HTTP usando uma sessão persistente."""
        session = self._create_session() # Nova sessão para cada requisição para evitar estados quebrados
        hdr = get_headers(url, user_agent=self.session_user_agent, extra=headers)
        kwargs['headers'] = hdr
        
        try:
            if method.upper() == "GET":
                return session.get(url, **kwargs)
            elif method.upper() == "HEAD":
                return session.head(url, **kwargs)
            else:
                raise ValueError("Método HTTP não suportado: " + method)
        except AttributeError:
            # Fallback para o requests padrão se a classe doh_client.requests não tiver o método
            import requests as fallback_requests
            if method.upper() == "GET":
                return fallback_requests.get(url, **kwargs)
            elif method.upper() == "HEAD":
                return fallback_requests.head(url, **kwargs)
            else:
                raise ValueError("Método HTTP não suportado: " + method)
        finally:
            session.close()


    def handle_manifest(self, url: str) -> Response:
        cached = self.cache.get(url)
        if cached:
            logging.info(f"Manifesto de {url} servido do cache.")
            return Response(cached, mimetype="application/vnd.apple.mpegurl")
        
        try:
            # Use um timeout menor para o manifesto, já que é uma requisição rápida
            r = self._make_request(url, method="GET", timeout=CONNECTION_TIMEOUT)
            r.raise_for_status()
            content = r.text
        except requests.exceptions.RequestException as e:
            logging.error(f"Erro ao carregar manifesto {url}: {e}")
            self.force_reconnect(reason=f"Falha manifesto principal")
            return Response("#EXTM3U\n#EXT-X-ERROR: Could not load manifest\n", status=502, mimetype="application/vnd.apple.mpegurl")
        
        try:
            proxy_base_url = f"http://{PROXY_HOST}:{self.active_port}/?url="
            m3u8_obj = m3u8.loads(content, uri=url)
            is_live = not m3u8_obj.is_endlist
            
            if m3u8_obj.is_variant:
                for playlist in m3u8_obj.playlists:
                    playlist.uri = proxy_base_url + urllib.parse.quote_plus(playlist.absolute_uri)
            
            for segment in m3u8_obj.segments:
                segment.uri = proxy_base_url + urllib.parse.quote_plus(segment.absolute_uri)
                if segment.key and segment.key.uri:
                    segment.key.uri = proxy_base_url + urllib.parse.quote_plus(segment.key.absolute_uri)

            proxied_playlist = m3u8_obj.dumps().encode("utf-8")
            ttl = 3 if is_live else 300
            self.cache.add(url, proxied_playlist, ttl)
            
            response = Response(proxied_playlist, mimetype="application/vnd.apple.mpegurl")
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
            return response
            
        except Exception as e:
            logging.error(f"Erro ao reescrever manifesto: {e}")
            return Response("#EXTM3U\n#EXT-X-ERROR: Playlist processing error\n", status=500, mimetype="application/vnd.apple.mpegurl")

    def handle_segment_stream(self, url: str) -> Response:
        def generate():
            try:
                # O objeto de sessão com retentativa já cuida das tentativas
                r = self._make_request(url, method="GET", stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT))
                r.raise_for_status()
                logging.info(f"Stream do segmento {url.split('/')[-1]} iniciado com sucesso.")
                
                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk: yield chunk
                r.close()
            except requests.exceptions.RequestException as e:
                logging.error(f"Falha CRÍTICA ao buscar segmento {url}: {e}")
                self.force_reconnect(reason=f"Falha persistente de segmento")
                # Não retorna nada, o stream será interrompido e o player fechará.

        return Response(stream_with_context(generate()), mimetype=safe_mime_type(url), status=200)


    def start(self) -> Optional[int]:
        self.stop()
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                self.active_port = port
                logging.info(f"Proxy PROATIVO iniciado em http://{PROXY_HOST}:{port}")
                return port
            except OSError: continue
        logging.error("Falha ao iniciar proxy: nenhuma porta disponível.")
        return None

    def stop(self):
        if self.server:
            try: self.server.shutdown()
            except Exception: pass
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=1)
        self.server = None
        self.server_thread = None
        self.active_port = None

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = IPTVHLSProxyManager()

    def play_stream(self, url: str, title: Optional[str] = None):
        if not self.proxy.start():
            import xbmcgui
            import xbmcplugin
            xbmcgui.Dialog().ok("Erro Proxy IPTV", "Não foi possível iniciar o servidor proxy.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        import xbmcgui
        import xbmcplugin
        li = xbmcgui.ListItem(path=proxy_url, label=title or "GIF PEG TV PLUS")
        li.setProperty("IsPlayable", "true")
        
        # Esta linha é a chave para o player padrão do Kodi entender o stream
        li.setMimeType("application/vnd.apple.mpegurl")
        
        # As linhas abaixo, que forçavam o inputstream.adaptive, foram REMOVIDAS.
        # li.setProperty("inputstream", "inputstream.adaptive")
        # li.setProperty("inputstream.adaptive.manifest_type", "hls")
        
        li.setProperty("IsLive", "true")
        
        xbmcplugin.setResolvedUrl(self.handle, True, li)
        logging.info(f"Reprodução iniciada com URL do proxy para o PLAYER PADRÃO: {proxy_url}")

    def show_test_streams(self):
        import xbmcgui
        import xbmcplugin
        test_streams = [
            ("Big Buck Bunny", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Elephants Dream", "https://d3u2k51g8x1l3w.cloudfront.net/a/master_elephantsdream.m3u8")
        ]
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=name)
            li.setProperty("IsPlayable", "true")
            plugin_url = f"plugin://{sys.argv[0]}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, li, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

def main():
    setup_logging()
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        addon = HLSProxyAddon(handle)
        action = params.get("action")
        if action == "play":
            url = params.get("url")
            title = params.get("title", "GIF PEG TV PLUS")
            if url: addon.play_stream(url, title)
            else: addon.show_test_streams()
        else:
            addon.show_test_streams()
    except Exception as e:
        logging.critical(f"Fatal error: {e}", exc_info=True)

if __name__ == "__main__":
    main()