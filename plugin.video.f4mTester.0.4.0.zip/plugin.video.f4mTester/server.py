import six
import os
import threading
import socket
import requests
import time
import json
import collections
import re
from datetime import datetime, timedelta
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import logging
import socketserver # Import for ThreadingMixIn

# Configuração de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode  # Python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # Python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from SimpleHTTPServer import SimpleHTTPRequestHandler

# Custom HTTPServer that uses threading for handling requests
class ThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True # Ensures threads are shut down when the main program exits

HOST_NAME = '127.0.0.1' # Changed to 0.0.0.0 to listen on all available interfaces
PORT_NUMBER = 65321
DOH_SERVER_URL = "https://cloudflare-dns.com/dns-query"
DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

# Globais para estado do stream atual. Serão resetados para novos canais.
GLOBAL_HEADERS = {}
GLOBAL_URL = '' # Base URL para segmentos relativos

# Instância global do servidor para acesso externo e gerenciamento de parada
_media_server_instance = None # Será inicializado em __main__

# --- Novo: Gerenciamento de Buffer de Stream ---
class StreamBuffer:
    def __init__(self, max_segments=50, timeshift_buffer_seconds=1024): # Limite de segmentos na memória (ajustável)
        self.segments = collections.OrderedDict() # {segment_url: (data, timestamp, sequence_number)}
        self.max_segments = max_segments
        self.timeshift_buffer_seconds = timeshift_buffer_seconds # Quanto tempo de stream manter no buffer
        self.lock = threading.Lock()
        self.playlist_sequence = -1 # Para rastrear a sequência da playlist HLS
        self.segment_duration = 0.0 # Duração média dos segmentos para cálculo de timeshift
        self.last_segment_timestamp = 0.0 # Timestamp do último segmento adicionado

    def add_segment(self, url, data, timestamp=None, sequence_number=None):
        with self.lock:
            ts = timestamp if timestamp is not None else time.time()
            self.segments[url] = (data, ts, sequence_number)
            self.last_segment_timestamp = ts
            
            # Remover segmentos muito antigos ou que excedem o limite de contagem
            self._cleanup_buffer()
            
            logger.debug(f"Segmento adicionado/atualizado no buffer: {url} (Seq: {sequence_number}, TS: {ts:.2f})")

    def get_segment(self, url):
        with self.lock:
            return self.segments.get(url)

    def _cleanup_buffer(self):
        """Remove segmentos que estão fora do limite de tempo ou do número máximo."""
        if not self.segments:
            return

        current_time = time.time()
        
        # Remove segmentos muito antigos (fora da janela de timeshift)
        urls_to_remove = []
        for url, (data, ts, seq) in list(self.segments.items()): # Iterate over a copy
            if ts is not None and (current_time - ts) > self.timeshift_buffer_seconds:
                urls_to_remove.append(url)
            else:
                # As OrderedDict mantém a ordem de inserção, podemos parar quando encontrar um segmento não expirado
                # (assuming segments are added in chronological order)
                break 
        
        for url in urls_to_remove:
            self.segments.pop(url)
            logger.debug(f"Segmento antigo removido do buffer por TTL: {url}")

        # Remove segmentos que excedem o número máximo, começando pelos mais antigos
        while len(self.segments) > self.max_segments:
            oldest_url = next(iter(self.segments))
            self.segments.pop(oldest_url)
            logger.debug(f"Segmento removido do buffer por limite de contagem: {oldest_url}")

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.playlist_sequence = 30
            self.segment_duration = 0.0
            self.last_segment_timestamp = 0.0
            logger.info("Buffer de stream limpo.")

    def get_buffered_segment_urls(self):
        with self.lock:
            return list(self.segments.keys())

    def get_segment_for_timeshift(self, target_time_epoch):
        """
        Tenta encontrar um segmento no buffer que esteja próximo do target_time_epoch.
        target_time_epoch: timestamp (float) em segundos desde a Epoch.
        """
        with self.lock:
            best_match_url = None
            min_diff = float('inf')
            best_segment_info = None

            # Iterate from newest to oldest to find the segment closest to target_time_epoch
            # We prefer segments slightly older than the target time to ensure playback continuity
            for url, (data, segment_ts, segment_seq) in reversed(self.segments.items()):
                if segment_ts is None:
                    continue

                diff = target_time_epoch - segment_ts # Positive if segment is older, negative if newer
                
                # Prioritize segments that are slightly older or at the target time
                if diff >= - (self.segment_duration / 2) : # Consider segments slightly newer, but prefer older
                    abs_diff = abs(diff)
                    if abs_diff < min_diff:
                        min_diff = abs_diff
                        best_match_url = url
                        best_segment_info = (data, segment_ts, segment_seq)
                
                # If we've gone significantly past the target time (to much older segments), stop
                if segment_ts < target_time_epoch - (self.segment_duration * 2 if self.segment_duration > 0 else 5):
                    break
            
            if best_match_url:
                logger.info(f"Timeshift: Encontrado segmento '{best_match_url}' com timestamp {best_segment_info[1]:.2f} "
                            f"para target {target_time_epoch:.2f} (diff {min_diff:.2f}s)")
                return best_segment_info
            else:
                logger.warning(f"Timeshift: Nenhum segmento encontrado no buffer para o tempo alvo {target_time_epoch:.2f}s.")
                return None
            
    def get_sequence_for_timeshift(self, target_time_epoch):
        """
        Tenta encontrar a sequence number para o target_time_epoch.
        Retorna a sequence number e o timestamp do segmento encontrado.
        """
        segment_info = self.get_segment_for_timeshift(target_time_epoch)
        if segment_info:
            data, ts, seq = segment_info
            return seq, ts
        return None, None


stream_buffer = StreamBuffer() # Instância global do buffer

# Cache para resultados DoH para reduzir requisições repetidas
doh_cache = collections.OrderedDict()
DOH_CACHE_MAX_SIZE = 100
DOH_CACHE_TTL = 300 # 5 minutos de TTL

def query_doh(domain, record_type="A", doh_server=DOH_SERVER_URL):
    """Resolve um domínio usando DNS over HTTPS e retorna o endereço IP, com caching."""
    # Verifica o cache primeiro
    if domain in doh_cache:
        ip, timestamp = doh_cache[domain]
        if (time.time() - timestamp) < DOH_CACHE_TTL:
            logger.debug(f"Usando DoH cache para {domain}: {ip}")
            return ip
        else:
            logger.info(f"Cache DoH expirado para {domain}")
            doh_cache.pop(domain) # Remove item expirado

    headers = {
        "Accept": "application/dns-json",
        "User-Agent": DEFAULT_USER_AGENT
    }
    params = {
        "name": domain,
        "type": record_type
    }
    
    session = requests.Session()
    retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)

    try:
        response = session.get(doh_server, headers=headers, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        if "Answer" in data:
            for answer in data["Answer"]:
                if answer["type"] == 1:  # Type 1 is A record
                    ip = answer["data"]
                    # Adiciona ao cache
                    doh_cache[domain] = (ip, time.time())
                    if len(doh_cache) > DOH_CACHE_MAX_SIZE:
                        doh_cache.popitem(last=False) # Remove o mais antigo
                    logger.debug(f"DoH resolvido para {domain}: {ip}")
                    return ip
        logger.warning(f"Nenhum registro A encontrado para {domain} via DoH.")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Falha na resolução DoH para {domain}: {e}")
        return None
    except json.JSONDecodeError as e:
        logger.error(f"Erro ao decodificar JSON da resposta DoH para {domain}: {e}")
        return None
    finally:
        session.close() # Garante que a sessão seja fechada após o uso

class Handler(SimpleHTTPRequestHandler):
    # Desativa o log padrão do SimpleHTTPRequestHandler para usar nosso logger
    def log_message(self, format, *args):
        logger.debug(format % args)

    # Reutiliza a sessão de requests para manter conexões persistentes
    _session = None

    @classmethod
    def get_session(cls):
        if cls._session is None:
            retry_strategy = Retry(
                total=3,
                backoff_factor=1,
                status_forcelist=[429, 500, 502, 503, 504],
                allowed_methods=["HEAD", "GET", "OPTIONS"]
            )
            adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=10, pool_maxsize=10) # Aumenta pool
            cls._session = requests.Session()
            cls._session.mount("http://", adapter)
            cls._session.mount("https://", adapter)
        return cls._session

    def _reset_stream_state(self):
        """Reseta o estado global para um novo stream."""
        global GLOBAL_HEADERS, GLOBAL_URL
        logger.info("Resetando estado do stream global (headers e base URL).")
        GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}
        GLOBAL_URL = ''
        stream_buffer.clear() # Limpa o buffer ao mudar de canal

    def _get_parsed_url_param(self):
        """Extrai e decodifica o parâmetro 'url' do caminho da requisição."""
        try:
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            
            raw_param = query_params.get('url', [None])[0]
            if raw_param:
                # Decode multiple times to handle nested encoding
                decoded_param = unquote_plus(raw_param)
                decoded_param = unquote(decoded_param) 
                return decoded_param
            return None
        except Exception as e:
            logger.error(f"Erro ao decodificar parâmetro URL '{self.path}': {e}")
            return None

    def _get_timeshift_param(self):
        """Extrai o parâmetro 'timeshift' do caminho da requisição."""
        try:
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            timeshift_str = query_params.get('timeshift', [None])[0]
            if timeshift_str:
                return int(timeshift_str)
            return 0 
        except (ValueError, TypeError) as e:
            logger.warning(f"Timeshift param inválido: '{timeshift_str}'. Usando 0. Erro: {e}")
            return 0
        except Exception as e:
            logger.error(f"Erro ao extrair parâmetro timeshift: {e}")
            return 0

    def get_headers_from_url_params(self, url_with_params):
        """
        Extrai cabeçalhos (Referer, Origin, Cookie, User-Agent) de uma string de URL que os contém como parâmetros.
        Retorna um dicionário com os cabeçalhos extraídos.
        """
        custom_headers = {}
        try:
            # We assume headers are passed as URL query parameters, potentially encoded within the main 'url' param.
            # Example: http://stream.com/live.m3u8?key=val&Referer=http://site.com
            # Or using a custom separator like '|' or '&h123'
            
            # First, check for common custom header markers
            header_str = None
            if '|' in url_with_params:
                parts = url_with_params.split('|', 1)
                url_with_params = parts[0]
                if len(parts) > 1:
                    header_str = parts[1]
            elif '&h123' in url_with_params:
                parts = url_with_params.split('&h123', 1)
                url_with_params = parts[0]
                if len(parts) > 1:
                    header_str = parts[1]
            
            # If explicit header string found, parse it
            if header_str:
                # Headers might be comma-separated key=value pairs, or similar
                # This is a very basic parsing; real-world might need more robust logic
                for part in header_str.split('&'): # Assume & as separator for key=value pairs
                    if '=' in part:
                        key, value = part.split('=', 1)
                        key = unquote_plus(key).strip()
                        value = unquote_plus(value).strip()
                        if key.lower() in ['referer', 'origin', 'cookie', 'user-agent']:
                            custom_headers[key] = value
            
            # Also parse from query string if available in the main URL parameter
            parsed_param_url = urlparse(url_with_params)
            params_qs = parse_qs(parsed_param_url.query)

            # Check common header names (case-insensitive)
            header_keys = {'referer', 'origin', 'cookie', 'user-agent'}
            for h_key in header_keys:
                if h_key in params_qs:
                    custom_headers[h_key] = unquote_plus(params_qs[h_key][0])
                elif h_key.capitalize() in params_qs:
                    custom_headers[h_key.capitalize()] = unquote_plus(params_qs[h_key.capitalize()][0])
        except Exception as e:
            logger.debug(f"Erro ao parsear cabeçalhos de '{url_with_params}': {e}")

        return custom_headers

    def clean_url_from_headers_params(self, url):
        """Removes custom header parameters (like Referer, Origin etc.) if they are part of the URL string itself."""
        if '|' in url:
            url = url.split('|')[0]
        elif '&h123' in url:
            url = url.split('&h123')[0]
        
        # Remove known header query params
        parsed = urlparse(url)
        query_params = parse_qs(parsed.query)
        
        clean_query = {}
        for key, value in query_params.items():
            if key.lower() not in ['referer', 'origin', 'cookie', 'user-agent', 'timeshift']:
                clean_query[key] = value
        
        # Reconstruct the URL without header params
        if clean_query:
            return parsed._replace(query=urlencode(clean_query, doseq=True)).geturl()
        else:
            return parsed._replace(query='').geturl()


    def convert_to_m3u8_url(self, url):
        """Converte uma URL de stream genérica para uma URL .m3u8 se aplicável."""
        # Remove custom header parameters that might be embedded in the URL itself
        original_url_cleaned = self.clean_url_from_headers_params(url)

        # Considera como potencial URL de livestream se não for .m3u8/.ts, tem 2 ':' e > 4 '/'
        is_potential_livestream_url = not ('.m3u8' in original_url_cleaned or '.ts' in original_url_cleaned) and \
                                      original_url_cleaned.count(":") >= 2 and original_url_cleaned.count("/") > 4
        
        if is_potential_livestream_url:
            try:
                parsed_url = urlparse(original_url_cleaned)
                # Heurística para URLs comuns de live (ex: IPTV Smarters)
                path_segments = parsed_url.path.strip('/').split('/')
                
                # Check if the path already contains common stream indicators
                if not any(seg in ['live', 'series', 'movie', 'hls'] for seg in path_segments):
                     # Attempt to insert '/live' if it doesn't seem like a structured stream path
                     if len(path_segments) > 0 and path_segments[0]: # Ensure not empty path or just '/'
                        new_path = '/live/' + '/'.join(path_segments)
                     else: # Path is just '/' or empty
                        new_path = '/live'
                     
                     new_url = parsed_url._replace(path=new_path).geturl()
                else:
                    new_url = original_url_cleaned # Already seems structured

                # Ensure it ends in .m3u8 if it's a generic video stream
                if not new_url.endswith('.m3u8'):
                    # Try to replace common video extensions
                    new_url = re.sub(r'\.(mkv|mp4|avi|flv|mov|ts)(\?.*)?$', '.m3u8\\2', new_url, flags=re.IGNORECASE)
                    if not new_url.endswith('.m3u8'): # If not replaced, append .m3u8
                        new_url = new_url + '.m3u8'

                if new_url != original_url_cleaned:
                    logger.info(f"URL convertida para M3U8 heurística: {url} -> {new_url}")
                    url = new_url # Use the modified URL
            except Exception as e:
                logger.warning(f"Falha ao tentar converter URL para M3U8 ({url}): {e}")
                pass
        return url

    def _make_request_with_doh(self, url, headers, stream=False, head=False, timeout=10):
        """Faz uma requisição HTTP(S), opcionalmente usando DoH e com retries."""
        parsed_original_url = urlparse(url)
        hostname = parsed_original_url.hostname
        
        ip = query_doh(hostname) if hostname else None
        
        req_url = url
        effective_headers = headers.copy()

        if ip:
            # Reconstruct URL with IP to bypass local DNS, but keep original hostname in Host header
            req_url = parsed_original_url._replace(netloc=f"{ip}:{parsed_original_url.port}" if parsed_original_url.port else ip).geturl()
            effective_headers["Host"] = hostname
            logger.debug(f"Usando IP {ip} (via DoH) para {hostname}. URL de requisição: {req_url}")
        else:
            logger.warning(f"Falha ao resolver {hostname} via DoH ou hostname ausente. Usando DNS do sistema para {url}.")

        s = self.get_session() # Usa a sessão HTTP persistente
        
        try:
            if head:
                response = s.head(req_url, headers=effective_headers, timeout=timeout, allow_redirects=True)
            else:
                response = s.get(req_url, headers=effective_headers, stream=stream, timeout=timeout, allow_redirects=True)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            logger.error(f"ERRO na requisição para {req_url}: {e}")
            raise # Re-lança a exceção após o log

    def _handle_ts_request(self, target_url, current_headers):
        """Lida com requisições de segmentos .ts, buscando no buffer ou na origem."""
        global GLOBAL_URL

        # Tenta resolver a URL completa do segmento
        if not target_url.startswith('http') and GLOBAL_URL:
            # Join target_url with GLOBAL_URL considering if GLOBAL_URL is a directory or file
            # Example: GLOBAL_URL = http://example.com/live/stream/playlist.m3u8
            #          target_url = segment123.ts
            # Result: http://example.com/live/stream/segment123.ts
            parsed_global = urlparse(GLOBAL_URL)
            if target_url.startswith('/'): # Absolute path from root
                full_url = f"{parsed_global.scheme}://{parsed_global.netloc}{target_url}"
            else: # Relative path from current global URL's directory
                # Check if GLOBAL_URL refers to a file (e.g., playlist.m3u8) or a directory
                global_path_parts = parsed_global.path.split('/')
                if '.' in global_path_parts[-1]: # GLOBAL_URL is a file
                    base_path = '/'.join(global_path_parts[:-1])
                else: # GLOBAL_URL is a directory or root
                    base_path = parsed_global.path
                
                full_url = f"{parsed_global.scheme}://{parsed_global.netloc}{base_path.rstrip('/')}/{target_url}"
                
            full_url = re.sub(r'(?<!:)/{2,}', '/', full_url) # Limpa barras duplicadas
            logger.debug(f"Resolvendo URL relativa do TS: {target_url} -> {full_url}")
        else:
            full_url = target_url
        
        # Tenta pegar do buffer primeiro
        buffered_data = stream_buffer.get_segment(full_url)
        if buffered_data:
            logger.info(f"Servindo segmento TS do buffer: {full_url}")
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                self.wfile.write(buffered_data[0]) 
            except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                logger.warning(f"Conexão interrompida ao enviar TS do buffer: {e}")
            return 

        logger.info(f"Segmento TS não encontrado no buffer, buscando na origem: {full_url}")
        try:
            r = self._make_request_with_doh(full_url, current_headers, stream=True, timeout=10)
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            segment_data = b''
            for chunk in r.iter_content(chunk_size=8192): # Tamanho de chunk otimizado
                if chunk:
                    segment_data += chunk
                    try:
                        self.wfile.write(chunk)
                    except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                        logger.warning(f"Conexão interrompida ao enviar TS: {e}")
                        break
            r.close()
            # Adiciona o segmento recém-baixado ao buffer.
            # A sequence_number pode ser inferida se tivermos o playlist_sequence e o índice.
            # Para TS, é difícil inferir o seq_num sem a playlist, mas podemos passar None.
            stream_buffer.add_segment(full_url, segment_data, time.time(), sequence_number=None) 
        except requests.exceptions.RequestException as e:
            logger.error(f"Falha ao buscar segmento TS {full_url}: {e}")
            self.send_error(404, f"Falha ao buscar TS: {e}")
        except Exception as e:
            logger.exception(f"ERRO inesperado ao processar TS {full_url}: {e}")
            self.send_error(500, f"Erro interno ao processar TS: {e}")

    def _handle_m3u8_request(self, target_url, current_headers):
        """Lida com requisições de playlists .m3u8, aplicando timeshift se solicitado."""
        global GLOBAL_URL

        timeshift_seconds = self._get_timeshift_param()
        if timeshift_seconds > 0:
            logger.info(f"Timeshift de {timeshift_seconds} segundos solicitado para {target_url}")

        try:
            r = self._make_request_with_doh(target_url, current_headers, timeout=10)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            playlist_content = r.text
            
            parsed_response_url = urlparse(r.url) # Use the final URL after redirects

            # Determine the base URL for relative segments based on the final playlist URL
            path_parts = parsed_response_url.path.split('/')
            if len(path_parts) > 1 and ('.' in path_parts[-1] or path_parts[-1] == ''):
                # If the last part has an extension (like .m3u8) or is empty, it's a file, so base is its directory
                base_path_for_segments = '/'.join(path_parts[:-1])
            else:
                # Otherwise, it's a directory or root
                base_path_for_segments = parsed_response_url.path

            if not base_path_for_segments.startswith('/'):
                 base_path_for_segments = '/' + base_path_for_segments
            if len(base_path_for_segments) > 1 and base_path_for_segments.endswith('/'):
                 base_path_for_segments = base_path_for_segments[:-1]
            
            GLOBAL_URL = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{base_path_for_segments}"
            logger.info(f"GLOBAL_URL base para segmentos definida como: {GLOBAL_URL}")

            processed_lines = []
            current_segment_duration = 0.0
            original_media_sequence = -1 
            segments_in_playlist = [] # Para armazenar (segment_url, index_in_playlist)

            lines = playlist_content.splitlines()
            for i, line in enumerate(lines):
                line = line.strip()
                if not line:
                    continue

                if line.startswith('#EXTINF:'):
                    try:
                        duration_match = re.search(r'#EXTINF:([\d.]+),', line)
                        if duration_match:
                            current_segment_duration = float(duration_match.group(1))
                            if stream_buffer.segment_duration == 0 or stream_buffer.segment_duration != current_segment_duration:
                                stream_buffer.segment_duration = current_segment_duration
                                logger.debug(f"Segment duration set to: {current_segment_duration}s")
                    except ValueError:
                        pass 
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                    try:
                        original_media_sequence = int(line.split(':')[1])
                        # This line will be re-added below if timeshift is applied, otherwise append original
                        processed_lines.append(line) 
                    except ValueError:
                        processed_lines.append(line)
                elif line.startswith('#EXT-X-TARGETDURATION:'):
                    try:
                        td = int(line.split(':')[1])
                        if stream_buffer.segment_duration == 0 or stream_buffer.segment_duration != float(td):
                            stream_buffer.segment_duration = float(td)
                            logger.debug(f"Target duration set to: {td}s")
                    except ValueError:
                        pass
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-KEY'):
                    # Proxy encryption key URIs if they are relative
                    if 'URI="' in line and not '://' in line.split('URI="')[1].split('"')[0]:
                        key_uri_part = line.split('URI="')[1].split('"')[0]
                        if key_uri_part.startswith('/'):
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(parsed_response_url.scheme)}%3A%2F%2F{quote_plus(parsed_response_url.netloc)}{quote_plus(key_uri_part)}"
                        else:
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(GLOBAL_URL.rstrip('/') + '/' + key_uri_part)}"
                        line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri}"')
                        logger.info(f"Chave URI proxyada: {line}")
                    processed_lines.append(line)
                elif line.startswith('#'):
                    processed_lines.append(line)
                else: # This is a segment URL
                    full_original_segment_url = ""
                    if line.startswith('http://') or line.startswith('https://'):
                        full_original_segment_url = line
                    elif line.startswith('/'):
                        full_original_segment_url = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{line}"
                    else:
                        full_original_segment_url = f"{GLOBAL_URL.rstrip('/')}/{line}"
                    
                    # Store original segments for potential timeshift re-writing
                    segments_in_playlist.append({
                        'url': full_original_segment_url,
                        'duration': current_segment_duration,
                        'sequence': original_media_sequence + len(segments_in_playlist) if original_media_sequence != -1 else None
                    })

                    # Proxy the segment URL
                    proxied_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(full_original_segment_url)}"
                    processed_lines.append(proxied_url)
            
            # --- Ajuste de MEDIA-SEQUENCE para Timeshift (Melhorado) ---
            final_playlist_lines = []
            if timeshift_seconds > 0 and stream_buffer.segment_duration > 0 and original_media_sequence != -1:
                # Aim for a point in the past relative to the latest buffered segment
                target_timestamp = stream_buffer.last_segment_timestamp - timeshift_seconds
                if target_timestamp <= 0: 
                    target_timestamp = time.time() - timeshift_seconds # Fallback if buffer is empty or too new
                    logger.warning(f"Target timestamp for timeshift was non-positive; using current time - timeshift: {target_timestamp:.2f}")

                adjusted_seq, found_ts = stream_buffer.get_sequence_for_timeshift(target_timestamp)

                if adjusted_seq is not None:
                    # Filter segments in the playlist to only include those from adjusted_seq onwards
                    # And adjust the MEDIA-SEQUENCE tag
                    
                    # Rebuild the playlist from 'processed_lines' but with adjusted sequence
                    # Find where MEDIA-SEQUENCE is, and the segment URLs
                    
                    found_media_sequence_line = False
                    found_program_date_time_line = False

                    # First, add the header lines up to the first segment or ENDLIST
                    for line in lines: # Iterate original lines to preserve original comments/tags
                        line = line.strip()
                        if not line: continue

                        if line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                            final_playlist_lines.append(f"#EXT-X-MEDIA-SEQUENCE:{adjusted_seq}")
                            logger.info(f"MEDIA-SEQUENCE ajustada para {adjusted_seq} (timeshift {timeshift_seconds}s para TS {found_ts:.2f})")
                            found_media_sequence_line = True
                        elif line.startswith('#EXT-X-PROGRAM-DATE-TIME:'):
                            if found_ts:
                                adjusted_dt = datetime.fromtimestamp(found_ts)
                                final_playlist_lines.append(f"#EXT-X-PROGRAM-DATE-TIME:{adjusted_dt.isoformat()}Z")
                                logger.info(f"PROGRAM-DATE-TIME ajustado para {adjusted_dt.isoformat()}Z")
                            else:
                                final_playlist_lines.append(line) # Keep original if no found_ts
                            found_program_date_time_line = True
                        elif line.startswith('#EXTINF:') or not line.startswith('#'):
                            # Stop processing headers once we hit the first segment or EXTINF tag
                            # We will re-add segments below based on adjusted_seq
                            break 
                        else:
                            # Proxy #EXT-X-KEY if it's a relative URI before adding
                            if line.startswith('#EXT-X-KEY') and 'URI="' in line and not '://' in line.split('URI="')[1].split('"')[0]:
                                key_uri_part = line.split('URI="')[1].split('"')[0]
                                if key_uri_part.startswith('/'):
                                    proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(parsed_response_url.scheme)}%3A%2F%2F{quote_plus(parsed_response_url.netloc)}{quote_plus(key_uri_part)}"
                                else:
                                    proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(GLOBAL_URL.rstrip('/') + '/' + key_uri_part)}"
                                line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri}"')
                            final_playlist_lines.append(line)
                    
                    # If MEDIA-SEQUENCE or PROGRAM-DATE-TIME were not found in original, add them now
                    if not found_media_sequence_line:
                         final_playlist_lines.insert(0, f"#EXT-X-MEDIA-SEQUENCE:{adjusted_seq}")
                    if not found_program_date_time_line and found_ts:
                         adjusted_dt = datetime.fromtimestamp(found_ts)
                         # Insert after MEDIA-SEQUENCE if possible
                         if found_media_sequence_line:
                             final_playlist_lines.insert(final_playlist_lines.index(f"#EXT-X-MEDIA-SEQUENCE:{adjusted_seq}") + 1, f"#EXT-X-PROGRAM-DATE-TIME:{adjusted_dt.isoformat()}Z")
                         else:
                             final_playlist_lines.insert(0, f"#EXT-X-PROGRAM-DATE-TIME:{adjusted_dt.isoformat()}Z")

                    # Now, add only the segments from the adjusted sequence onwards
                    for segment_info in segments_in_playlist:
                        # Assuming segment_info['sequence'] is relative to original_media_sequence
                        # or None if not determinable
                        if segment_info['sequence'] is not None and segment_info['sequence'] >= adjusted_seq:
                            # Re-find the corresponding original EXTINF line (or re-create it)
                            # This needs careful matching or a more robust parsing
                            # For simplicity, let's assume we can re-create EXTINF
                            
                            # Find the original EXTINF line for this segment URL in processed_lines
                            # (or simply append the corresponding lines from the original playlist)
                            # This part is tricky if the playlist is complex (e.g., #EXT-X-BYTERANGE, #EXT-X-DISCONTINUITY)
                            # For a simple HLS, this usually works:
                            segment_line_idx = -1
                            try:
                                # Find the index of the proxied URL for this segment
                                proxied_seg_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(segment_info['url'])}"
                                segment_line_idx = processed_lines.index(proxied_seg_url)
                                # The EXTINF line is usually right before the segment URL
                                if segment_line_idx > 0 and processed_lines[segment_line_idx - 1].startswith('#EXTINF:'):
                                    final_playlist_lines.append(processed_lines[segment_line_idx - 1]) # EXTINF
                                final_playlist_lines.append(proxied_seg_url) # Segment URL
                            except ValueError:
                                logger.warning(f"Segment URL {proxied_seg_url} not found in processed lines for timeshift adjustment.")
                                # Fallback: append if not found, or rethink segment filtering.
                                # For robustness, might need to re-parse original lines more carefully
                                # and track EXTINF to segment mapping during the initial parse.
                                # For now, we'll rely on it being there.

                        elif segment_info['sequence'] is None: # If sequence not determinable, just add all from original
                            # This path might lead to incorrect timeshift if sequence is crucial and missing
                            # For now, it will simply append all segments if sequence not available
                            # This needs a more robust segment parsing and tracking
                            pass # Skip segments before the adjusted sequence
                    
                    # Add any remaining tags like #EXT-X-ENDLIST
                    for line in lines:
                        if line.startswith('#EXT-X-ENDLIST'):
                            final_playlist_lines.append(line)
                            break # Only one ENDLIST expected
                    
                    final_playlist = "\n".join(final_playlist_lines)
                else:
                    logger.warning(f"Não foi possível encontrar uma sequência para timeshift de {timeshift_seconds}s. Servindo playlist original.")
                    final_playlist = "\n".join(processed_lines) # Fallback to original processed playlist
            else:
                final_playlist = "\n".join(processed_lines)

            self.wfile.write(final_playlist.encode("utf-8"))
            r.close()

        except requests.exceptions.RequestException as e:
            logger.error(f"Falha ao buscar M3U8 {target_url}: {e}")
            self.send_error(404, f"Falha ao buscar M3U8: {e}")
        except Exception as e:
            logger.exception(f"ERRO inesperado ao processar M3U8 {target_url}: {e}")
            self.send_error(500, f"Erro interno ao processar M3U8: {e}")

    def _handle_generic_request(self, target_url, current_headers):
        """Lida com requisições genéricas (ex: .html) como se fossem TS (tentativa de stream)."""
        logger.warning(f"Lidando com requisição genérica {target_url} como se fosse TS.")
        self._handle_ts_request(target_url, current_headers)

    def _shutdown_server(self):
        """Agenda o desligamento do servidor."""
        logger.info("Agendando desligamento do servidor...")
        req_shutdown()

    def _process_request(self, method_is_head=False):
        """Lida com a lógica principal da requisição GET ou HEAD."""
        global GLOBAL_HEADERS, GLOBAL_URL

        original_path = self.path

        if original_path == '/check':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"OK")
            return
        elif original_path == '/stop':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"Stopping server...")
            self._shutdown_server() 
            return
        elif original_path == '/buffer_info': 
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            
            # Garante que os timestamps sejam floats para JSON serialização
            segments_info = [
                {"url": url, "timestamp": ts, "sequence": seq} 
                for url, (data, ts, seq) in stream_buffer.segments.items()
            ]

            info = {
                "buffered_segments_count": len(stream_buffer.segments),
                "max_segments_capacity": stream_buffer.max_segments,
                "timeshift_buffer_seconds": stream_buffer.timeshift_buffer_seconds,
                "first_segment_url": list(stream_buffer.segments.keys())[0] if stream_buffer.segments else None,
                "last_segment_url": list(stream_buffer.segments.keys())[-1] if stream_buffer.segments else None,
                "global_url": GLOBAL_URL,
                "segment_duration": stream_buffer.segment_duration,
                "last_segment_timestamp": stream_buffer.last_segment_timestamp,
                "buffered_segments": segments_info # Adiciona detalhes dos segmentos
            }
            self.wfile.write(json.dumps(info, indent=2).encode('utf-8'))
            return

        target_url_from_param = self._get_parsed_url_param()
        
        current_headers = GLOBAL_HEADERS.copy()

        # Logic to reset state when starting a new main stream
        if original_path.startswith('/?url=') and target_url_from_param:
            # Clean target_url_from_param before comparison, to avoid false positives due to embedded headers
            cleaned_target_url = self.clean_url_from_headers_params(target_url_from_param)
            new_potential_base_url = urlparse(cleaned_target_url)._replace(query='', fragment='').geturl()
            current_global_base = urlparse(GLOBAL_URL)._replace(query='', fragment='').geturl()
            
            if ('.m3u8' in cleaned_target_url and new_potential_base_url != current_global_base) or \
               (not GLOBAL_URL and cleaned_target_url.startswith('http')): # First HTTP request with ?url=
                logger.info(f"Nova URL principal detectada: {target_url_from_param}. Resetando estado.")
                self._reset_stream_state()
                current_headers = GLOBAL_HEADERS.copy() # Re-initialize headers after reset

            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
            
            # The URL to actually fetch should be the cleaned version without embedded header params
            target_url_for_fetching = self.clean_url_from_headers_params(target_url_from_param)

        elif target_url_from_param: # Cases where ?url= is present but it's not the start of a new 'main' stream
            target_url_for_fetching = self.clean_url_from_headers_params(target_url_from_param)
            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
        else: # Requests without ?url= (e.g., relative segments, /check, /stop)
            target_url_for_fetching = original_path

        # Apply URL conversion before routing
        processed_target_url = target_url_for_fetching
        if processed_target_url.startswith('http'):
            processed_target_url = self.convert_to_m3u8_url(target_url_for_fetching)
        
        if not processed_target_url.startswith('http') and not GLOBAL_URL and not original_path.startswith('/'):
            self.send_error(400, "URL base não definida para caminho relativo e sem parâmetro 'url'.")
            return

        # Routing based on file type
        # Prioritize checking for extensions in the *processed* URL
        if '.m3u8' in processed_target_url:
            logger.debug(f"Roteando para M3U8: {processed_target_url}")
            if method_is_head: 
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.end_headers() 
                return
            self._handle_m3u8_request(processed_target_url, current_headers)
        elif '.ts' in processed_target_url or ('/hl' in processed_target_url and not processed_target_url.endswith(".m3u8")):
            logger.debug(f"Roteando para TS: {processed_target_url}")
            if method_is_head: 
                self.send_response(200)
                self.send_header('Content-type', 'video/mp2t')
                self.end_headers() 
                return
            self._handle_ts_request(processed_target_url, current_headers)
        elif target_url_from_param and (target_url_from_param.endswith(".html") or target_url_from_param.endswith(".php") or not '.' in urlparse(target_url_from_param).path.split('/')[-1]):
            # If it's a ?url= request and doesn't have a specific media extension, treat as generic
            logger.debug(f"Roteando para genérico (original .html/.php etc): {processed_target_url}")
            if method_is_head: 
                self.send_response(200)
                self.end_headers() 
                return
            self._handle_generic_request(processed_target_url, current_headers)
        elif not target_url_from_param and ('.m3u8' in original_path or '.ts' in original_path or '/hl' in original_path):
            # Handle relative paths that already contain the extension (e.g., from an M3U8 playlist itself)
            if '.m3u8' in original_path:
                logger.debug(f"Roteando para M3U8 (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-Type', 'application/vnd.apple.mpegurl'); self.end_headers(); return
                self._handle_m3u8_request(original_path, current_headers)
            elif '.ts' in original_path or '/hl' in original_path:
                logger.debug(f"Roteando para TS (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-type', 'video/mp2t'); self.end_headers(); return
                self._handle_ts_request(original_path, current_headers)
        else:
            if target_url_from_param:
                 logger.warning(f"Tipo de URL não explicitamente tratado via ?url=: {target_url_from_param}. Tentando como genérico.")
                 if method_is_head: self.send_response(200); self.end_headers(); return
                 self._handle_generic_request(processed_target_url, current_headers)
            else:
                 logger.error(f"Path não reconhecido: {original_path}")
                 self.send_error(404, "Recurso não encontrado ou tipo não suportado.")

    def do_HEAD(self):
        self._process_request(method_is_head=True)
    
    def do_GET(self):
        self._process_request(method_is_head=False)

GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}

# httpd is no longer a global variable, but managed by MediaServer instance
# httpd = None 

class MediaServer:
    def __init__(self):
        self.server_thread = None
        self.httpd_instance = None
        # _stop_event is implicitly handled by ThreadingHTTPServer.shutdown() now
        # self._stop_event = threading.Event() 

    def is_in_use(self):
        """Verifica se a porta do servidor está em uso."""
        # If the server is already running and managed by this instance
        if self.httpd_instance and self.server_thread and self.server_thread.is_alive():
            return True
        
        # Otherwise, try to connect to see if the port is occupied by something else
        # Use 'with' statement for proper socket closure
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.1)
            try:
                s.bind((HOST_NAME, PORT_NUMBER)) # Try to bind, not connect
                s.listen(1)
                logger.debug(f"Porta {PORT_NUMBER} está livre.")
                return False
            except socket.error as e:
                logger.warning(f"Porta {PORT_NUMBER} em uso por outro processo ou instância não gerenciada: {e}")
                return True

    def start(self):
        if not self.is_in_use():
            logger.info("Iniciando servidor HTTP MediaServer...")
            try:
                # Use ThreadingHTTPServer for concurrent request handling
                self.httpd_instance = ThreadingHTTPServer((HOST_NAME, PORT_NUMBER), Handler)
                
                self.server_thread = threading.Thread(target=self.httpd_instance.serve_forever)
                self.server_thread.daemon = True # Allow main program to exit even if server thread is alive
                self.server_thread.start()
                
                # Small delay for the thread to start and server to bind
                time.sleep(0.5) 
                if self.server_thread.is_alive():
                    logger.info(f"MediaServer iniciado com sucesso em http://{HOST_NAME}:{PORT_NUMBER}")
                else:
                    logger.error("Falha ao iniciar MediaServer: thread do servidor não iniciou.")
                    self.httpd_instance = None
            except Exception as e:
                logger.error(f"Erro ao iniciar MediaServer na porta {PORT_NUMBER}: {e}")
                self.httpd_instance = None
        else:
            logger.info("MediaServer já está em execução ou a porta está ocupada.")

    def stop(self):
        """Para o servidor HTTP se estiver em execução."""
        logger.info("Solicitando parada do MediaServer...")
        if self.httpd_instance:
            # shutdown() needs to be called from a different thread than serve_forever()
            # to avoid deadlock, so it's typically called in a separate thread or via a client request
            # Since we are stopping it from the main thread, this is fine.
            self.httpd_instance.shutdown() 
            self.httpd_instance.server_close()
            logger.info("Aguardando thread do servidor finalizar...")
            if self.server_thread and self.server_thread.is_alive():
                 self.server_thread.join(timeout=5)
            if self.server_thread and not self.server_thread.is_alive():
                 logger.info("Thread do servidor finalizada.")
            else:
                 logger.warning("Timeout ao esperar thread do servidor, ou thread não encontrada/não finalizada.")

            self.httpd_instance = None
            self.server_thread = None
            logger.info("MediaServer parado.")
        else:
            logger.info("MediaServer não estava em execução (instância httpd não encontrada).")
            # Attempt to send a stop request if it's running but not managed by this process's instance
            try:
                requests.get(f'http://{HOST_NAME}:{PORT_NUMBER}/stop', timeout=1) # Increased timeout slightly
            except requests.exceptions.ConnectionError:
                logger.debug(f"Nenhum servidor encontrado na porta {PORT_NUMBER} para enviar comando de parada externo.")
            except Exception as e:
                logger.warning(f"Erro ao tentar parar servidor externo: {e}")


def req_shutdown():
    """Função de nível de módulo para solicitar o desligamento do servidor."""
    global _media_server_instance
    if _media_server_instance:
        logger.info("req_shutdown() chamado. Solicitando parada do MediaServer.")
        _media_server_instance.stop()
    else:
        logger.warning("req_shutdown() chamado, mas MediaServer não está ativo ou inicializado.")


def prepare_url(url_to_proxy, custom_headers_dict=None, timeshift_seconds=0):
    """
    Prepara a URL para ser usada com o servidor proxy local.
    Adiciona cabeçalhos customizados à URL de forma codificada e timeshift.
    """
    try:
        # It's crucial to unquote the input URL if it was already quoted before being passed to this function
        # This prevents double-encoding issues.
        url_to_proxy_decoded = unquote_plus(url_to_proxy)
        url_to_proxy_decoded = unquote(url_to_proxy_decoded)
    except Exception as e:
        logger.warning(f"Erro ao decodificar URL de entrada '{url_to_proxy}': {e}. Usando URL original.")
        url_to_proxy_decoded = url_to_proxy # Fallback to original if decoding fails

    parsed_original = urlparse(url_to_proxy_decoded)
    # Start with the original URL's path and query as base for modification
    # This prevents accidentally adding header params to the base URL itself, only its query
    base_url_for_params = parsed_original.geturl() # Keep original query string

    combined_query_params = parse_qs(parsed_original.query, keep_blank_values=True) # Parse original query, keep blank values

    if custom_headers_dict:
        # Add custom headers as query parameters, ensuring keys are unique and values are encoded
        # Use a consistent prefix to avoid collision with legitimate URL parameters
        for key, value in custom_headers_dict.items():
            param_key = f"h_{key.lower()}" # Use a prefix like 'h_'
            combined_query_params[param_key] = [value] 
            logger.debug(f"Adicionando header param: {param_key}={value}")

    if timeshift_seconds > 0:
        combined_query_params['timeshift'] = [str(timeshift_seconds)]
        logger.debug(f"Adicionando timeshift param: {timeshift_seconds}")

    # Reconstruct the query string from the combined parameters
    # urlencode handles proper quoting
    new_query_string = urlencode(combined_query_params, doseq=True)
    
    # Reconstruct the final URL to be encoded for the proxy
    # Use _replace to put the new query string back
    effective_url_to_proxy = parsed_original._replace(query=new_query_string).geturl()

    encoded_target_url = quote_plus(effective_url_to_proxy)
    
    final_proxy_url = f'http://{HOST_NAME}:{PORT_NUMBER}/?url={encoded_target_url}'
    logger.debug(f"URL Original: {url_to_proxy_decoded}")
    logger.debug(f"URL Efetiva para proxy: {effective_url_to_proxy}")
    logger.debug(f"URL Final do Proxy: {final_proxy_url}")
    return final_proxy_url


if __name__ == '__main__':
    _media_server_instance = MediaServer() 
    _media_server_instance.start()

    # Exemplo de uso:
    test_m3u8_url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    proxied_url = prepare_url(test_m3u8_url)
    logger.info(f"URL do Proxy para o cliente (VLC, Kodi): {proxied_url}")

    # Exemplo com timeshift de 60 segundos
    proxied_url_timeshift = prepare_url(test_m3u8_url, timeshift_seconds=60)
    logger.info(f"URL do Proxy com Timeshift de 60s: {proxied_url_timeshift}")

    # Exemplo com custom headers (Referer e User-Agent)
    custom_headers_example = {
        'Referer': 'http://example.com/player/',
        'User-Agent': 'MyCustomPlayer/1.0'
    }
    proxied_url_with_headers = prepare_url(test_m3u8_url, custom_headers_example)
    logger.info(f"URL do Proxy com headers customizados: {proxied_url_with_headers}")

    # Exemplo com URL já contendo parâmetros (que seriam passados para o destino)
    test_m3u8_url_with_params = "https://example.com/live/stream.m3u8?token=abc&id=123"
    proxied_url_with_params = prepare_url(test_m3u8_url_with_params)
    logger.info(f"URL do Proxy com params originais: {proxied_url_with_params}")

    logger.info(f"\nServidor rodando. Acesse http://{HOST_NAME}:{PORT_NUMBER}/check para verificar.")
    logger.info(f"Para ver informações do buffer: http://{HOST_NAME}:{PORT_NUMBER}/buffer_info")
    logger.info(f"Para parar o servidor, acesse http://{HOST_NAME}:{PORT_NUMBER}/stop ou pressione Ctrl+C.")

    try:
        # Keep the main thread alive while the server threads run in the background
        # Use a simple loop with sleep to prevent busy-waiting if there's no joinable thread
        while True:
            if _media_server_instance and _media_server_instance.server_thread and _media_server_instance.server_thread.is_alive():
                time.sleep(1) # Sleep to avoid busy-waiting
            else:
                logger.info("Servidor não está mais ativo ou não foi iniciado. Saindo.")
                break # Exit if the server thread is no longer running
    except KeyboardInterrupt:
        logger.info("\nInterrupção de teclado no script principal. Parando o servidor...")
    finally:
        _media_server_instance.stop()
        logger.info("Script principal finalizado.")