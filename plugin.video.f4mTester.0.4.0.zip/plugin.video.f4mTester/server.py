import six
import os
import threading
import socket
import requests # Mantido porque o código original o utiliza extensivamente.
import time
import json
import collections
import re
from datetime import datetime, timedelta
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import logging
import socketserver

# Configuração de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode  # Python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # Python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from SimpleHTTPServer import SimpleHTTPRequestHandler

# Custom HTTPServer that uses threading for handling requests
class ThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True # Ensures threads are shut down when the main program exits

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 65321
DOH_SERVER_URL = "https://dns.nextdns.io/37d9d4" # Exemplo de servidor DoH
DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

# Globais para estado do stream atual. Serão resetados para novos canais.
GLOBAL_HEADERS = {}
GLOBAL_URL = '' # Base URL para segmentos relativos, refletindo a URL final da playlist.

# Instância global do servidor para acesso externo e gerenciamento de parada
_media_server_instance = None

# Fila para pré-carregamento de segmentos
preload_queue = collections.deque()
preload_worker_thread = None
preload_running = threading.Event() # Evento para controlar o worker de pré-carregamento

# --- Funções auxiliares para manipulação de URL e Cabeçalhos ---
def get_headers_from_url_params(url_with_params):
    """
    Extrai cabeçalhos (Referer, Origin, Cookie, User-Agent) de uma string de URL que os contém como parâmetros.
    Assume que os cabeçalhos podem estar como query params prefixados com 'h_'.
    Retorna um dicionário com os cabeçalhos extraídos.
    """
    custom_headers = {}
    try:
        # Divide a URL no primeiro '|' para separar a URL base dos parâmetros de cabeçalho
        # Ex: http://stream.com/playlist.m3u8|h_referer=http://site.com&h_user-agent=CustomUA
        url_parts = url_with_params.split('|', 1)
        if len(url_parts) > 1:
            header_params_str = url_parts[1]
            for param_pair in header_params_str.split('&'):
                if '=' in param_pair:
                    key, value = param_pair.split('=', 1)
                    key = unquote_plus(key).strip()
                    value = unquote_plus(value).strip()
                    # Verifica se a chave é um cabeçalho padrão com prefixo 'h_'
                    if key.lower().startswith('h_'):
                        original_header_name = key[2:].replace('-', '_').title().replace('_', '-') # Convert h_user-agent to User-Agent
                        if original_header_name in ['Referer', 'Origin', 'Cookie', 'User-Agent']:
                            custom_headers[original_header_name] = value
                            logger.debug(f"Header encontrado via '|' separado: {original_header_name}={value}")
        
        # Também extrai de query parameters padrão se estiverem presentes
        # Isso é mais comum quando o prepare_url é usado para adicionar headers
        parsed_url = urlparse(url_parts[0]) # Usa a parte da URL antes do '|'
        query_params = parse_qs(parsed_url.query)

        for key, value_list in query_params.items():
            if value_list: # Ensure there's a value
                lower_key = key.lower()
                if lower_key.startswith('h_'):
                    original_header_name = lower_key[2:].replace('-', '_').title().replace('_', '-') # Convert h_user-agent to User-Agent
                    if original_header_name in ['Referer', 'Origin', 'Cookie', 'User-Agent']:
                        custom_headers[original_header_name] = unquote_plus(value_list[0])
                        logger.debug(f"Header encontrado em query param '{key}': {value_list[0]}")
                # Também verifica por nomes de cabeçalho diretos (sem h_) caso sejam passados assim
                elif lower_key in ['referer', 'origin', 'cookie', 'user-agent']:
                    custom_headers[lower_key.capitalize()] = unquote_plus(value_list[0])
                    logger.debug(f"Header direto encontrado em query param '{key}': {value_list[0]}")

    except Exception as e:
        logger.warning(f"Erro ao parsear cabeçalhos de '{url_with_params}': {e}")

    return custom_headers

def clean_url_from_headers_params(url):
    """
    Remove parâmetros customizados de cabeçalho (ex: h_referer, h_user-agent) e timeshift
    de uma URL, e remove a parte da URL após o separador '|' se presente.
    """
    # Remove custom separator if present
    if '|' in url:
        url = url.split('|')[0]
    
    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)
    
    clean_query = {}
    for key, value in query_params.items():
        lower_key = key.lower()
        # Remove known header query params (both prefixed and non-prefixed, and timeshift)
        if not (lower_key.startswith('h_') and lower_key[2:] in ['referer', 'origin', 'cookie', 'user-agent']) and \
           not (lower_key in ['referer', 'origin', 'cookie', 'user-agent', 'timeshift']):
            clean_query[key] = value # Keep original key case for non-header params
    
    # Reconstruct the URL without header params and timeshift
    if clean_query:
        # urlencode com doseq=True lida com múltiplos valores para a mesma chave
        return parsed._replace(query=urlencode(clean_query, doseq=True)).geturl()
    else:
        return parsed._replace(query='').geturl()
# --- Fim das Funções auxiliares ---


# --- Gerenciamento de Buffer de Stream ---
class StreamBuffer:
    def __init__(self, max_segments=50, timeshift_buffer_seconds=1024): 
        self.segments = collections.OrderedDict() # {segment_url: (data, timestamp, sequence_number)}
        self.max_segments = max_segments
        self.timeshift_buffer_seconds = timeshift_buffer_seconds # Quanto tempo de stream manter no buffer
        self.lock = threading.Lock()
        self.playlist_sequence = -1 # Para rastrear a sequência da playlist HLS
        self.segment_duration = 0.0 # Duração média dos segmentos para cálculo de timeshift
        self.last_segment_timestamp = 0.0 # Timestamp do último segmento adicionado

    def add_segment(self, url, data, timestamp=None, sequence_number=None):
        with self.lock:
            ts = timestamp if timestamp is not None else time.time()
            self.segments[url] = (data, ts, sequence_number)
            self.last_segment_timestamp = ts
            
            self._cleanup_buffer()
            
            logger.debug(f"Segmento adicionado/atualizado no buffer: {url} (Seq: {sequence_number}, TS: {ts:.2f})")

    def get_segment(self, url):
        with self.lock:
            return self.segments.get(url)

    def _cleanup_buffer(self):
        """Remove segmentos que estão fora do limite de tempo ou do número máximo."""
        if not self.segments:
            return

        current_time = time.time()
        
        # Remove segmentos muito antigos (fora da janela de timeshift)
        urls_to_remove = []
        for url, (data, ts, seq) in list(self.segments.items()):
            if ts is not None and (current_time - ts) > self.timeshift_buffer_seconds:
                urls_to_remove.append(url)
            else:
                break # Segments are ordered, so stop when not expired (assuming they are added chronologically)
        
        for url in urls_to_remove:
            self.segments.pop(url)
            logger.debug(f"Segmento antigo removido do buffer por TTL: {url}")

        # Remove segments exceeding max count, starting from the oldest
        while len(self.segments) > self.max_segments:
            oldest_url = next(iter(self.segments))
            self.segments.pop(oldest_url)
            logger.debug(f"Segmento removido do buffer por limite de contagem: {oldest_url}")

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.playlist_sequence = -1
            self.segment_duration = 0.0
            self.last_segment_timestamp = 0.0
            logger.info("Buffer de stream limpo.")

    def get_buffered_segment_urls(self):
        with self.lock:
            return list(self.segments.keys())

    def get_sequence_for_timeshift(self, target_time_epoch):
        """
        Tenta encontrar a sequence number e o timestamp de um segmento no buffer que esteja próximo do target_time_epoch.
        target_time_epoch: timestamp (float) em segundos desde a Epoch.
        Retorna (sequence number, timestamp do segmento encontrado) ou (None, None).
        """
        with self.lock:
            best_match_seq = None
            best_match_ts = None
            min_time_diff = float('inf')

            # Itera do segmento mais recente para o mais antigo
            for url, (data, segment_ts, segment_seq) in reversed(self.segments.items()):
                if segment_ts is None or segment_seq is None:
                    continue

                time_diff = target_time_epoch - segment_ts

                # Prioriza segmentos que estão ligeiramente mais antigos ou no tempo alvo
                # Considera uma margem de +/- metade da duração do segmento
                if time_diff >= -(self.segment_duration / 2) : 
                    abs_time_diff = abs(time_diff)
                    if abs_time_diff < min_time_diff:
                        min_time_diff = abs_time_diff
                        best_match_seq = segment_seq
                        best_match_ts = segment_ts
                
                # Se já passamos muito do tempo alvo para segmentos muito mais antigos, pare
                if segment_ts < target_time_epoch - (self.segment_duration * 3 if self.segment_duration > 0 else 10):
                    break
            
            if best_match_seq is not None:
                logger.info(f"Timeshift: Encontrado segmento seq {best_match_seq} (TS: {best_match_ts:.2f}) "
                            f"para target {target_time_epoch:.2f} (diff {min_time_diff:.2f}s)")
                return best_match_seq, best_match_ts
            else:
                logger.warning(f"Timeshift: Nenhum segmento encontrado no buffer para o tempo alvo {target_time_epoch:.2f}s.")
                return None, None

stream_buffer = StreamBuffer() # Instância global do buffer

# Cache para resultados DoH para reduzir requisições repetidas
doh_cache = collections.OrderedDict()
DOH_CACHE_MAX_SIZE = 100
DOH_CACHE_TTL = 300 # 5 minutos de TTL

def is_ip_address(hostname):
    """
    Checks if the given string is an IPv4 or IPv6 address.
    """
    try:
        socket.inet_aton(hostname) # Check IPv4
        return True
    except socket.error:
        try:
            socket.inet_pton(socket.AF_INET6, hostname) # Check IPv6
            return True
        except socket.error:
            return False

def query_doh(domain, record_type="A", doh_server=DOH_SERVER_URL, timeout=5):
    """
    Resolve um domínio usando DNS over HTTPS e retorna o endereço IP, com caching.
    :param domain: O nome de domínio a ser resolvido.
    :param record_type: O tipo de registro DNS (padrão "A" para IPv4).
    :param doh_server: A URL do servidor DoH.
    :param timeout: Tempo limite da requisição em segundos.
    :return: O endereço IP resolvido (string) ou None se a resolução falhar.
    """
    if not domain:
        logger.warning("Domínio vazio fornecido para resolução DoH.")
        return None
    
    if is_ip_address(domain):
        logger.debug(f"O domínio '{domain}' é um endereço IP, ignorando resolução DoH.")
        return domain # If it's already an IP, return it directly

    # Verifica o cache primeiro
    if domain in doh_cache:
        ip, timestamp = doh_cache[domain]
        if (time.time() - timestamp) < DOH_CACHE_TTL:
            logger.debug(f"Usando cache DoH para {domain}: {ip}")
            return ip
        else:
            logger.info(f"Cache DoH expirado para {domain}, removendo.")
            doh_cache.pop(domain) # Remove item expirado

    headers = {
        "Accept": "application/dns-json",
        "User-Agent": DEFAULT_USER_AGENT
    }
    
    # Session with retries for DoH requests
    session = requests.Session()
    retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('http://', HTTPAdapter(max_retries=retries))
    session.mount('https://', HTTPAdapter(max_retries=retries))

    try:
        logger.info(f"Tentando resolver {domain} via DoH com servidor: {doh_server}")
        r = session.get(doh_server, headers=headers, params={"name": domain, "type": record_type}, timeout=timeout)
        r.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
        
        data = r.json()
        if "Answer" in data:
            for answer in data["Answer"]:
                if answer.get("type") == 1:  # Type 1 is A record (IPv4)
                    ip = answer.get("data")
                    if ip:
                        doh_cache[domain] = (ip, time.time())
                        if len(doh_cache) > DOH_CACHE_MAX_SIZE:
                            doh_cache.popitem(last=False) # Remove o mais antigo (FIFO)
                        logger.info(f"DoH resolvido com sucesso para {domain}: {ip}")
                        return ip
            logger.warning(f"Nenhum registro A válido encontrado na resposta DoH para {domain}.")
            return None
        else:
            logger.warning(f"Resposta DoH para {domain} não contém seção 'Answer' ou está vazia.")
            return None
    except requests.exceptions.Timeout:
        logger.error(f"Timeout ao tentar resolver {domain} via DoH em {doh_server}.")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Erro na requisição DoH para {domain}: {e}")
        return None
    except json.JSONDecodeError as e:
        logger.error(f"Erro ao decodificar JSON da resposta DoH para {domain}: {e}.")
        return None
    except Exception as e:
        logger.error(f"Erro inesperado na requisição DoH para {domain}: {e}")
        return None

# Worker de pré-carregamento de segmentos
def preload_worker():
    while preload_running.is_set():
        try:
            if preload_queue:
                segment_url, segment_seq, segment_duration = preload_queue.popleft()
                if not stream_buffer.get_segment(segment_url): # Só baixa se não estiver já no buffer
                    logger.info(f"Pré-carregando segmento: {segment_url} (Seq: {segment_seq})")
                    try:
                        # Reutiliza o session para fazer a requisição do segmento
                        # Headers devem ser os atuais, GLOBAL_HEADERS não é thread-safe para este uso
                        # Para este worker, podemos usar um UA padrão ou considerar os headers do stream principal
                        # Por simplicidade, usaremos um requests.Session novo aqui.
                        current_headers = GLOBAL_HEADERS.copy() # Copia para evitar modificações externas
                        
                        r = requests.get(segment_url, headers=current_headers, stream=True, timeout=10)
                        r.raise_for_status()
                        
                        segment_data = b''
                        for chunk in r.iter_content(chunk_size=8192):
                            if chunk:
                                segment_data += chunk
                        r.close()
                        stream_buffer.add_segment(segment_url, segment_data, sequence_number=segment_seq)
                        logger.debug(f"Segmento {segment_url} pré-carregado com sucesso.")
                    except requests.exceptions.RequestException as e:
                        logger.warning(f"Falha ao pré-carregar segmento {segment_url}: {e}")
                    except Exception as e:
                        logger.warning(f"Erro inesperado ao pré-carregar segmento {segment_url}: {e}")
                else:
                    logger.debug(f"Segmento {segment_url} já no buffer, pulando pré-carregamento.")
            else:
                time.sleep(0.05) # Espera um pouco se a fila estiver vazia
        except Exception as e:
            logger.error(f"Erro no worker de pré-carregamento: {e}")
            time.sleep(1) # Evita loop rápido em caso de erro persistente

class Handler(SimpleHTTPRequestHandler):
    # Desativa o log padrão do SimpleHTTPRequestHandler para usar nosso logger
    def log_message(self, format, *args):
        logger.debug(format % args) # Keep debug level for noisy default logs

    _session = None # Definir a sessão aqui para reutilização

    @classmethod
    def get_session(cls):
        if cls._session is None:
            cls._session = requests.Session()
            retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
            cls._session.mount('http://', HTTPAdapter(max_retries=retries))
            cls._session.mount('https://', HTTPAdapter(max_retries=retries))
        return cls._session

    def _reset_stream_state(self):
        """Reseta o estado global para um novo stream."""
        global GLOBAL_HEADERS, GLOBAL_URL
        logger.info("Resetando estado do stream global (headers e base URL).")
        GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}
        GLOBAL_URL = ''
        stream_buffer.clear() # Limpa o buffer ao mudar de canal
        preload_queue.clear() # Limpa a fila de pré-carregamento também
        # A thread do worker de pré-carregamento deve ser reiniciada ou garantida que está rodando
        start_preload_worker_if_not_running()


    def _get_parsed_url_param(self):
        """Extrai e decodifica o parâmetro 'url' do caminho da requisição."""
        try:
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            
            raw_param = query_params.get('url', [None])[0]
            if raw_param:
                # Decode multiple times to handle nested encoding
                decoded_param = unquote_plus(raw_param)
                decoded_param = unquote(decoded_param) 
                return decoded_param
            return None
        except Exception as e:
            logger.error(f"Erro ao decodificar parâmetro URL '{self.path}': {e}")
            return None

    def _get_timeshift_param(self):
        """Extrai o parâmetro 'timeshift' do caminho da requisição."""
        try:
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            timeshift_str = query_params.get('timeshift', [None])[0]
            if timeshift_str:
                return int(timeshift_str)
            return 0 
        except (ValueError, TypeError) as e:
            logger.warning(f"Timeshift param inválido: '{timeshift_str}'. Usando 0. Erro: {e}")
            return 0
        except Exception as e:
            logger.error(f"Erro ao extrair parâmetro timeshift: {e}")
            return 0
    
    def convert_to_m3u8_url(self, url):
        """
        Converte uma URL de stream genérica para uma URL .m3u8 se aplicável,
        aplicando heurísticas para URLs de livestream comuns.
        """
        original_url_cleaned = clean_url_from_headers_params(url)
        parsed_url = urlparse(original_url_cleaned)
        path = parsed_url.path.lower()
        
        # Se já termina em .m3u8 ou .m3u, não faz nada
        if path.endswith(('.m3u8', '.m3u')):
            return original_url_cleaned
        
        # Heurística para URLs que podem ser livestreams mas não têm extensão explícita
        # ou têm extensões de vídeo comuns.
        # Prioriza a adição de .m3u8
        if (
            not any(ext in path for ext in ['.ts', '.mp4', '.mkv', '.avi', '.flv', '.mov']) and
            parsed_url.netloc and
            path.count('/') > 2 
        ) or any(ext in path for ext in ['.mp4', '.mkv', '.avi', '.flv', '.mov']):
            
            # Se já tem uma extensão de vídeo, tenta substituir
            if re.search(r'\.(mkv|mp4|avi|flv|mov|ts)(\?.*)?$', path, re.IGNORECASE):
                # Usar re.sub com uma função de substituição para lidar com a parte da query string
                def replace_ext_with_m3u8(match):
                    return '.m3u8' + (match.group(2) if match.group(2) else '')
                new_url = re.sub(r'\.(mkv|mp4|avi|flv|mov|ts)(\?.*)?$', replace_ext_with_m3u8, original_url_cleaned, flags=re.IGNORECASE)
                logger.info(f"URL de vídeo convertida para M3U8: {original_url_cleaned} -> {new_url}")
                return new_url
            
            # Se não tem extensão aparente mas parece uma URL de stream (ex: /live/channel)
            # Tenta adicionar .m3u8 no final
            if not path.split('/')[-1].count('.'): # Last segment of path has no dot
                new_url = original_url_cleaned.rstrip('/') + '/playlist.m3u8' # Adiciona um nome padrão
                logger.info(f"URL genérica convertida para M3U8 heurística: {original_url_cleaned} -> {new_url}")
                return new_url

        return original_url_cleaned # Retorna a original se nenhuma heurística se aplicar

    def _make_request_with_doh(self, url, headers, stream=False, head=False, timeout=10):
        """
        Faz uma requisição HTTP(S) usando requests, opcionalmente usando DoH e com retries.
        Retorna o objeto de resposta do requests.
        """
        parsed_original_url = urlparse(url)
        hostname = parsed_original_url.hostname
        
        req_url = url
        effective_headers = headers.copy()
        
        ip = None
        if hostname and not is_ip_address(hostname):
            ip = query_doh(hostname, timeout=timeout) # query_doh já tem retries
        elif hostname and is_ip_address(hostname):
            logger.debug(f"O hostname '{hostname}' é um endereço IP, ignorando resolução DoH.")
            ip = hostname # Use o IP diretamente
        else:
            logger.debug(f"Hostname ausente na URL {url}. Usando URL direta.")

        if ip and ip != hostname:
            # Reconstruir a URL para usar o IP, mas manter o Host header com o hostname original
            if parsed_original_url.scheme == 'https':
                # Para HTTPS, não podemos simplesmente substituir o hostname pelo IP
                # e esperar que o certificado SSL ainda funcione, a menos que o certificado
                # inclua o IP como SAN ou o servidor suporte SNI com IP.
                # A abordagem mais segura é confiar no sistema DNS subjacente
                # para resolver o hostname para o IP.
                # Se o DoH é usado, é para resolver o DNS no lado do cliente.
                # requests ainda fará sua própria resolução se não usarmos um adaptador de transporte customizado.
                # A melhor prática aqui é apenas garantir que o Host header esteja correto.
                req_url = url # Usa a URL original com hostname
                effective_headers["Host"] = hostname # Garante que o Host header correto seja enviado
                logger.debug(f"DoH resolveu {hostname} para {ip}. Requisição HTTPS usará o hostname original '{hostname}' com Host header explícito.")
            else: # Para HTTP, é mais direto substituir
                req_url = parsed_original_url._replace(netloc=f"{ip}:{parsed_original_url.port}" if parsed_original_url.port else ip).geturl()
                effective_headers["Host"] = hostname # Garante que o Host header correto seja enviado
                logger.debug(f"DoH resolveu {hostname} para {ip}. Requisição HTTP para {req_url} com Host header '{hostname}'.")
        elif hostname:
            effective_headers["Host"] = hostname
            logger.debug(f"Não usando DoH para {hostname} (já um IP ou falha na resolução). Requisição usará a URL original.")
        else:
            logger.debug(f"Sem hostname. Requisição usará a URL: {req_url}")

        session = self.get_session()
        try:
            logger.info(f"Fazendo requisição {'HEAD' if head else 'GET'} para {req_url}")
            if head:
                r = session.head(req_url, headers=effective_headers, timeout=timeout)
            else:
                r = session.get(req_url, headers=effective_headers, stream=stream, timeout=timeout)
            r.raise_for_status() # Lança HTTPError para respostas de erro (4xx ou 5xx)
            logger.info(f"Requisição bem-sucedida para {req_url}. Status: {r.status_code}")
            return r
        except requests.exceptions.RequestException as e:
            logger.error(f"ERRO na requisição para {req_url}: {e}")
            raise # Re-lança a exceção após o log

    def _handle_ts_request(self, target_url, current_headers):
        """Lida com requisições de segmentos .ts, buscando no buffer ou na origem."""
        global GLOBAL_URL

        full_url = target_url
        if not target_url.startswith('http') and GLOBAL_URL:
            # urljoin é mais robusto para lidar com URLs relativas
            full_url = requests.compat.urljoin(GLOBAL_URL, target_url) 
            logger.debug(f"Resolvendo URL relativa do TS: {target_url} -> {full_url}")
        
        buffered_data = stream_buffer.get_segment(full_url)
        if buffered_data:
            logger.info(f"Servindo segmento TS do buffer: {full_url}")
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                self.wfile.write(buffered_data[0]) 
            except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                logger.warning(f"Conexão interrompida ao enviar TS do buffer: {e}")
            return 

        logger.info(f"Segmento TS não encontrado no buffer, buscando na origem: {full_url}")
        try:
            r = self._make_request_with_doh(full_url, current_headers, stream=True, timeout=10)
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            # Copia os cabeçalhos de resposta relevantes da origem
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']: # Evita cabeçalhos problemáticos
                    self.send_header(header, value)
            self.end_headers()
            
            segment_data = b''
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    segment_data += chunk
                    try:
                        self.wfile.write(chunk)
                    except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                        logger.warning(f"Conexão interrompida ao enviar TS: {e}")
                        break # Sai do loop de escrita se a conexão cair
            r.close()
            # Adiciona o segmento recém-baixado ao buffer.
            # Não temos o sequence_number aqui para TS individual, mas o timestamp é suficiente.
            stream_buffer.add_segment(full_url, segment_data, time.time(), sequence_number=None) 
        except requests.exceptions.RequestException as e:
            logger.error(f"Falha ao buscar segmento TS {full_url}: {e}")
            self.send_error(404, f"Falha ao buscar TS: {e}")
        except Exception as e:
            logger.exception(f"ERRO inesperado ao processar TS {full_url}: {e}")
            self.send_error(500, f"Erro interno ao processar TS: {e}")


    def _handle_m3u8_request(self, target_url, current_headers):
        """Lida com requisições de playlists .m3u8, aplicando timeshift se solicitado."""
        global GLOBAL_URL

        timeshift_seconds = self._get_timeshift_param()
        if timeshift_seconds > 0:
            logger.info(f"Timeshift de {timeshift_seconds} segundos solicitado para {target_url}")

        try:
            r = self._make_request_with_doh(target_url, current_headers, timeout=10)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Access-Control-Allow-Origin', '*')
            # Copia os cabeçalhos de resposta relevantes da origem
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                    self.send_header(header, value)
            self.end_headers()
            
            playlist_content = r.text # Use .text para conteúdo de texto
            
            # ATENÇÃO: Use r.url (a URL final após redirecionamentos) para definir GLOBAL_URL
            parsed_response_url = urlparse(r.url) 

            # Garante que GLOBAL_URL é a base correta para URLs relativas na playlist.
            # Remove o último segmento (se for um arquivo) para obter o diretório base.
            base_url_for_segments = parsed_response_url._replace(query='', fragment='').geturl()
            if not base_url_for_segments.endswith('/') and '.' in base_url_for_segments.split('/')[-1]:
                base_url_for_segments = base_url_for_segments.rsplit('/', 1)[0] + '/'
            elif not base_url_for_segments.endswith('/'):
                base_url_for_segments += '/'

            GLOBAL_URL = base_url_for_segments
            logger.info(f"GLOBAL_URL base para segmentos definida como: {GLOBAL_URL}")

            processed_lines = []
            current_segment_duration = 0.0
            original_media_sequence = -1 
            segments_in_playlist = [] # Para armazenar (segment_url, duration, sequence_number, program_date_time)
            
            current_program_date_time = None

            lines = playlist_content.splitlines()
            for i, line in enumerate(lines):
                line = line.strip()
                if not line:
                    processed_lines.append('')
                    continue

                if line.startswith('#EXTINF:'):
                    try:
                        duration_match = re.search(r'#EXTINF:([\d.]+),', line)
                        if duration_match:
                            current_segment_duration = float(duration_match.group(1))
                            if stream_buffer.segment_duration == 0 or abs(stream_buffer.segment_duration - current_segment_duration) > 0.001:
                                stream_buffer.segment_duration = current_segment_duration
                                logger.debug(f"Duração do segmento HLS definida como: {current_segment_duration}s")
                    except ValueError:
                        pass 
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                    try:
                        original_media_sequence = int(line.split(':')[1])
                        processed_lines.append(line) 
                    except ValueError:
                        processed_lines.append(line)
                elif line.startswith('#EXT-X-TARGETDURATION:'):
                    try:
                        td = int(line.split(':')[1])
                        if stream_buffer.segment_duration == 0 or abs(stream_buffer.segment_duration - float(td)) > 0.001:
                            stream_buffer.segment_duration = float(td)
                            logger.debug(f"Target duration set to: {td}s")
                    except ValueError:
                        pass
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-PROGRAM-DATE-TIME:'):
                    try:
                        dt_str = line.split(':', 1)[1]
                        # Tenta parsear com ou sem fuso horário (Z ou +/-HH:MM)
                        # Remove a parte do fuso horário para compatibilidade de parsing se for Python < 3.7
                        dt_str_no_tz = dt_str.split('+')[0]
                        if dt_str_no_tz.endswith('Z'):
                            dt_obj = datetime.strptime(dt_str_no_tz, '%Y-%m-%dT%H:%M:%S.%fZ')
                        elif '.' in dt_str_no_tz: # Assume microsegundos
                            dt_obj = datetime.strptime(dt_str_no_tz, '%Y-%m-%dT%H:%M:%S.%f')
                        else:
                            dt_obj = datetime.strptime(dt_str_no_tz, '%Y-%m-%dT%H:%M:%S')

                        current_program_date_time = dt_obj.timestamp()
                    except ValueError:
                        logger.warning(f"Não foi possível parsear PROGRAM-DATE-TIME: {dt_str}")
                        current_program_date_time = None
                    processed_lines.append(line)

                elif line.startswith('#EXT-X-KEY'):
                    # Proxy encryption key URIs if they are relative
                    if 'URI="' in line:
                        uri_match = re.search(r'URI="([^"]+)"', line)
                        if uri_match:
                            key_uri_part = uri_match.group(1)
                            # Se a URI é relativa OU a URI da chave tem um caminho sem schema, assumimos que é relativo à playlist
                            if not '://' in key_uri_part and not key_uri_part.startswith('/'): 
                                # Construir a URL absoluta da chave baseada na GLOBAL_URL
                                proxied_key_uri_full = requests.compat.urljoin(GLOBAL_URL, key_uri_part)
                                # Em seguida, proxear via nosso servidor
                                proxied_key_uri_for_client = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(proxied_key_uri_full)}"
                                line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri_for_client}"')
                                logger.info(f"Chave URI proxyada: {proxied_key_uri_full} -> {proxied_key_uri_for_client}")
                            elif key_uri_part.startswith('//'): # Protocol-relative URL
                                # Prepend scheme from GLOBAL_URL
                                scheme = urlparse(GLOBAL_URL).scheme
                                if scheme:
                                    proxied_key_uri_full = f"{scheme}:{key_uri_part}"
                                else:
                                    proxied_key_uri_full = f"http:{key_uri_part}" # Fallback to http
                                proxied_key_uri_for_client = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(proxied_key_uri_full)}"
                                line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri_for_client}"')
                                logger.info(f"Chave URI proxyada (protocol-relative): {proxied_key_uri_full} -> {proxied_key_uri_for_client}")
                            elif key_uri_part.startswith('/'): # Absolute path relative to host
                                # Reconstruct absolute URL with GLOBAL_URL's scheme and netloc
                                parsed_global = urlparse(GLOBAL_URL)
                                proxied_key_uri_full = parsed_global._replace(path=key_uri_part, query='', fragment='').geturl()
                                proxied_key_uri_for_client = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(proxied_key_uri_full)}"
                                line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri_for_client}"')
                                logger.info(f"Chave URI proxyada (absolute path): {proxied_key_uri_full} -> {proxied_key_uri_for_client}")
                    processed_lines.append(line)
                elif line.startswith('#'):
                    processed_lines.append(line)
                else: # This is a segment URL
                    # Construir URL absoluta do segmento
                    full_original_segment_url = requests.compat.urljoin(GLOBAL_URL, line)
                    
                    segment_seq = original_media_sequence + len(segments_in_playlist) if original_media_sequence != -1 else None
                    segment_ts = None
                    if current_program_date_time is not None and current_segment_duration > 0:
                        # Estimar o timestamp do segmento se PROGRAM-DATE-TIME for usado
                        segment_ts = current_program_date_time + (len(segments_in_playlist) * current_segment_duration)

                    segments_in_playlist.append({
                        'url': full_original_segment_url,
                        'duration': current_segment_duration,
                        'sequence': segment_seq,
                        'program_date_time': segment_ts
                    })

                    # Proxy the segment URL
                    proxied_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(full_original_segment_url)}"
                    processed_lines.append(proxied_url)
            
            # --- Adicionar segmentos para pré-carregamento ---
            num_segments_to_preload = 3 # Define quantos segmentos pré-carregar
            for i, segment_info in enumerate(segments_in_playlist):
                if i < num_segments_to_preload:
                    if not stream_buffer.get_segment(segment_info['url']): # Só adiciona se não estiver no buffer
                        preload_queue.append((segment_info['url'], segment_info['sequence'], segment_info['duration']))
                        logger.debug(f"Adicionado para pré-carregamento: {segment_info['url']} (Seq: {segment_info['sequence']})")
                else:
                    break # Só pré-carrega os primeiros N

            # --- Ajuste de MEDIA-SEQUENCE e PROGRAM-DATE-TIME para Timeshift ---
            final_playlist_lines = []
            if timeshift_seconds > 0 and stream_buffer.segment_duration > 0 and original_media_sequence != -1:
                # O tempo alvo é o tempo atual do último segmento no buffer menos o timeshift
                target_timestamp = stream_buffer.last_segment_timestamp - timeshift_seconds
                if target_timestamp <= 0: 
                    target_timestamp = time.time() - timeshift_seconds # Fallback se buffer vazio ou muito novo
                    logger.warning(f"Target timestamp para timeshift era <= 0; usando tempo atual - timeshift: {target_timestamp:.2f}")

                adjusted_seq, found_ts = stream_buffer.get_sequence_for_timeshift(target_timestamp)

                if adjusted_seq is not None:
                    found_media_sequence_line = False
                    found_program_date_time_line = False

                    # Iterar sobre as linhas processadas (que já têm as URLs proxyadas)
                    # e reescrever MEDIA-SEQUENCE e PROGRAM-DATE-TIME
                    for line in processed_lines:
                        line_stripped = line.strip()
                        if line_stripped.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                            final_playlist_lines.append(f"#EXT-X-MEDIA-SEQUENCE:{adjusted_seq}")
                            logger.info(f"MEDIA-SEQUENCE ajustada para {adjusted_seq} (timeshift {timeshift_seconds}s para TS {found_ts:.2f})")
                            found_media_sequence_line = True
                        elif line_stripped.startswith('#EXT-X-PROGRAM-DATE-TIME:'):
                            if found_ts:
                                adjusted_dt = datetime.fromtimestamp(found_ts)
                                # Formato com milissegundos para HLS, usando Z para UTC (se apropriado)
                                final_playlist_lines.append(f"#EXT-X-PROGRAM-DATE-TIME:{adjusted_dt.isoformat()}Z")
                                logger.info(f"PROGRAM-DATE-TIME ajustado para {adjusted_dt.isoformat()}Z")
                            else:
                                final_playlist_lines.append(line_stripped) 
                            found_program_date_time_line = True
                        elif line_stripped.startswith('#EXTINF:') or not line_stripped.startswith('#'):
                            # Já adicionamos os cabeçalhos até aqui, agora vamos lidar com os segmentos
                            # Adiciona qualquer linha que não seja um cabeçalho ou #EXTINF.
                            # Os segmentos serão adicionados abaixo com base na sequência ajustada.
                            break 
                        else:
                            final_playlist_lines.append(line_stripped)
                    
                    # Se MEDIA-SEQUENCE ou PROGRAM-DATE-TIME não estavam na playlist original, adicione-os
                    if not found_media_sequence_line:
                        # Adiciona no início da playlist, ou após #EXTM3U
                        try:
                            idx = next(i for i, l in enumerate(final_playlist_lines) if l.startswith("#EXTM3U"))
                            final_playlist_lines.insert(idx + 1, f"#EXT-X-MEDIA-SEQUENCE:{adjusted_seq}")
                        except StopIteration:
                            final_playlist_lines.insert(0, f"#EXT-X-MEDIA-SEQUENCE:{adjusted_seq}")
                    
                    if not found_program_date_time_line and found_ts:
                        adjusted_dt = datetime.fromtimestamp(found_ts)
                        # Tenta inserir após MEDIA-SEQUENCE ou no início
                        try:
                            idx = next(i for i, l in enumerate(final_playlist_lines) if l.startswith("#EXT-X-MEDIA-SEQUENCE:"))
                            final_playlist_lines.insert(idx + 1, f"#EXT-X-PROGRAM-DATE-TIME:{adjusted_dt.isoformat()}Z")
                        except StopIteration:
                            final_playlist_lines.insert(0, f"#EXT-X-PROGRAM-DATE-TIME:{adjusted_dt.isoformat()}Z")


                    # Adiciona apenas os segmentos a partir da sequência ajustada
                    for segment_info in segments_in_playlist:
                        if segment_info['sequence'] is not None and segment_info['sequence'] >= adjusted_seq:
                            proxied_seg_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(segment_info['url'])}"
                            
                            final_playlist_lines.append(f"#EXTINF:{segment_info['duration']:.3f},") 
                            final_playlist_lines.append(proxied_seg_url)
                        elif segment_info['sequence'] is None: 
                            # Se a sequência não é determinável (ex: playlist sem MEDIA-SEQUENCE),
                            # podemos optar por incluir tudo ou ser mais rigorosos. 
                            # Por enquanto, se timeshift está ativo e seq é None, pula.
                            pass 

                    # Adiciona qualquer tag #EXT-X-ENDLIST se estiver presente
                    for line_orig in lines:
                        if line_orig.strip().startswith('#EXT-X-ENDLIST'):
                            final_playlist_lines.append(line_orig.strip())
                            break
                    
                    final_playlist = "\n".join(final_playlist_lines)
                else:
                    logger.warning(f"Não foi possível encontrar uma sequência para timeshift de {timeshift_seconds}s. Servindo playlist original.")
                    final_playlist = "\n".join(processed_lines) # Fallback to original processed playlist
            else:
                final_playlist = "\n".join(processed_lines)

            self.wfile.write(final_playlist.encode("utf-8"))
            r.close()

        except requests.exceptions.RequestException as e:
            logger.error(f"Falha ao buscar M3U8 {target_url}: {e}")
            self.send_error(404, f"Falha ao buscar M3U8: {e}")
        except Exception as e:
            logger.exception(f"ERRO inesperado ao processar M3U8 {target_url}: {e}")
            self.send_error(500, f"Erro interno ao processar M3U8: {e}")

    def _handle_generic_request(self, target_url, current_headers, method_is_head):
        """Lida com requisições genéricas, tentando proxyar o conteúdo."""
        logger.info(f"Lidando com requisição genérica: {target_url}")
        try:
            r = self._make_request_with_doh(target_url, current_headers, stream=True, head=method_is_head, timeout=15)
            
            self.send_response(r.status_code)
            # Copy headers from upstream response
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']: # Avoid problematic headers
                    self.send_header(header, value)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            if not method_is_head:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                        except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                            logger.warning(f"Conexão interrompida ao enviar dados genéricos: {e}")
                            break
            r.close()
        except requests.exceptions.RequestException as e:
            logger.error(f"Falha ao buscar recurso genérico {target_url}: {e}")
            self.send_error(e.response.status_code if e.response else 500, f"Falha ao buscar recurso: {e}")
        except Exception as e:
            logger.exception(f"ERRO inesperado ao processar requisição genérica {target_url}: {e}")
            self.send_error(500, f"Erro interno ao processar requisição: {e}")

    def _shutdown_server(self):
        """Agenda o desligamento do servidor."""
        logger.info("Agendando desligamento do servidor...")
        req_shutdown()

    def _process_request(self, method_is_head=False):
        """Lida com a lógica principal da requisição GET ou HEAD."""
        global GLOBAL_HEADERS, GLOBAL_URL

        original_path = self.path

        if original_path == '/check':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"OK")
            return
        elif original_path == '/stop':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"Stopping server...")
            self._shutdown_server() 
            return
        elif original_path == '/buffer_info': 
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            
            segments_info = [
                {"url": url, "timestamp": ts, "sequence": seq} 
                for url, (data, ts, seq) in stream_buffer.segments.items()
            ]

            info = {
                "buffered_segments_count": len(stream_buffer.segments),
                "max_segments_capacity": stream_buffer.max_segments,
                "timeshift_buffer_seconds": stream_buffer.timeshift_buffer_seconds,
                "first_segment_url": list(stream_buffer.segments.keys())[0] if stream_buffer.segments else None,
                "last_segment_url": list(stream_buffer.segments.keys())[-1] if stream_buffer.segments else None,
                "global_url": GLOBAL_URL,
                "segment_duration": stream_buffer.segment_duration,
                "last_segment_timestamp": stream_buffer.last_segment_timestamp,
                "buffered_segments": segments_info 
            }
            self.wfile.write(json.dumps(info, indent=2).encode('utf-8'))
            return

        target_url_from_param = self._get_parsed_url_param()
        
        current_headers = GLOBAL_HEADERS.copy()

        # Logic to reset state when starting a new main stream
        if original_path.startswith('/?url=') and target_url_from_param:
            cleaned_target_url_base = clean_url_from_headers_params(target_url_from_param)
            
            # Use parsed_url to get scheme, netloc and path, ignoring query/fragment for base comparison
            new_potential_base_url_parsed = urlparse(cleaned_target_url_base)
            # Normalize path for comparison (e.g., remove trailing slashes if not root)
            new_potential_base_url = new_potential_base_url_parsed._replace(query='', fragment='').geturl().rstrip('/')
            if new_potential_base_url == new_potential_base_url_parsed.scheme + '://' + new_potential_base_url_parsed.netloc: # It's a root
                pass # keep as is
            
            current_global_base_parsed = urlparse(GLOBAL_URL)
            current_global_base = current_global_base_parsed._replace(query='', fragment='').geturl().rstrip('/')
            if current_global_base == current_global_base_parsed.scheme + '://' + current_global_base_parsed.netloc: # It's a root
                pass # keep as is

            is_new_stream_m3u8_like = ('.m3u8' in new_potential_base_url_parsed.path.lower() or '.m3u' in new_potential_base_url_parsed.path.lower())
            is_first_http_request = (not GLOBAL_URL and new_potential_base_url_parsed.scheme in ('http', 'https'))

            # Reset only if it's a new m3u8 stream or the very first http/https request
            if (is_new_stream_m3u8_like and new_potential_base_url != current_global_base) or is_first_http_request:
                logger.info(f"Nova URL principal detectada: {target_url_from_param}. Resetando estado do servidor.")
                self._reset_stream_state()
                current_headers = GLOBAL_HEADERS.copy() 

            custom_params_in_url = get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
            
            target_url_for_fetching = cleaned_target_url_base # Use the cleaned URL for actual fetching

        elif target_url_from_param: 
            target_url_for_fetching = clean_url_from_headers_params(target_url_from_param)
            custom_params_in_url = get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
        else: # Direta requisição para um path como /hls/segment.ts
            target_url_for_fetching = original_path

        # Apply URL conversion before routing for http/https URLs
        processed_target_url = target_url_for_fetching
        if processed_target_url.startswith('http'):
            processed_target_url = self.convert_to_m3u8_url(target_url_for_fetching)
        
        # Validate that we have a base URL for relative paths if needed
        if not processed_target_url.startswith('http') and not GLOBAL_URL:
            self.send_error(400, "URL base não definida para caminho relativo e sem parâmetro 'url'.")
            logger.error(f"Erro 400: URL base não definida para {original_path}.")
            return

        # Routing based on file type (case-insensitive checks)
        processed_target_url_lower = processed_target_url.lower()
        
        is_m3u8 = '.m3u8' in processed_target_url_lower or '.m3u' in processed_target_url_lower
        is_ts = '.ts' in processed_target_url_lower or ('/hls/' in processed_target_url_lower and not is_m3u8)

        if is_m3u8:
            logger.debug(f"Roteando para M3U8: {processed_target_url}")
            if method_is_head: 
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.end_headers() 
                return
            self._handle_m3u8_request(processed_target_url, current_headers)
        elif is_ts:
            logger.debug(f"Roteando para TS: {processed_target_url}")
            if method_is_head: 
                self.send_response(200)
                self.send_header('Content-type', 'video/mp2t')
                self.end_headers() 
                return
            self._handle_ts_request(processed_target_url, current_headers)
        else: # Fallback para requisições genéricas (ex: .html, imagens, ou streams desconhecidos)
            logger.debug(f"Roteando para genérico: {processed_target_url}")
            self._handle_generic_request(processed_target_url, current_headers, method_is_head)

    def do_HEAD(self):
        self._process_request(method_is_head=True)
    
    def do_GET(self):
        self._process_request(method_is_head=False)

GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}

class MediaServer:
    def __init__(self):
        self.server_thread = None
        self.httpd_instance = None
        self._is_stopping = threading.Event() # Event to signal stopping

    def is_in_use(self):
        """Verifica se a porta do servidor está em uso."""
        if self.httpd_instance and self.server_thread and self.server_thread.is_alive():
            return True # Server is running within this instance
        
        # Attempt to bind to check if the port is occupied by another process
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.1) 
            try:
                s.bind((HOST_NAME, PORT_NUMBER)) 
                s.listen(1) 
                logger.debug(f"Porta {PORT_NUMBER} está livre.")
                return False
            except socket.error as e:
                logger.warning(f"Porta {PORT_NUMBER} em uso por outro processo ou instância não gerenciada: {e}")
                return True

    def start(self):
        if not self.is_in_use():
            logger.info("Iniciando servidor HTTP MediaServer...")
            self._is_stopping.clear() 
            try:
                self.httpd_instance = ThreadingHTTPServer((HOST_NAME, PORT_NUMBER), Handler)
                
                self.server_thread = threading.Thread(target=self.httpd_instance.serve_forever, daemon=True)
                self.server_thread.start()
                
                # Inicia o worker de pré-carregamento quando o servidor é iniciado
                start_preload_worker_if_not_running()

                # Give a small moment for the thread to start
                time.sleep(0.1) 

                if self.server_thread.is_alive():
                    logger.info(f"MediaServer iniciado com sucesso em http://{HOST_NAME}:{PORT_NUMBER}")
                else:
                    logger.error("Falha ao iniciar MediaServer: thread do servidor não iniciou.")
                    self.httpd_instance = None
            except Exception as e:
                logger.error(f"Erro fatal ao iniciar MediaServer na porta {PORT_NUMBER}: {e}")
                self.httpd_instance = None
        else:
            logger.info("MediaServer já está em execução ou a porta está ocupada.")
            # Garante que o worker de pré-carregamento esteja rodando mesmo se o servidor já estiver ativo
            start_preload_worker_if_not_running()


    def stop(self):
        """Para o servidor HTTP se estiver em execução."""
        if self._is_stopping.is_set():
            logger.info("Solicitação de parada já em andamento.")
            return

        self._is_stopping.set() 
        stop_preload_worker() # Sinaliza para o worker de pré-carregamento parar

        logger.info("Solicitando parada do MediaServer...")
        if self.httpd_instance:
            shutdown_thread = threading.Thread(target=self.httpd_instance.shutdown)
            shutdown_thread.start()
            
            logger.info("Aguardando thread do servidor finalizar...")
            if self.server_thread and self.server_thread.is_alive():
                 self.server_thread.join(timeout=3) # Increased timeout slightly
            
            if self.server_thread and not self.server_thread.is_alive():
                 logger.info("Thread do servidor finalizada.")
            else:
                 logger.warning("Timeout ao esperar thread do servidor, ou thread não encontrada/não finalizada. Tentando fechar o socket diretamente.")
                 if self.httpd_instance:
                    try:
                        self.httpd_instance.server_close()
                        logger.info("Socket do servidor forçadamente fechado.")
                    except Exception as sock_e:
                        logger.warning(f"Erro ao tentar forçar fechamento do socket: {sock_e}")

            self.httpd_instance = None
            self.server_thread = None
            logger.info("MediaServer parado.")
        else:
            logger.info("MediaServer não estava em execução (instância httpd não encontrada).")
            # If our instance isn't running, but the port is in use, try to signal an external server
            if self.is_in_use():
                try:
                    logger.info(f"Tentando enviar comando de parada para possível servidor externo na porta {PORT_NUMBER}.")
                    # Use a short timeout for this attempt
                    requests.get(f'http://{HOST_NAME}:{PORT_NUMBER}/stop', timeout=1) 
                except requests.exceptions.RequestException as e:
                    logger.debug(f"Nenhum servidor encontrado na porta {PORT_NUMBER} para enviar comando de parada externo: {e}")
                except Exception as e:
                    logger.warning(f"Erro ao tentar parar servidor externo: {e}")
            else:
                logger.info("Porta do servidor não está em uso; nenhuma instância para parar.")


def req_shutdown():
    """Função de nível de módulo para solicitar o desligamento do servidor."""
    global _media_server_instance
    if _media_server_instance:
        logger.info("req_shutdown() chamado. Solicitando parada do MediaServer.")
        _media_server_instance.stop()
    else:
        logger.warning("req_shutdown() chamado, mas MediaServer não está ativo ou inicializado.")

def start_preload_worker_if_not_running():
    global preload_worker_thread, preload_running
    if not preload_running.is_set() or (preload_worker_thread and not preload_worker_thread.is_alive()):
        logger.info("Iniciando worker de pré-carregamento de segmentos.")
        preload_running.set()
        preload_worker_thread = threading.Thread(target=preload_worker, daemon=True)
        preload_worker_thread.start()
    else:
        logger.debug("Worker de pré-carregamento já está rodando.")

def stop_preload_worker():
    global preload_running, preload_worker_thread
    if preload_running.is_set():
        logger.info("Sinalizando worker de pré-carregamento para parar.")
        preload_running.clear()
        if preload_worker_thread and preload_worker_thread.is_alive():
            preload_worker_thread.join(timeout=2) # Espera o worker finalizar
            if preload_worker_thread.is_alive():
                logger.warning("Worker de pré-carregamento não finalizou no tempo esperado.")
        preload_worker_thread = None
    preload_queue.clear() # Limpa a fila ao parar


def prepare_url(url_to_proxy, custom_headers_dict=None, timeshift_seconds=0):
    """
    Prepara a URL para ser usada com o servidor proxy local.
    Adiciona cabeçalhos customizados à URL de forma codificada e timeshift.
    """
    try:
        # Decodifica a URL de entrada para garantir que não há dupla codificação
        url_to_proxy_decoded = unquote_plus(url_to_proxy)
        url_to_proxy_decoded = unquote(url_to_proxy_decoded)
    except Exception as e:
        logger.warning(f"Erro ao decodificar URL de entrada '{url_to_proxy}': {e}. Usando URL original.")
        url_to_proxy_decoded = url_to_proxy 

    # Limpa a URL de quaisquer parâmetros de cabeçalho existentes
    cleaned_original_url_for_encoding = clean_url_from_headers_params(url_to_proxy_decoded)
    
    parsed_cleaned = urlparse(cleaned_original_url_for_encoding)
    combined_query_params = parse_qs(parsed_cleaned.query, keep_blank_values=True)

    if custom_headers_dict:
        for key, value in custom_headers_dict.items():
            param_key = f"h_{key.lower()}" 
            combined_query_params[param_key] = [value] 
            logger.debug(f"Adicionando header param: {param_key}={value}")

    if timeshift_seconds > 0:
        combined_query_params['timeshift'] = [str(timeshift_seconds)]
        logger.debug(f"Adicionando timeshift param: {timeshift_seconds}")

    new_query_string = urlencode(combined_query_params, doseq=True)
    
    # Reconstrói a URL com os novos parâmetros de query
    effective_url_to_proxy_parsed = parsed_cleaned._replace(query=new_query_string)
    effective_url_to_proxy = effective_url_to_proxy_parsed.geturl()

    # Codifica a URL efetiva para ser um parâmetro da URL do nosso proxy
    encoded_target_url = quote_plus(effective_url_to_proxy)
    
    final_proxy_url = f'http://{HOST_NAME}:{PORT_NUMBER}/?url={encoded_target_url}'
    logger.debug(f"URL Original: {url_to_proxy_decoded}")
    logger.debug(f"URL Efetiva para proxy (com nossos parâmetros): {effective_url_to_proxy}")
    logger.debug(f"URL Final do Proxy para o cliente: {final_proxy_url}")
    return final_proxy_url


if __name__ == '__main__':
    _media_server_instance = MediaServer() 
    _media_server_instance.start()

    # Exemplos de uso:
    test_m3u8_url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    proxied_url = prepare_url(test_m3u8_url)
    logger.info(f"URL do Proxy para o cliente (VLC, Kodi): {proxied_url}")

    # Exemplo com timeshift de 60 segundos
    proxied_url_timeshift = prepare_url(test_m3u8_url, timeshift_seconds=60)
    logger.info(f"URL do Proxy com Timeshift de 60s: {proxied_url_timeshift}")

    # Exemplo com custom headers (Referer e User-Agent)
    custom_headers_example = {
        'Referer': 'http://example.com/player/',
        'User-Agent': 'MyCustomPlayer/1.0'
    }
    proxied_url_with_headers = prepare_url(test_m3u8_url, custom_headers_example)
    logger.info(f"URL do Proxy com headers customizados: {proxied_url_with_headers}")

    # Exemplo com URL já contendo parâmetros (que seriam passados para o destino)
    test_m3u8_url_with_params = "https://example.com/live/stream.m3u8?token=abc&id=123"
    proxied_url_with_params = prepare_url(test_m3u8_url_with_params)
    logger.info(f"URL do Proxy com params originais: {proxied_url_with_params}")

    # Exemplo com URL contendo um IP (para testar a correção para o problema original)
    test_ip_url = "http://208.115.200.210:80/hls/17641_640.ts?token=0BXqSZzqo8_fATlK5LCVhRxIfOBPKkBtDL-wdNGmD1w9NVX7BAjfUhqQm4-auwrWcPcOspoEfvSPAoDlGgezbVL5kBk62J1ZILkQSXhIYxkPVdcD_PUi6tMG2ocXf_Pp"
    proxied_ip_url = prepare_url(test_ip_url)
    logger.info(f"URL do Proxy com IP direto (não deve tentar DoH para o IP): {proxied_ip_url}")

    logger.info(f"\nServidor rodando. Acesse http://{HOST_NAME}:{PORT_NUMBER}/check para verificar.")
    logger.info(f"Para ver informações do buffer: http://{HOST_NAME}:{PORT_NUMBER}/buffer_info")
    logger.info(f"Para parar o servidor, acesse http://{HOST_NAME}:{PORT_NUMBER}/stop ou pressione Ctrl+C.")

    try:
        while True:
            # Mantém o thread principal vivo enquanto o servidor estiver rodando
            if _media_server_instance and _media_server_instance.server_thread and _media_server_instance.server_thread.is_alive():
                time.sleep(1) 
            else:
                logger.info("Servidor não está mais ativo ou não foi iniciado. Saindo.")
                break 
    except KeyboardInterrupt:
        logger.info("\nInterrupção de teclado no script principal. Parando o servidor...")
    finally:
        _media_server_instance.stop()
        logger.info("Script principal finalizado.")