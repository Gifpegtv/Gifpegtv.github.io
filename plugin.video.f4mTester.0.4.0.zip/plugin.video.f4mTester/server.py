import six
import threading
import socket
import requests # Mantido porque o código original o utiliza extensivamente.
import time
import json
import collections
import re
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import logging
import socketserver

# Configuração de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode  # Python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # Python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from SimpleHTTPServer import SimpleHTTPRequestHandler

# Custom HTTPServer que usa threading para lidar com requisições
class ThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True # Garante que as threads sejam encerradas quando o programa principal sair

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 65321
DOH_SERVER_URL = "https://cloudflare-dns.com/dns-query" # Exemplo de servidor DoH
DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

# Globais para estado do stream atual. Serão resetados para novos canais.
GLOBAL_HEADERS = {}
GLOBAL_URL = '' # URL base para segmentos relativos, refletindo a URL final da playlist.

# Instância global do servidor para acesso externo e gerenciamento de parada
_media_server_instance = None

# Fila para pré-carregamento de segmentos
preload_queue = collections.deque()
preload_worker_thread = None
preload_running = threading.Event() # Evento para controlar o worker de pré-carregamento

# Define o tamanho do chunk para leitura/escrita. Um valor maior reduz a sobrecarga de I/O.
BUFFER_CHUNK_SIZE = 262144 # 256 KB

# --- Funções auxiliares para manipulação de URL e Cabeçalhos ---
def get_headers_from_url_params(url_with_params):
    """
    Extrai cabeçalhos (Referer, Origin, Cookie, User-Agent) de uma string de URL.
    """
    custom_headers = {}
    try:
        url_parts = url_with_params.split('|', 1)
        if len(url_parts) > 1:
            header_params_str = url_parts[1]
            for param_pair in header_params_str.split('&'):
                if '=' in param_pair:
                    key, value = param_pair.split('=', 1)
                    key = unquote_plus(key).strip()
                    value = unquote_plus(value).strip()
                    if key.lower().startswith('h_'):
                        original_header_name = key[2:].replace('-', '_').title().replace('_', '-')
                        if original_header_name in ['Referer', 'Origin', 'Cookie', 'User-Agent']:
                            custom_headers[original_header_name] = value
        
        parsed_url = urlparse(url_parts[0])
        query_params = parse_qs(parsed_url.query)

        for key, value_list in query_params.items():
            if value_list:
                lower_key = key.lower()
                if lower_key.startswith('h_'):
                    original_header_name = lower_key[2:].replace('-', '_').title().replace('_', '-')
                    if original_header_name in ['Referer', 'Origin', 'Cookie', 'User-Agent']:
                        custom_headers[original_header_name] = unquote_plus(value_list[0])
                elif lower_key in ['referer', 'origin', 'cookie', 'user-agent']:
                    custom_headers[lower_key.capitalize()] = unquote_plus(value_list[0])

    except Exception as e:
        logger.warning(f"Erro ao parsear cabeçalhos de '{url_with_params}': {e}")

    return custom_headers

def clean_url_from_headers_params(url):
    """
    Remove parâmetros de cabeçalho customizados e de timeshift da URL.
    """
    if '|' in url:
        url = url.split('|')[0]
    
    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)
    
    clean_query = {
        key: value for key, value in query_params.items()
        if not (key.lower().startswith('h_') and key.lower()[2:] in ['referer', 'origin', 'cookie', 'user-agent']) and \
           not (key.lower() in ['referer', 'origin', 'cookie', 'user-agent', 'timeshift'])
    }
    
    if clean_query:
        return parsed._replace(query=urlencode(clean_query, doseq=True)).geturl()
    else:
        return parsed._replace(query='').geturl()
# --- Fim das Funções auxiliares ---


# --- Gerenciamento de Buffer de Stream ---
class StreamBuffer:
    def __init__(self, max_segments=120, timeshift_buffer_seconds=36000): 
        self.segments = collections.OrderedDict()
        self.max_segments = max_segments
        self.timeshift_buffer_seconds = timeshift_buffer_seconds
        self.lock = threading.Lock()
        self.playlist_sequence = -1
        self.segment_duration = 0.0
        self.last_segment_timestamp = 0.0

    def add_segment(self, url, data, timestamp=None, sequence_number=None):
        with self.lock:
            ts = timestamp if timestamp is not None else time.time()
            self.segments[url] = (data, ts, sequence_number)
            self.last_segment_timestamp = ts
            self._cleanup_buffer()
            logger.debug(f"Segmento adicionado/atualizado no buffer: {url} (Seq: {sequence_number})")

    def get_segment(self, url):
        with self.lock:
            return self.segments.get(url)

    def _cleanup_buffer(self):
        if not self.segments:
            return
        current_time = time.time()
        urls_to_remove = [url for url, (_, ts, _) in list(self.segments.items()) if ts and (current_time - ts) > self.timeshift_buffer_seconds]
        for url in urls_to_remove:
            self.segments.pop(url)
        while len(self.segments) > self.max_segments:
            self.segments.popitem(last=False)

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.playlist_sequence = -1
            self.segment_duration = 0.0
            self.last_segment_timestamp = 0.0
            logger.info("Buffer de stream limpo.")

    def get_sequence_for_timeshift(self, target_time_epoch):
        with self.lock:
            best_match_seq, best_match_ts, min_time_diff = None, None, float('inf')
            for _, (data, segment_ts, segment_seq) in reversed(self.segments.items()):
                if segment_ts and segment_seq:
                    time_diff = target_time_epoch - segment_ts
                    if time_diff >= -(self.segment_duration / 2):
                        abs_time_diff = abs(time_diff)
                        if abs_time_diff < min_time_diff:
                            min_time_diff, best_match_seq, best_match_ts = abs_time_diff, segment_seq, segment_ts
                    if segment_ts < target_time_epoch - (self.segment_duration * 3 if self.segment_duration > 0 else 10):
                        break
            if best_match_seq:
                logger.info(f"Timeshift: Encontrado segmento seq {best_match_seq} para target {target_time_epoch:.2f}")
                return best_match_seq, best_match_ts
            logger.warning(f"Timeshift: Nenhum segmento encontrado para o tempo alvo {target_time_epoch:.2f}s.")
            return None, None

stream_buffer = StreamBuffer()

# Cache para resultados DoH
doh_cache = collections.OrderedDict()
DOH_CACHE_MAX_SIZE = 100
DOH_CACHE_TTL = 300 # 5 minutos

def is_ip_address(hostname):
    try:
        socket.inet_aton(hostname)
        return True
    except socket.error:
        try:
            socket.inet_pton(socket.AF_INET6, hostname)
            return True
        except socket.error:
            return False

def query_doh(domain, record_type="A", doh_server=DOH_SERVER_URL, timeout=5):
    if not domain or is_ip_address(domain):
        return domain
    if domain in doh_cache and (time.time() - doh_cache[domain][1]) < DOH_CACHE_TTL:
        return doh_cache[domain][0]
    
    headers = {"Accept": "application/dns-json", "User-Agent": DEFAULT_USER_AGENT}
    session = requests.Session()
    retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))
    try:
        r = session.get(doh_server, headers=headers, params={"name": domain, "type": record_type}, timeout=timeout)
        r.raise_for_status()
        data = r.json()
        if "Answer" in data:
            for answer in data["Answer"]:
                if answer.get("type") == 1:
                    ip = answer.get("data")
                    doh_cache[domain] = (ip, time.time())
                    if len(doh_cache) > DOH_CACHE_MAX_SIZE:
                        doh_cache.popitem(last=False)
                    return ip
    except requests.exceptions.RequestException as e:
        logger.error(f"Erro na requisição DoH para {domain}: {e}")
    return None

# Worker de pré-carregamento de segmentos
def preload_worker():
    while preload_running.is_set():
        try:
            if preload_queue:
                segment_url, segment_seq, segment_duration = preload_queue.popleft()
                if not stream_buffer.get_segment(segment_url):
                    logger.info(f"Pré-carregando segmento: {segment_url}")
                    try:
                        current_headers = GLOBAL_HEADERS.copy()
                        r = requests.get(segment_url, headers=current_headers, stream=True, timeout=10)
                        r.raise_for_status()
                        segment_data = r.content
                        stream_buffer.add_segment(segment_url, segment_data, timestamp=time.time(), sequence_number=segment_seq)
                    except requests.exceptions.RequestException as e:
                        logger.warning(f"Falha ao pré-carregar segmento {segment_url}: {e}")
            else:
                # OTIMIZAÇÃO DE CPU: Aumentar o tempo de espera para evitar busy-waiting.
                # Um valor maior aqui reduz drasticamente o uso de CPU quando a fila está vazia.
                time.sleep(0.5) 
        except Exception as e:
            logger.error(f"Erro no worker de pré-carregamento: {e}")
            time.sleep(1)

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.debug(format % args)

    _session = None

    @classmethod
    def get_session(cls):
        if cls._session is None:
            cls._session = requests.Session()
            retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
            cls._session.mount('https://', HTTPAdapter(max_retries=retries))
            cls._session.mount('http://', HTTPAdapter(max_retries=retries))
        return cls._session

    def _reset_stream_state(self):
        global GLOBAL_HEADERS, GLOBAL_URL
        logger.info("Resetando estado do stream global.")
        GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}
        GLOBAL_URL = ''
        stream_buffer.clear()
        preload_queue.clear()
        start_preload_worker_if_not_running()

    def _get_parsed_url_param(self):
        try:
            query_params = parse_qs(urlparse(self.path).query)
            raw_param = query_params.get('url', [None])[0]
            return unquote(unquote_plus(raw_param)) if raw_param else None
        except Exception as e:
            logger.error(f"Erro ao decodificar parâmetro URL '{self.path}': {e}")
            return None

    def _get_timeshift_param(self):
        try:
            query_params = parse_qs(urlparse(self.path).query)
            return int(query_params.get('timeshift', [0])[0])
        except (ValueError, TypeError):
            return 0

    def _make_request_with_doh(self, url, headers, stream=False, head=False, timeout=10):
        parsed_original_url = urlparse(url)
        hostname = parsed_original_url.hostname
        req_url = url
        effective_headers = headers.copy()
        
        ip = query_doh(hostname, timeout=timeout)
        if ip and ip != hostname and parsed_original_url.scheme == 'http':
            req_url = parsed_original_url._replace(netloc=f"{ip}:{parsed_original_url.port}" if parsed_original_url.port else ip).geturl()
            effective_headers["Host"] = hostname
        elif hostname:
            effective_headers["Host"] = hostname

        session = self.get_session()
        try:
            method = 'HEAD' if head else 'GET'
            r = session.request(method, req_url, headers=effective_headers, stream=stream, timeout=timeout)
            r.raise_for_status()
            return r
        except requests.exceptions.RequestException as e:
            logger.error(f"ERRO na requisição para {req_url}: {e}")
            raise

    def _handle_ts_request(self, target_url, current_headers):
        global GLOBAL_URL
        full_url = requests.compat.urljoin(GLOBAL_URL, target_url) if not target_url.startswith('http') and GLOBAL_URL else target_url
        
        buffered_data = stream_buffer.get_segment(full_url)
        if buffered_data:
            logger.info(f"Servindo segmento TS do buffer: {full_url}")
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                self.wfile.write(buffered_data[0])
            except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                logger.warning(f"Conexão interrompida ao enviar TS do buffer: {e}")
            return

        try:
            r = self._make_request_with_doh(full_url, current_headers, stream=True, timeout=10)
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                    self.send_header(header, value)
            self.end_headers()
            
            segment_data = b''
            for chunk in r.iter_content(chunk_size=BUFFER_CHUNK_SIZE):
                segment_data += chunk
                try:
                    self.wfile.write(chunk)
                except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                    logger.warning(f"Conexão interrompida ao enviar TS: {e}")
                    break
            r.close()
            stream_buffer.add_segment(full_url, segment_data, time.time())
        except requests.exceptions.RequestException as e:
            self.send_error(404, f"Falha ao buscar TS: {e}")
        except Exception as e:
            self.send_error(500, f"Erro interno ao processar TS: {e}")

    def _handle_m3u8_request(self, target_url, current_headers):
        global GLOBAL_URL
        timeshift_seconds = self._get_timeshift_param()
        try:
            r = self._make_request_with_doh(target_url, current_headers, timeout=10)
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Access-Control-Allow-Origin', '*')
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                    self.send_header(header, value)
            self.end_headers()
            
            playlist_content = r.text
            base_url_for_segments = r.url.rsplit('/', 1)[0] + '/'
            GLOBAL_URL = base_url_for_segments

            processed_lines = []
            original_media_sequence = -1
            segments_in_playlist = []
            
            lines = playlist_content.splitlines()
            for line in lines:
                line = line.strip()
                if line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                    original_media_sequence = int(line.split(':')[1])
                elif line.startswith('#EXTINF:'):
                    duration_match = re.search(r'#EXTINF:([\d.]+),', line)
                    if duration_match:
                        stream_buffer.segment_duration = float(duration_match.group(1))
                
                if not line.startswith('#') and line:
                    full_segment_url = requests.compat.urljoin(GLOBAL_URL, line)
                    segment_seq = original_media_sequence + len(segments_in_playlist) if original_media_sequence != -1 else None
                    segments_in_playlist.append({'url': full_segment_url, 'sequence': segment_seq})
                    processed_lines.append(f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(full_segment_url)}")
                else:
                    # Proxy de chaves de encriptação
                    if line.startswith('#EXT-X-KEY') and 'URI="' in line:
                         uri_match = re.search(r'URI="([^"]+)"', line)
                         if uri_match:
                             key_uri = uri_match.group(1)
                             proxied_key_uri_full = requests.compat.urljoin(GLOBAL_URL, key_uri)
                             proxied_key_uri_for_client = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(proxied_key_uri_full)}"
                             line = line.replace(f'URI="{key_uri}"', f'URI="{proxied_key_uri_for_client}"')
                    processed_lines.append(line)

            # OTIMIZAÇÃO: Aumentar o pré-carregamento para garantir mais buffer no cliente
            num_segments_to_preload = 5 
            for i, segment_info in enumerate(segments_in_playlist):
                if i < num_segments_to_preload and not stream_buffer.get_segment(segment_info['url']):
                    preload_queue.append((segment_info['url'], segment_info['sequence'], stream_buffer.segment_duration))
            
            final_playlist = "\n".join(processed_lines)
            self.wfile.write(final_playlist.encode("utf-8"))
            r.close()
        except requests.exceptions.RequestException as e:
            self.send_error(404, f"Falha ao buscar M3U8: {e}")
        except Exception as e:
            self.send_error(500, f"Erro interno ao processar M3U8: {e}")

    def _handle_generic_request(self, target_url, current_headers, method_is_head):
        try:
            r = self._make_request_with_doh(target_url, current_headers, stream=True, head=method_is_head, timeout=15)
            self.send_response(r.status_code)
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                    self.send_header(header, value)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if not method_is_head:
                for chunk in r.iter_content(chunk_size=BUFFER_CHUNK_SIZE):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                        except (socket.error, BrokenPipeError, ConnectionResetError):
                            break
            r.close()
        except requests.exceptions.RequestException as e:
            self.send_error(e.response.status_code if e.response else 500, f"Falha ao buscar recurso: {e}")
        except Exception as e:
            self.send_error(500, f"Erro interno ao processar requisição: {e}")

    def _shutdown_server(self):
        req_shutdown()

    def _process_request(self, method_is_head=False):
        global GLOBAL_HEADERS, GLOBAL_URL
        original_path = self.path

        if original_path == '/stop':
            self.send_response(200)
            self.end_headers()
            if not method_is_head: self.wfile.write(b"Stopping server...")
            self._shutdown_server()
            return

        target_url_from_param = self._get_parsed_url_param()
        current_headers = GLOBAL_HEADERS.copy()

        if original_path.startswith('/?url=') and target_url_from_param:
            cleaned_target_url = clean_url_from_headers_params(target_url_from_param)
            is_new_m3u8 = '.m3u8' in cleaned_target_url.lower() or '.m3u' in cleaned_target_url.lower()
            if is_new_m3u8 and not GLOBAL_URL.startswith(cleaned_target_url.rsplit('/', 1)[0]):
                self._reset_stream_state()
                current_headers = GLOBAL_HEADERS.copy()

            current_headers.update(get_headers_from_url_params(target_url_from_param))
            target_url_for_fetching = cleaned_target_url
        else:
            target_url_for_fetching = target_url_from_param or original_path

        if not target_url_for_fetching.startswith('http') and not GLOBAL_URL:
            self.send_error(400, "URL base não definida para caminho relativo.")
            return

        url_lower = target_url_for_fetching.lower()
        if '.m3u8' in url_lower or '.m3u' in url_lower:
            self._handle_m3u8_request(target_url_for_fetching, current_headers)
        elif '.ts' in url_lower:
            self._handle_ts_request(target_url_for_fetching, current_headers)
        else:
            self._handle_generic_request(target_url_for_fetching, current_headers, method_is_head)

    def do_HEAD(self):
        self._process_request(method_is_head=True)
    
    def do_GET(self):
        self._process_request(method_is_head=False)

class MediaServer:
    def __init__(self):
        self.server_thread = None
        self.httpd_instance = None

    def is_in_use(self):
        if self.server_thread and self.server_thread.is_alive():
            return True
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex((HOST_NAME, PORT_NUMBER)) == 0

    def start(self):
        if not self.is_in_use():
            try:
                self.httpd_instance = ThreadingHTTPServer((HOST_NAME, PORT_NUMBER), Handler)
                self.server_thread = threading.Thread(target=self.httpd_instance.serve_forever, daemon=True)
                self.server_thread.start()
                start_preload_worker_if_not_running()
                logger.info(f"MediaServer iniciado com sucesso em http://{HOST_NAME}:{PORT_NUMBER}")
            except Exception as e:
                logger.error(f"Erro fatal ao iniciar MediaServer: {e}")
                self.httpd_instance = None
        else:
            logger.info("MediaServer já está em execução ou a porta está ocupada.")
            start_preload_worker_if_not_running()

    def stop(self):
        stop_preload_worker()
        if self.httpd_instance:
            logger.info("Solicitando parada do MediaServer...")
            shutdown_thread = threading.Thread(target=self.httpd_instance.shutdown)
            shutdown_thread.start()
            shutdown_thread.join(5)
            self.httpd_instance = None
            self.server_thread = None
            logger.info("MediaServer parado.")

def req_shutdown():
    global _media_server_instance
    if _media_server_instance:
        _media_server_instance.stop()

def start_preload_worker_if_not_running():
    global preload_worker_thread, preload_running
    if not preload_running.is_set() or (preload_worker_thread and not preload_worker_thread.is_alive()):
        preload_running.set()
        preload_worker_thread = threading.Thread(target=preload_worker, daemon=True)
        preload_worker_thread.start()

def stop_preload_worker():
    global preload_running
    if preload_running.is_set():
        preload_running.clear()
        if preload_worker_thread and preload_worker_thread.is_alive():
            preload_worker_thread.join(2)
    preload_queue.clear()

def prepare_url(url_to_proxy, custom_headers_dict=None, timeshift_seconds=0):
    try:
        url_to_proxy_decoded = unquote(unquote_plus(url_to_proxy))
    except Exception:
        url_to_proxy_decoded = url_to_proxy
    
    cleaned_url = clean_url_from_headers_params(url_to_proxy_decoded)
    parsed_cleaned = urlparse(cleaned_url)
    params = parse_qs(parsed_cleaned.query)

    if custom_headers_dict:
        for key, value in custom_headers_dict.items():
            params[f"h_{key.lower()}"] = value
    if timeshift_seconds > 0:
        params['timeshift'] = str(timeshift_seconds)
    
    effective_url = parsed_cleaned._replace(query=urlencode(params, doseq=True)).geturl()
    return f'http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(effective_url)}'

if __name__ == '__main__':
    _media_server_instance = MediaServer() 
    _media_server_instance.start()
    
    logger.info(f"\nServidor rodando. Para parar, acesse http://{HOST_NAME}:{PORT_NUMBER}/stop ou pressione Ctrl+C.")
    try:
        # Mantém o script principal em execução
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        logger.info("\nInterrupção de teclado. Parando o servidor...")
    finally:
        _media_server_instance.stop()
        logger.info("Script finalizado.")