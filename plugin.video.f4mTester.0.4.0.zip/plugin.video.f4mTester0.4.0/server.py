import six
import threading
import socket
import requests
import time
import json
import collections
import re
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import logging
import socketserver
import urllib.parse

# --- Logging para depuração de requests ---
import http.client as http_client
# Descomente as linhas abaixo para ver detalhes de requisição/resposta HTTP (útil para depuração)
# http_client.HTTPConnection.debuglevel = 1
# logging.getLogger("requests.packages.urllib3").setLevel(logging.DEBUG)
# logging.getLogger("requests.packages.urllib3").propagate = True
# --- Fim do Logging de requests ---

# Configuração de logging padrão
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode  # Python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # Python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from SimpleHTTPServer import SimpleHTTPRequestHandler

# Custom HTTPServer que usa threading para lidar com requisições
class ThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 63651
DOH_SERVER_URL = "https://mozilla.cloudflare-dns.com/dns-query"
DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

# Instância global do servidor para acesso externo e gerenciamento de parada
_media_server_instance = None

# Fila para pré-carregamento de segmentos - agora por stream
preload_queues = collections.defaultdict(collections.deque)
preload_worker_threads = {}
preload_running = threading.Event() # Controla todos os workers

# Define o tamanho do chunk para leitura/escrita. Um valor maior reduz a sobrecarga de I/O.
BUFFER_CHUNK_SIZE = 262144 # 256 KB
# Define o tamanho do pré-buffer inicial para links TS diretos (ex: primeiros 2 chunks)
INITIAL_TS_PREBUFFER_CHUNKS = 50 

# --- Funções auxiliares para manipulação de URL e Cabeçalhos ---
def get_headers_from_url_params(url_with_params):
    """
    Extrai cabeçalhos de uma string de URL. Aceita cabeçalhos prefixados com 'h_'.
    A string pode ser a URL completa (com '?url=...') ou a parte após o '?url='.
    Também lida com o formato de cabeçalhos após o '|'.
    """
    custom_headers = {}
    
    # Prioriza parâmetros após o '|'
    url_parts = url_with_params.split('|', 1)
    if len(url_parts) > 1:
        header_params_str = url_parts[1]
        for param_pair in header_params_str.split('&'):
            if '=' in param_pair:
                key, value = param_pair.split('=', 1)
                key = unquote_plus(key).strip()
                value = unquote_plus(value).strip()
                if key.lower().startswith('h_'):
                    original_header_name = key[2:].replace('_', '-').title()
                    custom_headers[original_header_name] = value
                elif key.lower() in ['referer', 'origin', 'cookie', 'user-agent']: # Backward compatibility
                    custom_headers[key.lower().capitalize()] = value

    # Em seguida, processa parâmetros de query, mas com menor prioridade se já definidos via '|'
    parsed_url = urlparse(url_parts[0])
    query_params = parse_qs(parsed_url.query)

    for key, value_list in query_params.items():
        if value_list:
            lower_key = key.lower()
            if lower_key.startswith('h_'):
                original_header_name = lower_key[2:].replace('_', '-').title()
                if original_header_name not in custom_headers:
                    custom_headers[original_header_name] = unquote_plus(value_list[0])
            elif lower_key in ['referer', 'origin', 'cookie', 'user-agent']:
                if lower_key.capitalize() not in custom_headers:
                    custom_headers[lower_key.capitalize()] = unquote_plus(value_list[0])

    return custom_headers

def clean_url_from_headers_params(url):
    """
    Remove parâmetros de cabeçalho customizados (prefixados com 'h_') e de timeshift
    da parte da query da URL, e também remove a parte após o '|'.
    """
    if '|' in url:
        url = url.split('|')[0]

    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)

    clean_query = {}
    for key, value in query_params.items():
        lower_key = key.lower()
        if not lower_key.startswith('h_') and lower_key != 'timeshift':
            clean_query[key] = value

    if clean_query:
        return parsed._replace(query=urlencode(clean_query, doseq=True)).geturl()
    else:
        return parsed._replace(query='').geturl()
# --- Fim das Funções auxiliares ---


# --- Gerenciamento de Buffer de Stream ---
class StreamBuffer:
    def __init__(self, max_segments=300, timeshift_buffer_seconds=300):
        self.segments = collections.OrderedDict()
        self.max_segments = max_segments
        self.timeshift_buffer_seconds = timeshift_buffer_seconds
        self.lock = threading.Lock()
        self.playlist_sequence = 0
        self.segment_duration = 10
        self.last_segment_timestamp = 0

    def add_segment(self, url, data, timestamp=None, sequence_number=None):
        with self.lock:
            ts = timestamp if timestamp is not None else time.time()
            if data is not None and ts is not None:
                self.segments[url] = (data, ts, sequence_number)
                self.last_segment_timestamp = ts
                self._cleanup_buffer()
                logger.debug(f"Segmento adicionado/atualizado no buffer: {url} (Seq: {sequence_number})")
            else:
                logger.warning(f"Tentativa de adicionar segmento inválido ao buffer: {url}, data: {data}, ts: {ts}")

    def get_segment(self, url):
        with self.lock:
            return self.segments.get(url)

    def _cleanup_buffer(self):
        if not self.segments:
            return
        current_time = time.time()
        
        urls_to_remove_by_time = []
        for url, (_, ts, _) in list(self.segments.items()):
            if ts is not None and (current_time - ts) > self.timeshift_buffer_seconds:
                urls_to_remove_by_time.append(url)
            else:
                break 
        for url in urls_to_remove_by_time:
            self.segments.pop(url)

        while len(self.segments) > self.max_segments:
            self.segments.popitem(last=False)

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.playlist_sequence = 0
            self.segment_duration = 10
            self.last_segment_timestamp = 0
            logger.info("Buffer de stream limpo.")

    def get_sequence_for_timeshift(self, target_time_epoch):
        with self.lock:
            best_match_seq, best_match_ts, min_time_diff = None, None, float('inf')
            for url, (data, segment_ts, segment_seq) in reversed(self.segments.items()):
                if segment_ts is not None and segment_seq is not None:
                    time_diff = target_time_epoch - segment_ts
                    if time_diff >= - (self.segment_duration / 2) and time_diff < min_time_diff:
                        min_time_diff = abs(time_diff)
                        best_match_seq, best_match_ts = segment_seq, segment_ts
                    
                    if segment_ts < target_time_epoch - self.timeshift_buffer_seconds:
                         break

            if best_match_seq is not None:
                logger.info(f"Timeshift: Encontrado segmento seq {best_match_seq} (TS: {best_match_ts:.2f}) para target {target_time_epoch:.2f}")
                return best_match_seq, best_match_ts
            logger.warning(f"Timeshift: Nenhum segmento adequado encontrado para o tempo alvo {target_time_epoch:.2f}s.")
            return None, None

# Cache para resultados DoH
doh_cache = collections.OrderedDict()
DOH_CACHE_MAX_SIZE = 100
DOH_CACHE_TTL = 300

def is_ip_address(hostname):
    """Verifica se uma string é um endereço IP válido."""
    try:
        socket.inet_aton(hostname)
        return True
    except socket.error:
        try:
            socket.inet_pton(socket.AF_INET6, hostname)
            return True
        except socket.error:
            return False

def query_doh(domain, record_type="A", doh_server=DOH_SERVER_URL, timeout=5):
    """Consulta um servidor DNS over HTTPS."""
    if not domain or is_ip_address(domain):
        return domain
    
    if domain in doh_cache and (time.time() - doh_cache[domain][1]) < DOH_CACHE_TTL:
        logger.debug(f"DoH cache hit for {domain}: {doh_cache[domain][0]}")
        return doh_cache[domain][0]

    headers = {"Accept": "application/dns-json", "User-Agent": DEFAULT_USER_AGENT}
    session = requests.Session()
    retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))
    try:
        r = session.get(doh_server, headers=headers, params={"name": domain, "type": record_type}, timeout=timeout)
        r.raise_for_status()
        data = r.json()
        if "Answer" in data:
            for answer in data["Answer"]:
                if answer.get("type") == 1: # A record
                    ip = answer.get("data")
                    doh_cache[domain] = (ip, time.time())
                    if len(doh_cache) > DOH_CACHE_MAX_SIZE:
                        doh_cache.popitem(last=False)
                    logger.debug(f"DoH resolved {domain} to {ip}")
                    return ip
    except requests.exceptions.RequestException as e:
        logger.error(f"Erro na requisição DoH para {domain}: {e}")
    except json.JSONDecodeError as e:
        logger.error(f"Erro ao decodificar resposta JSON do DoH para {domain}: {e}")
    return None

# Worker de pré-carregamento de segmentos (blocos de dados)
def preload_worker(stream_key):
    """Worker de pré-carregamento para uma stream específica."""
    while preload_running.is_set():
        try:
            if stream_key not in preload_queues:
                time.sleep(0.1) # Queue for this stream might have been removed
                continue
            
            queue = preload_queues[stream_key]
            
            if queue:
                segment_url, segment_seq, segment_duration, stream_headers, stream_buffer_instance = queue.popleft()
                if not stream_buffer_instance.get_segment(segment_url):
                    logger.info(f"Pré-carregando segmento para stream {stream_key}: {segment_url}")
                    try:
                        session = Handler.get_session()
                        # Increased timeout for preloading as well
                        r = session.get(segment_url, headers=stream_headers, stream=True, timeout=30) 
                        r.raise_for_status()
                        segment_data = r.content
                        stream_buffer_instance.add_segment(segment_url, segment_data, timestamp=time.time(), sequence_number=segment_seq)
                    except requests.exceptions.RequestException as e:
                        logger.warning(f"Falha ao pré-carregar segmento {segment_url} para stream {stream_key}: {e}")
                else:
                    logger.debug(f"Segmento {segment_url} para stream {stream_key} já no buffer, pulando pré-carga.")
            else:
                time.sleep(0.1)
        except Exception as e:
            logger.error(f"Erro no worker de pré-carregamento para stream {stream_key}: {e}")
            time.sleep(1)

class StreamState:
    """Encapsula o estado de uma stream específica."""
    def __init__(self, base_m3u8_url):
        self.base_m3u8_url = base_m3u8_url
        self.headers = {
            'User-Agent': DEFAULT_USER_AGENT,
            'Connection': 'keep-alive',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1'
        }
        self.buffer = StreamBuffer()
        logger.info(f"Nova StreamState criada para: {base_m3u8_url}")

    def clear_state(self):
        """Limpa o estado desta stream."""
        # Note: Do not reset headers entirely if they were custom set, only the buffer.
        # If headers need to be reset, it should be done externally or explicitly.
        self.buffer.clear()
        logger.info(f"Estado da stream {self.base_m3u8_url} limpo (buffer).")

class StreamStateManager:
    """Gerencia múltiplas StreamState instâncias."""
    def __init__(self):
        self.streams = {} # Key: cleaned_base_m3u8_url, Value: StreamState instance
        self.lock = threading.Lock()

    def get_stream(self, base_m3u8_url):
        with self.lock:
            if base_m3u8_url not in self.streams:
                self.streams[base_m3u8_url] = StreamState(base_m3u8_url)
            return self.streams[base_m3u8_url]

    def remove_stream(self, base_m3u8_url):
        with self.lock:
            if base_m3u8_url in self.streams:
                del self.streams[base_m3u8_url]
                logger.info(f"StreamState para {base_m3u8_url} removido.")

    def clear_all_streams(self):
        """Limpa o buffer de todas as streams gerenciadas."""
        with self.lock:
            for stream_key in list(self.streams.keys()):
                self.streams[stream_key].clear_state()
                # Opcional: remover a stream inteira se ela não for mais usada.
                # self.remove_stream(stream_key)
            logger.info("Buffers de todas as streams foram limpos.")


stream_state_manager = StreamStateManager()

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.debug(format % args)

    _session = None
    # Global para rastrear o StreamState do M3U8 atualmente ativo para segmentos
    # Isso é uma simplificação e assume primariamente a reprodução de uma única stream por vez
    # ou que os clientes irão re-requisitar M3U8s para novas streams.
    _last_active_m3u8_stream_state = None 

    @classmethod
    def get_session(cls):
        """Retorna uma sessão requests reutilizável com retries configurados."""
        if cls._session is None:
            cls._session = requests.Session()
            retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504, 509], allowed_methods=frozenset(['GET', 'HEAD']))
            cls._session.mount('https://', HTTPAdapter(max_retries=retries))
            cls._session.mount('http://', HTTPAdapter(max_retries=retries))
            cls._session.allow_redirects = True
        return cls._session

    def _get_parsed_url_param(self):
        """Extrai e decodifica o parâmetro 'url' da requisição do cliente."""
        try:
            path_query = urlparse(self.path).query
            raw_param = path_query.split('url=', 1)[1] if 'url=' in path_query else None
            if raw_param:
                # The first part before '|' is the actual URL.
                return unquote(unquote_plus(raw_param.split('|', 1)[0]))
            return None
        except Exception as e:
            logger.error(f"Erro ao decodificar parâmetro URL '{self.path}': {e}")
            return None

    def _get_timeshift_param(self):
        """Extrai o parâmetro 'timeshift' da requisição do cliente."""
        try:
            query_params = parse_qs(urlparse(self.path).query)
            return int(query_params.get('timeshift', [0])[0])
        except (ValueError, TypeError):
            return 0

    def _make_request_with_doh(self, url, headers, stream=False, head=False, timeout=30, verify_ssl=True): # Increased default timeout to 30 seconds
        """
        Faz uma requisição HTTP/HTTPS, usando DoH para resolução de IP.
        Permite controle sobre cabeçalhos, streaming, método (GET/HEAD), timeout e verificação SSL.
        """
        parsed_original_url = urlparse(url)
        hostname = parsed_original_url.hostname
        req_url = url

        effective_headers = headers.copy() # Use the provided headers, which are already merged with defaults and client customs

        if hostname:
            effective_headers["Host"] = hostname

        ip = query_doh(hostname, timeout=timeout)
        if ip and ip != hostname:
            if parsed_original_url.scheme == 'http':
                netloc = f"{ip}:{parsed_original_url.port}" if parsed_original_url.port else ip
                req_url = parsed_original_url._replace(netloc=netloc).geturl()
            else:
                logger.debug(f"Resolved HTTPS host {hostname} to IP {ip}, but keeping hostname in URL for SSL.")
            
        session = self.get_session()
        try:
            method = 'HEAD' if head else 'GET'
            r = session.request(
                method,
                req_url,
                headers=effective_headers,
                stream=stream,
                timeout=timeout, # Use the passed timeout
                verify=verify_ssl,
                allow_redirects=True
            )
            r.raise_for_status()
            return r
        except requests.exceptions.RequestException as e:
            final_url = e.response.url if e.response else req_url
            logger.error(f"ERRO na requisição para {final_url}: {e}")
            raise

    def _handle_ts_request(self, target_url, current_stream_state):
        # Constrói a URL completa do segmento
        # Se target_url já for uma URL completa, use-a. Caso contrário, junte com a base da stream.
        full_url = requests.compat.urljoin(current_stream_state.base_m3u8_url, target_url) if not target_url.startswith('http') and current_stream_state.base_m3u8_url else target_url

        # Tenta pegar do buffer primeiro
        buffered_data = current_stream_state.buffer.get_segment(full_url)
        if buffered_data:
            logger.info(f"Servindo segmento TS do buffer para stream {current_stream_state.base_m3u8_url}: {full_url}")
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                self.wfile.write(buffered_data[0])
            except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                logger.warning(f"Conexão interrompida ao enviar TS do buffer: {e}")
            return

        try:
            r = self._make_request_with_doh(full_url, current_stream_state.headers, stream=True, timeout=30) # Increased timeout to 30 seconds
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding', 'content-length']:
                    self.send_header(header, value)
            self.end_headers()

            segment_data = b''
            chunks_buffered = 0

            for chunk in r.iter_content(chunk_size=BUFFER_CHUNK_SIZE):
                if not chunk:
                    continue
                
                segment_data += chunk
                
                # Para TS diretos (sem M3U8 pai), podemos "pré-bufferizar" uma parte inicial
                # antes de começar a enviar ao cliente, se ainda não houver dados no buffer.
                # Isso simula um pequeno pré-buffer inicial para links TS diretos.
                if current_stream_state.base_m3u8_url == full_url and chunks_buffered < INITIAL_TS_PREBUFFER_CHUNKS:
                    chunks_buffered += 1
                    logger.debug(f"Pré-buffer TS direto: chunk {chunks_buffered}/{INITIAL_TS_PREBUFFER_CHUNKS} para {full_url}")
                    # Não enviamos o chunk ao cliente ainda, apenas acumulamos em segment_data
                else:
                    # Envia os chunks acumulados (se houver) e depois os chunks subsequentes
                    if segment_data: # Envia o que foi acumulado no pré-buffer
                        try:
                            self.wfile.write(segment_data)
                            segment_data = b'' # Limpa o buffer após enviar
                        except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                            logger.warning(f"Conexão interrompida ao enviar TS pré-bufferizado: {e}")
                            break # Sai do loop
                    
                    try:
                        self.wfile.write(chunk) # Envia o chunk atual diretamente
                    except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                        logger.warning(f"Conexão interrompida ao enviar TS: {e}")
                        break # Sai do loop
            
            # Garante que qualquer dado restante no segment_data seja enviado
            if segment_data:
                 try:
                    self.wfile.write(segment_data)
                 except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                    logger.warning(f"Conexão interrompida ao enviar TS restante: {e}")

            r.close()
            
            # Adiciona o segmento completo (ou a parte que foi baixada) ao buffer da StreamState.
            # Para TS diretos, o "full_url" é o próprio "base_m3u8_url" do StreamState temporário.
            current_stream_state.buffer.add_segment(full_url, segment_data, time.time())

        except requests.exceptions.RequestException as e:
            status_code = e.response.status_code if e.response is not None else 500
            self.send_error(status_code, f"Falha ao buscar TS: {e}")
        except Exception as e:
            logger.exception(f"Erro interno ao processar TS: {e}")
            self.send_error(500, f"Erro interno ao processar TS: {e}")

    def _handle_m3u8_request(self, target_url, current_stream_state):
        timeshift_seconds = self._get_timeshift_param()
        try:
            # Ao requisitar um novo M3U8, limpar o buffer de todas as streams ativas.
            # Isso é útil para simular uma "troca de canal" e liberar memória.
            logger.info(f"Nova requisição M3U8 detectada: {target_url}. Limpando buffers de todas as streams.")
            stream_state_manager.clear_all_streams()
            
            r = self._make_request_with_doh(target_url, current_stream_state.headers, timeout=30) # Increased timeout to 30 seconds
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Access-Control-Allow-Origin', '*')
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding', 'content-length']:
                    self.send_header(header, value)
            self.end_headers()

            playlist_content = r.text
            base_url_for_segments = r.url.rsplit('/', 1)[0] + '/' 
            current_stream_state.base_m3u8_url = base_url_for_segments # Update if redirected

            processed_lines = []
            original_media_sequence = -1
            segments_in_playlist = []
            
            uri_pattern = re.compile(r'URI="([^"]+)"')
            
            lines = playlist_content.splitlines()
            for line in lines:
                line = line.strip()
                if line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                    try:
                        original_media_sequence = int(line.split(':')[1])
                        current_stream_state.buffer.playlist_sequence = original_media_sequence
                    except ValueError:
                        logger.warning(f"Falha ao parsear MEDIA-SEQUENCE: {line}")
                        original_media_sequence = 0
                elif line.startswith('#EXTINF:'):
                    duration_match = re.search(r'#EXTINF:([\d.]+),', line)
                    if duration_match:
                        current_stream_state.buffer.segment_duration = float(duration_match.group(1))

                if line.startswith('#'):
                    uri_match = uri_pattern.search(line)
                    if uri_match:
                        original_uri = uri_match.group(1)
                        if not original_uri.startswith('http://') and not original_uri.startswith('https://'):
                            proxied_uri_full = requests.compat.urljoin(current_stream_state.base_m3u8_url, original_uri)
                            proxied_uri_for_client = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(proxied_uri_full)}"
                            line = line.replace(f'URI="{original_uri}"', f'URI="{proxied_uri_for_client}"')
                    processed_lines.append(line)
                elif line:
                    full_segment_url = requests.compat.urljoin(current_stream_state.base_m3u8_url, line)
                    
                    segment_seq = None
                    if original_media_sequence != -1:
                        segment_seq = original_media_sequence + len(segments_in_playlist)

                    segments_in_playlist.append({'url': full_segment_url, 'sequence': segment_seq, 'duration': current_stream_state.buffer.segment_duration})
                    processed_lines.append(f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(full_segment_url)}")

            if timeshift_seconds > 0 and current_stream_state.buffer.segments and current_stream_state.buffer.segment_duration > 0:
                target_time_epoch = time.time() - timeshift_seconds
                matched_seq, matched_ts = current_stream_state.buffer.get_sequence_for_timeshift(target_time_epoch)
                
                if matched_seq is not None:
                    # num_live_segments = len(segments_in_playlist) # This variable is not used after setting
                    
                    new_media_sequence = matched_seq
                    
                    timeshifted_playlist_lines = []
                    timeshifted_playlist_lines.append('#EXTM3U')
                    timeshifted_playlist_lines.append('#EXT-X-VERSION:3')
                    timeshifted_playlist_lines.append(f'#EXT-X-TARGETDURATION:{int(current_stream_state.buffer.segment_duration) + 1}')
                    timeshifted_playlist_lines.append(f'#EXT-X-MEDIA-SEQUENCE:{new_media_sequence}')
                    
                    segments_to_add = []
                    for seg_info in segments_in_playlist:
                        if seg_info['sequence'] is not None and seg_info['sequence'] >= new_media_sequence:
                            segments_to_add.append(seg_info)
                        # Limiting the number of segments to avoid excessive playlist length, adjust as needed.
                        if seg_info['sequence'] is not None and seg_info['sequence'] > original_media_sequence + 100: # Example limit (100 segments beyond original start)
                            break
                    
                    for seg_info in segments_to_add:
                        timeshifted_playlist_lines.append(f'#EXTINF:{current_stream_state.buffer.segment_duration:.3f},')
                        timeshifted_playlist_lines.append(f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(seg_info['url'])}")
                    
                    if '#EXT-X-ENDLIST' in playlist_content:
                        timeshifted_playlist_lines.append('#EXT-X-ENDLIST')

                    final_playlist_content = "\n".join(timeshifted_playlist_lines)
                    logger.info(f"Gerando playlist para timeshift (Seq: {new_media_sequence}) para stream {current_stream_state.base_m3u8_url}.")
                else:
                    final_playlist_content = "\n".join(processed_lines)
                    logger.warning(f"Timeshift solicitado para stream {current_stream_state.base_m3u8_url}, mas não foi possível encontrar o segmento. Servindo playlist original.")
            else:
                final_playlist_content = "\n".join(processed_lines)

            self.wfile.write(final_playlist_content.encode("utf-8"))
            r.close()

            # Pré-carregamento: prioriza segmentos mais recentes da playlist
            stream_key = current_stream_state.base_m3u8_url # Use the stream key for preloading
            start_preload_worker_for_stream(stream_key) # Ensure worker is running for this stream
            preload_queues[stream_key].clear() # Clear existing preload queue for this stream
            num_segments_to_preload = 10
            for i in range(len(segments_in_playlist) -1, max(-1, len(segments_in_playlist) - num_segments_to_preload -1), -1):
                segment_info = segments_in_playlist[i]
                if not current_stream_state.buffer.get_segment(segment_info['url']):
                    preload_queues[stream_key].appendleft((segment_info['url'], segment_info['sequence'], segment_info['duration'], current_stream_state.headers, current_stream_state.buffer))

        except requests.exceptions.RequestException as e:
            status_code = e.response.status_code if e.response is not None else 500
            self.send_error(status_code, f"Falha ao buscar M3U8: {e}")
        except Exception as e:
            logger.exception(f"Erro interno ao processar M3U8: {e}")
            self.send_error(500, f"Erro interno ao processar M3U8: {e}")

    def _handle_generic_request(self, target_url, current_stream_state, method_is_head):
        """Lida com requisições para outros tipos de recursos que não são TS ou M3U8."""
        try:
            r = self._make_request_with_doh(target_url, current_stream_state.headers, stream=True, head=method_is_head, timeout=30) # Increased timeout to 30 seconds
            self.send_response(r.status_code)
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding', 'content-length']:
                    self.send_header(header, value)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if not method_is_head:
                for chunk in r.iter_content(chunk_size=BUFFER_CHUNK_SIZE):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                        except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                            logger.warning(f"Conexão interrompida ao enviar recurso genérico: {e}")
                            break
            r.close()
        except requests.exceptions.RequestException as e:
            status_code = e.response.status_code if e.response is not None else 500
            self.send_error(status_code, f"Falha ao buscar recurso: {e}")
        except Exception as e:
            logger.exception(f"Erro interno ao processar requisição genérica: {e}")
            self.send_error(500, f"Erro interno ao processar requisição: {e}")

    def _shutdown_server(self):
        """Solicita o desligamento do servidor."""
        req_shutdown()

    def _process_request(self, method_is_head=False):
        original_path = self.path

        if original_path == '/stop':
            self.send_response(200)
            self.end_headers()
            if not method_is_head: self.wfile.write(b"Stopping server...")
            self._shutdown_server()
            return

        target_url_from_param = None
        if original_path.startswith('/?url='):
            try:
                target_url_from_param = self._get_parsed_url_param()
            except Exception as e:
                logger.error(f"Erro ao obter URL do parâmetro na requisição: {e}")
                self.send_error(400, "URL inválida no parâmetro.")
                return

        if not target_url_from_param:
            self.send_error(400, "Parâmetro 'url' ausente na requisição.")
            return

        cleaned_target_url = clean_url_from_headers_params(target_url_from_param)
        is_m3u8_request = '.m3u8' in cleaned_target_url.lower() or '.m3u' in cleaned_target_url.lower()
        is_ts_request = '.ts' in cleaned_target_url.lower() or '.aac' in cleaned_target_url.lower() or '.mp4' in cleaned_target_url.lower() or '.m4a' in cleaned_target_url.lower() or '.mov' in cleaned_target_url.lower()

        current_stream_state = None
        if is_m3u8_request:
            # Sempre obtenha (ou crie) uma StreamState para a URL M3U8
            current_stream_state = stream_state_manager.get_stream(cleaned_target_url)
            # A limpeza do buffer é feita dentro de _handle_m3u8_request ao detectar uma nova playlist
            current_stream_state.base_m3u8_url = cleaned_target_url
            Handler._last_active_m3u8_stream_state = current_stream_state
            logger.debug(f"M3U8 request: Set _last_active_m3u8_stream_state to {current_stream_state.base_m3u8_url}")

        elif is_ts_request: # Handle direct TS links or segments from unknown M3U8s
            # Se for uma requisição TS, verifica se pertence à última stream M3U8 ativa
            if Handler._last_active_m3u8_stream_state and \
               cleaned_target_url.startswith(Handler._last_active_m3u8_stream_state.base_m3u8_url.rsplit('/', 1)[0]):
                # Assume que os segmentos TS são relativos ao caminho base do último M3U8
                current_stream_state = Handler._last_active_m3u8_stream_state
                logger.debug(f"TS request: Using _last_active_m3u8_stream_state ({current_stream_state.base_m3u8_url}) for segment.")
            else:
                # Para links TS diretos ou segmentos não claramente ligados ao último M3U8,
                # cria um StreamState especificamente para esta URL TS.
                # Isso faz da própria URL TS a "base_m3u8_url" para seu StreamState temporário.
                current_stream_state = StreamState(cleaned_target_url)
                current_stream_state.clear_state() # Garante buffer fresco para este TS direto
                logger.warning(f"TS request ({cleaned_target_url}) não diretamente ligado a M3U8 anterior. Usando StreamState temporário.")
                # IMPORTANTE: NÃO definimos _last_active_m3u8_stream_state aqui, pois é um TS direto.
                # Definir isso associaria incorretamente segmentos M3U8 subsequentes com a URL deste TS.
        elif Handler._last_active_m3u8_stream_state:
            # Se for uma requisição genérica (não M3U8/TS) e houver um M3U8 ativo, use-o.
            current_stream_state = Handler._last_active_m3u8_stream_state
            logger.debug(f"Generic request: Using _last_active_m3u8_stream_state ({current_stream_state.base_m3u8_url})")
        else:
            # Se não houver M3U8 ativo e não for TS, crie um StreamState temporário para esta URL.
            current_stream_state = StreamState(cleaned_target_url)
            logger.warning(f"Requisição para {cleaned_target_url} sem M3U8 anterior. Usando estado de stream temporário. Buffer/Pré-carregamento podem não ser eficazes.")

        # Mescla os cabeçalhos personalizados do cliente na requisição original nos cabeçalhos da stream.
        headers_from_client_url = get_headers_from_url_params(original_path)
        current_stream_state.headers.update(headers_from_client_url)

        # Decide o tipo de handler com base na extensão da URL
        if is_m3u8_request:
            self._handle_m3u8_request(target_url_from_param, current_stream_state)
        elif is_ts_request: # Usa a flag is_ts_request determinada
            self._handle_ts_request(target_url_from_param, current_stream_state)
        else:
            self._handle_generic_request(target_url_from_param, current_stream_state, method_is_head)


    def do_HEAD(self):
        self._process_request(method_is_head=True)

    def do_GET(self):
        self._process_request(method_is_head=False)

class MediaServer:
    def __init__(self):
        self.server_thread = None
        self.httpd_instance = None
        self._shutdown_event = threading.Event()

    def is_in_use(self):
        """Verifica se o servidor está em execução ou se a porta está ocupada."""
        if self.server_thread and self.server_thread.is_alive() and not self._shutdown_event.is_set():
            logger.debug("MediaServer thread está ativa.")
            return True
        
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((HOST_NAME, PORT_NUMBER))
                return False
            except socket.error:
                logger.warning(f"Porta {PORT_NUMBER} já está em uso.")
                return True

    def start(self):
        """Inicia o servidor em uma nova thread."""
        if not self.is_in_use():
            try:
                self._shutdown_event.clear()
                self.httpd_instance = ThreadingHTTPServer((HOST_NAME, PORT_NUMBER), Handler)
                self.httpd_instance.timeout = 1 
                self.server_thread = threading.Thread(target=self.httpd_instance.serve_forever, daemon=True)
                self.server_thread.start()
                preload_running.set()
                logger.info(f"MediaServer iniciado com sucesso em http://{HOST_NAME}:{PORT_NUMBER}")
            except Exception as e:
                logger.error(f"Erro fatal ao iniciar MediaServer: {e}")
                self.httpd_instance = None
        else:
            logger.info("MediaServer já está em execução ou a porta está ocupada. Garantindo que o worker de pré-carregamento esteja ativo.")
            preload_running.set() # Ensure global worker flag is set

    def stop(self):
        """Para o servidor."""
        if self.httpd_instance:
            logger.info("Solicitando parada do MediaServer...")
            self._shutdown_event.set()
            shutdown_thread = threading.Thread(target=self.httpd_instance.shutdown)
            shutdown_thread.start()
            shutdown_thread.join(5)
            self.httpd_instance = None
            self.server_thread = None
            stop_all_preload_workers() # Stops all workers
            logger.info("MediaServer parado.")
        else:
            logger.info("MediaServer não está em execução.")
            stop_all_preload_workers()

def req_shutdown():
    """Função externa para solicitar o desligamento do servidor."""
    global _media_server_instance
    if _media_server_instance:
        _media_server_instance.stop()

def start_preload_worker_for_stream(stream_key):
    """Inicia um worker de pré-carregamento para uma stream específica se ainda não estiver rodando."""
    global preload_worker_threads, preload_running
    if not preload_running.is_set():
        preload_running.set() # Ensure the global flag is set
    
    if stream_key not in preload_worker_threads or not preload_worker_threads[stream_key].is_alive():
        logger.info(f"Iniciando worker de pré-carregamento para stream: {stream_key}")
        thread = threading.Thread(target=preload_worker, args=(stream_key,), daemon=True)
        preload_worker_threads[stream_key] = thread
        thread.start()

def stop_preload_worker_for_stream(stream_key):
    """Para o worker de pré-carregamento para uma stream específica."""
    global preload_worker_threads, preload_queues
    if stream_key in preload_worker_threads and preload_worker_threads[stream_key].is_alive():
        logger.info(f"Solicitando parada do worker de pré-carregamento para stream: {stream_key}")
        if stream_key in preload_queues:
            preload_queues[stream_key].clear() # Clear queue first
            # The worker will eventually exit if preload_running is clear or its queue is empty
            # For immediate stop, a per-worker event would be needed, but this simplifies management.

def stop_all_preload_workers():
    """Para todos os workers de pré-carregamento."""
    global preload_running, preload_worker_threads, preload_queues
    if preload_running.is_set():
        preload_running.clear() # Signal all workers to stop
        logger.info("Aguardando workers de pré-carregamento pararem...")
        for stream_key, thread in list(preload_worker_threads.items()):
            if thread.is_alive():
                thread.join(2) # Wait a bit for each
            if not thread.is_alive():
                del preload_worker_threads[stream_key]
        logger.info("Todos os workers de pré-carregamento parados.")
    preload_queues.clear() # Clear all queues after stopping workers

def prepare_url(url_to_proxy, custom_headers_dict=None, timeshift_seconds=0):
    """
    Prepara a URL para ser passada para o proxy local.
    Adiciona custom_headers_dict e timeshift_seconds como parâmetros na URL.
    """
    try:
        url_to_proxy_decoded = unquote(unquote_plus(url_to_proxy))
    except Exception:
        url_to_proxy_decoded = url_to_proxy

    cleaned_url = clean_url_from_headers_params(url_to_proxy_decoded)
    parsed_cleaned = urlparse(cleaned_url)
    
    params_for_query = parse_qs(parsed_cleaned.query)
    if timeshift_seconds > 0:
        params_for_query['timeshift'] = [str(timeshift_seconds)]
    effective_url_query = urlencode(params_for_query, doseq=True)
    effective_url = parsed_cleaned._replace(query=effective_url_query).geturl()

    header_params_for_pipe = []
    if custom_headers_dict:
        for key, value in custom_headers_dict.items():
            header_param_key = f"h_{key.lower().replace('-', '_')}"
            header_params_for_pipe.append(f"{quote_plus(header_param_key)}={quote_plus(value)}")

    final_proxied_url = f'http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(effective_url)}'
    if header_params_for_pipe:
        final_proxied_url += '|' + '&'.join(header_params_for_pipe)

    return final_proxied_url

if __name__ == '__main__':
    _media_server_instance = MediaServer()
    _media_server_instance.start()

    logger.info(f"\nServidor rodando. Para parar, acesse http://{HOST_NAME}:{PORT_NUMBER}/stop ou pressione Ctrl+C.")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        logger.info("\nInterrupção de teclado. Parando o servidor...")
    finally:
        _media_server_instance.stop()
        logger.info("Script finalizado.")