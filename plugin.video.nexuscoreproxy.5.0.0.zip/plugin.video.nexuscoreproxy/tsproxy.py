# -*- coding: utf-8 -*-
# Autor: Deivid Silva
# Nexu Core MPEG-TS Proxy

import time
import threading
import queue
import http.client
import urllib.error
import sys
import ssl
import json
import random
import socket
from collections import deque
from socketserver import ThreadingMixIn
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, quote

TS_PACKET_SIZE = 188
TS_SYNC_BYTE = 0x47
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
NULL_PUMP_BURST = TS_NULL_PACKET * 64
NULL_PUMP_INTERVAL = 0.08
PREBUFFER_BYTES_FIRST = 128 * 1024
CLIENT_QUEUE_SIZE = 2048
FETCH_TIMEOUT = 6.0
GRACE_PERIOD = 75.0
BACKOFF_FAST = 0.05
BACKOFF_MAX = 1.5
BACKOFF_JITTER = 0.1
PREBUF_WAIT_TIMEOUT = 20.0
STALL_TIMEOUT = 12.0
CB_FAIL_THRESHOLD = 8
CB_COOLDOWN_SEC = 15.0
PREFETCH_QUEUE_SIZE = 2
PREFETCH_TRIGGER_MB = 0.5
LAT_TARGET_MS = 180.0
LAT_WINDOW = 20
LAT_CHUNK_MIN = TS_PACKET_SIZE * 8
LAT_CHUNK_MAX = 256 * 1024

_VLC_UA_POOL = [
    'VLC/3.0.21 LibVLC/3.0.21',
    'VLC/3.0.20 LibVLC/3.0.20',
    'VLC/3.0.18 LibVLC/3.0.18',
    'VLC/3.0.16 LibVLC/3.0.16',
    'VLC/3.0.12 LibVLC/3.0.12',
    'VLC/2.2.8 LibVLC/2.2.8',
]

def _pick_ua():
    return random.choice(_VLC_UA_POOL)

def _fake_ip():
    ranges = [
        (177, 0, 0, 0),
        (189, 0, 0, 0),
        (187, 0, 0, 0),
        (186, 0, 0, 0),
        (200, 128, 0, 0),
    ]
    base = random.choice(ranges)
    return "%d.%d.%d.%d" % (base[0], random.randint(1, 254), random.randint(1, 254), random.randint(1, 254))

def _build_tls_context():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.minimum_version = getattr(ssl, "TLSVersion", ssl).TLSv1_2 if hasattr(ssl, "TLSVersion") else ssl.PROTOCOL_TLSv1_2
    _CIPHERS = ':'.join([
        'TLS_AES_128_GCM_SHA256',
        'TLS_AES_256_GCM_SHA384',
        'TLS_CHACHA20_POLY1305_SHA256',
        'ECDHE-RSA-AES128-GCM-SHA256',
        'ECDHE-RSA-AES256-GCM-SHA384',
        'ECDHE-RSA-CHACHA20-POLY1305',
        'ECDHE-RSA-AES128-SHA256',
        'ECDHE-RSA-AES256-SHA384',
        'AES128-GCM-SHA256',
        'AES256-GCM-SHA384',
    ])
    try:
        ctx.set_ciphers(_CIPHERS)
    except Exception:
        try:
            ctx.set_ciphers('HIGH:!aNULL:!MD5')
        except Exception:
            pass
    if hasattr(ssl, "OP_NO_COMPRESSION"):
        ctx.options |= ssl.OP_NO_COMPRESSION
    if hasattr(ssl, "OP_NO_TICKET"):
        ctx.options &= ~ssl.OP_NO_TICKET
    try:
        ctx.set_ecdh_curve('prime256v1')
    except Exception:
        pass
    return ctx

_TLS_CTX = _build_tls_context()

class BitrateMeter(object):
    def __init__(self, window_sec=3.0):
        self._window_sec = window_sec
        self._samples = deque()
        self._lock = threading.Lock()
        self.bps = 0.0

    def add(self, byte_count):
        now = time.monotonic()
        with self._lock:
            self._samples.append((now, byte_count))
            cutoff = now - self._window_sec
            while self._samples and self._samples[0][0] < cutoff:
                self._samples.popleft()
            if len(self._samples) >= 2:
                total_bytes = sum(s[1] for s in self._samples)
                elapsed = self._samples[-1][0] - self._samples[0][0]
                self.bps = (total_bytes * 8 / elapsed) if elapsed > 0 else 0.0
            else:
                self.bps = 0.0

    def reset(self):
        with self._lock:
            self._samples.clear()
            self.bps = 0.0

    @property
    def kbps(self):
        return self.bps / 1_000

    @property
    def mbps(self):
        return self.bps / 1_000_000

    def chunk_size_for_target(self, target_bps, interval_sec=0.1):
        raw = int(target_bps / 8 * interval_sec)
        aligned = (raw // TS_PACKET_SIZE) * TS_PACKET_SIZE
        return max(TS_PACKET_SIZE * 8, aligned)

class LatencyController(object):
    def __init__(self, target_ms=LAT_TARGET_MS, window=LAT_WINDOW):
        self._target_ms = target_ms
        self._window = window
        self._samples = deque(maxlen=window)
        self._lock = threading.Lock()
        self._chunk_size = LAT_CHUNK_MIN * 4
        self._last_read_ts = 0.0

    def mark_read_start(self):
        self._last_read_ts = time.monotonic()

    def mark_read_end(self, bytes_received):
        if self._last_read_ts == 0.0 or bytes_received == 0:
            return
        elapsed_ms = (time.monotonic() - self._last_read_ts) * 1000.0
        with self._lock:
            self._samples.append(elapsed_ms)
            self._adjust(bytes_received)

    def _adjust(self, bytes_received):
        if len(self._samples) < 3:
            return
        avg_ms = sum(self._samples) / len(self._samples)
        ratio = avg_ms / self._target_ms
        if ratio > 1.3:
            new_size = int(self._chunk_size * 0.80)
        elif ratio > 1.05:
            new_size = int(self._chunk_size * 0.92)
        elif ratio < 0.5:
            new_size = int(self._chunk_size * 1.25)
        elif ratio < 0.85:
            new_size = int(self._chunk_size * 1.10)
        else:
            return
        new_size = (new_size // TS_PACKET_SIZE) * TS_PACKET_SIZE
        self._chunk_size = max(LAT_CHUNK_MIN, min(LAT_CHUNK_MAX, new_size))

    @property
    def chunk_size(self):
        with self._lock:
            return self._chunk_size

    @property
    def avg_latency_ms(self):
        with self._lock:
            return sum(self._samples) / len(self._samples) if self._samples else 0.0

    def reset(self):
        with self._lock:
            self._samples.clear()
            self._chunk_size = LAT_CHUNK_MIN * 4
            self._last_read_ts = 0.0

class SingleTailCache(object):
    def __init__(self):
        self._live = b''
        self._backup = b''
        self._lock = threading.Lock()

    def update_live(self, tail, tail_size, min_bytes):
        if not tail or len(tail) < min_bytes:
            return False
        remainder = len(tail) % TS_PACKET_SIZE
        if remainder:
            tail = tail[remainder:]
        if len(tail) < min_bytes:
            return False
        with self._lock:
            self._live = tail[-tail_size:]
        return True

    def promote_to_backup(self, min_bytes):
        with self._lock:
            if self._live and len(self._live) >= min_bytes:
                self._backup = self._live
                self._live = b''
                return True
        return False

    def get_for_suture(self):
        with self._lock:
            return self._live

    def get_for_recovery(self):
        with self._lock:
            return self._backup if (not self._live and self._backup) else b''

    def has_any(self, min_bytes):
        with self._lock:
            return bool((self._live and len(self._live) >= min_bytes) or
                        (self._backup and len(self._backup) >= min_bytes))

class ContinuityFixer(object):
    def __init__(self):
        self._cc = {}
        self._dirty = set()
        self._lock = threading.Lock()

    def mark_resync(self, pids=None):
        with self._lock:
            if pids is None:
                self._dirty.update(list(self._cc.keys()))
            else:
                self._dirty.update(pids)

    def reset_pid(self, pid):
        with self._lock:
            self._cc.pop(pid, None)
            self._dirty.discard(pid)

    def known_pids(self):
        with self._lock:
            return set(self._cc.keys())

    def fix(self, pkt):
        if len(pkt) != TS_PACKET_SIZE or pkt[0] != TS_SYNC_BYTE:
            return pkt
        pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
        if pid == 0x1FFF:
            return pkt
        has_payload = bool(pkt[3] & 0x10)
        if not has_payload:
            return pkt
        incoming_cc = pkt[3] & 0x0F
        with self._lock:
            if pid in self._dirty:
                self._cc[pid] = (incoming_cc + 1) & 0x0F
                self._dirty.discard(pid)
                return pkt
            if pid not in self._cc:
                self._cc[pid] = (incoming_cc + 1) & 0x0F
                return pkt
            expected_cc = self._cc[pid]
            fixed_byte = bytes([(pkt[3] & 0xF0) | (expected_cc & 0x0F)])
            self._cc[pid] = (expected_cc + 1) & 0x0F
        return pkt[:3] + fixed_byte + pkt[4:]

    def detect_discontinuous_pids(self, segment):
        discontinuous = set()
        n = len(segment) // TS_PACKET_SIZE
        seen = set()
        with self._lock:
            for i in range(n):
                offset = i * TS_PACKET_SIZE
                pkt = segment[offset:offset + TS_PACKET_SIZE]
                if pkt[0] != TS_SYNC_BYTE:
                    continue
                pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
                if pid == 0x1FFF or pid in seen:
                    continue
                if not (pkt[3] & 0x10):
                    continue
                seen.add(pid)
                if pid not in self._cc:
                    continue
                incoming_cc = pkt[3] & 0x0F
                expected_cc = self._cc[pid]
                if incoming_cc != expected_cc:
                    discontinuous.add(pid)
        return discontinuous

class CircuitBreaker(object):
    def __init__(self, fail_threshold=CB_FAIL_THRESHOLD, cooldown_sec=CB_COOLDOWN_SEC):
        self._fail_threshold = fail_threshold
        self._cooldown_sec = cooldown_sec
        self._consecutive_fails = 0
        self._open_until = 0.0
        self._lock = threading.Lock()
        self._state = 'CLOSED'

    def record_success(self):
        with self._lock:
            self._consecutive_fails = 0
            self._state = 'CLOSED'

    def record_failure(self):
        with self._lock:
            self._consecutive_fails += 1
            if self._consecutive_fails >= self._fail_threshold and self._state == 'CLOSED':
                self._state = 'OPEN'
                self._open_until = time.monotonic() + self._cooldown_sec

    def is_open(self):
        with self._lock:
            if self._state == 'CLOSED':
                return False
            if self._state == 'HALF_OPEN':
                return False
            if time.monotonic() >= self._open_until:
                self._state = 'HALF_OPEN'
                return False
            return True

    @property
    def state(self):
        with self._lock:
            return self._state

    @property
    def consecutive_fails(self):
        with self._lock:
            return self._consecutive_fails

def open_stream(url, ua=None, fwd_ip=None):
    ua = ua or _pick_ua()
    fwd_ip = fwd_ip or _fake_ip()
    current_url = url
    max_redirects = 10
    for attempt in range(max_redirects):
        parsed = urlparse(current_url)
        is_https = parsed.scheme == 'https'
        host = parsed.hostname
        port = parsed.port or (443 if is_https else 80)
        netloc_clean = host
        if not ((is_https and port == 443) or (not is_https and port == 80)):
            netloc_clean = "%s:%d" % (host, port)
        path = parsed.path or '/'
        if parsed.query:
            path += '?' + parsed.query
        headers = {
            'User-Agent': ua,
            'Accept': '*/*',
            'Icy-MetaData': '1',
            'Connection': 'keep-alive',
            'Host': netloc_clean,
            'X-Forwarded-For': fwd_ip,
            'X-Real-IP': fwd_ip,
        }
        conn = None
        try:
            if is_https:
                conn = http.client.HTTPSConnection(
                    host, port,
                    timeout=FETCH_TIMEOUT,
                    context=_TLS_CTX,
                )
                conn.connect()
                conn.sock.do_handshake()
            else:
                conn = http.client.HTTPConnection(host, port, timeout=FETCH_TIMEOUT)
            conn.request('GET', path, headers=headers)
            resp = conn.getresponse()
            if resp.status in (301, 302, 307, 308):
                location = resp.getheader('Location')
                try:
                    resp.read()
                except Exception:
                    pass
                finally:
                    try:
                        conn.close()
                    except Exception:
                        pass
                if location:
                    if location.startswith('http'):
                        current_url = location
                    elif location.startswith('/'):
                        current_url = "%s://%s%s" % (parsed.scheme, parsed.netloc, location)
                    else:
                        current_url = "%s://%s/%s" % (parsed.scheme, parsed.netloc, location.lstrip('./'))
                    continue
                raise urllib.error.HTTPError(
                    current_url, resp.status, 'Redirect sem Location', resp.getheaders(), None
                )
            elif resp.status >= 400:
                try:
                    resp.read()
                except Exception:
                    pass
                try:
                    conn.close()
                except Exception:
                    pass
                raise urllib.error.HTTPError(
                    current_url, resp.status, resp.reason, resp.getheaders(), None
                )
            return resp
        except Exception:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass
            raise
    raise urllib.error.HTTPError(url, 500, 'Max Redirects Exceeded', {}, None)

class BroadcastBus(object):
    def __init__(self, per_client_size=CLIENT_QUEUE_SIZE):
        self._clients = {}
        self._lock = threading.RLock()
        self._per_client_size = per_client_size
        self._next_id = 0

    def subscribe(self):
        with self._lock:
            cid = self._next_id
            self._next_id += 1
            q = queue.Queue(maxsize=self._per_client_size)
            self._clients[cid] = q
            return cid, q

    def unsubscribe(self, cid):
        with self._lock:
            self._clients.pop(cid, None)

    def publish(self, chunk):
        with self._lock:
            for q in list(self._clients.values()):
                try:
                    q.put_nowait(chunk)
                except queue.Full:
                    try:
                        q.get_nowait()
                        q.put_nowait(chunk)
                    except Exception:
                        pass

    def publish_null(self):
        with self._lock:
            for q in list(self._clients.values()):
                if q.qsize() < self._per_client_size // 4:
                    try:
                        q.put_nowait(NULL_PUMP_BURST)
                    except queue.Full:
                        pass

    @property
    def client_count(self):
        with self._lock:
            return len(self._clients)

class PrefetchWorker(threading.Thread):
    def __init__(self, url):
        threading.Thread.__init__(self)
        self.daemon = True
        self.name = "Prefetch-%d" % id(self)
        self.url = url
        self.result_queue = queue.Queue(maxsize=PREFETCH_QUEUE_SIZE)
        self._trigger = threading.Event()
        self._cancelled = threading.Event()

    def trigger(self):
        self._trigger.set()

    def cancel(self):
        self._cancelled.set()
        self._trigger.set()

    def run(self):
        while not self._cancelled.is_set():
            self._trigger.wait()
            self._trigger.clear()
            if self._cancelled.is_set():
                break
            try:
                resp = open_stream(self.url, ua=_pick_ua(), fwd_ip=_fake_ip())
                if not self._cancelled.is_set():
                    try:
                        self.result_queue.put(('ok', resp), block=True, timeout=5.0)
                    except queue.Full:
                        try:
                            resp.close()
                        except Exception:
                            pass
                else:
                    try:
                        resp.close()
                    except Exception:
                        pass
            except Exception as e:
                if not self._cancelled.is_set():
                    try:
                        self.result_queue.put(('err', e), block=False)
                    except queue.Full:
                        pass

    def cancel_and_drain(self):
        self.cancel()
        while True:
            try:
                kind, val = self.result_queue.get_nowait()
                if kind == 'ok':
                    try:
                        val.close()
                    except Exception:
                        pass
            except queue.Empty:
                break

    def get_result(self, timeout=0.0):
        try:
            return self.result_queue.get(block=(timeout > 0), timeout=timeout)
        except queue.Empty:
            return None

class TSEngine(threading.Thread):
    def __init__(self, url):
        threading.Thread.__init__(self)
        self.daemon = True
        self.name = "TSEng-%d" % id(self)
        self.url = url
        self.bus = BroadcastBus()
        self._stop_event = threading.Event()
        self.prebuf_ready = threading.Event()
        self._first_connection = True
        self._prebuf_bytes_first = PREBUFFER_BYTES_FIRST
        self.cc_fixer = ContinuityFixer()
        self.tail_cache = SingleTailCache()
        self.bitrate_meter = BitrateMeter(window_sec=3.0)
        self.lat_controller = LatencyController()
        self.circuit_breaker = CircuitBreaker()
        self.stream_tail = bytearray()
        self.residual_buffer = bytearray()
        self._bytes_sent = 0
        self.has_initial_lock = False
        self._client_lock = threading.Lock()
        self._last_client = time.time()
        self._session_ua = _pick_ua()
        self._session_ip = _fake_ip()
        self._avg_segment_size = 0
        self.dyn_tail_size = 256 * TS_PACKET_SIZE
        self.dyn_tail_secondary = 128 * TS_PACKET_SIZE
        self.dyn_min_bytes = 64 * TS_PACKET_SIZE
        self.dyn_suture_window_max = self.dyn_tail_size * 512
        self.dyn_suture_timeout = 5.0
        self._prefetch = None
        self._prefetch_triggered = False
        self._metrics = {
            'reconnections': 0,
            'sutures_ok': 0,
            'sutures_timeout': 0,
            'stalls': 0,
            'cb_trips': 0,
            'bytes_total': 0,
            'started_at': time.time(),
        }
        self._metrics_lock = threading.Lock()

    def _inc(self, key, n=1):
        with self._metrics_lock:
            self._metrics[key] = self._metrics.get(key, 0) + n

    def get_metrics(self):
        with self._metrics_lock:
            m = dict(self._metrics)
        m['uptime_sec'] = round(time.time() - m.pop('started_at'), 1)
        m['bitrate_mbps'] = round(self.bitrate_meter.mbps, 3)
        m['latency_ms'] = round(self.lat_controller.avg_latency_ms, 1)
        m['chunk_size_kb'] = round(self.lat_controller.chunk_size / 1024, 1)
        m['clients'] = self.bus.client_count
        m['cb_state'] = self.circuit_breaker.state
        m['cb_fails'] = self.circuit_breaker.consecutive_fails
        m['session_ua'] = self._session_ua
        m['first_conn'] = self._first_connection
        return m

    def _rotate_session(self):
        self._session_ua = _pick_ua()
        self._session_ip = _fake_ip()

    def add_client(self):
        cid, q = self.bus.subscribe()
        with self._client_lock:
            self._last_client = time.time()
        return cid, q

    def remove_client(self, cid):
        self.bus.unsubscribe(cid)
        with self._client_lock:
            self._last_client = time.time()

    def _should_stop(self):
        if self._stop_event.is_set():
            return True
        if self.bus.client_count > 0:
            return False
        with self._client_lock:
            return (time.time() - self._last_client) > GRACE_PERIOD

    def _pump_null(self):
        self.bus.publish_null()

    @staticmethod
    def _find_sync_offset(data):
        limit = len(data) - TS_PACKET_SIZE
        for i in range(limit):
            if data[i] == TS_SYNC_BYTE and data[i + TS_PACKET_SIZE] == TS_SYNC_BYTE:
                return i
        return -1

    def _adjust_dynamics(self, new_size):
        if new_size < TS_PACKET_SIZE * 64:
            return
        if self._avg_segment_size == 0:
            self._avg_segment_size = new_size
        else:
            self._avg_segment_size = int(self._avg_segment_size * 0.7 + new_size * 0.3)
        target_size = self._avg_segment_size
        bps = self.bitrate_meter.bps if self.bitrate_meter.bps > 0 else (target_size * 8 / 5.0)
        suture_timeout = max(2.0, min(8.0, target_size / 1_048_576 * 1.2))
        suture_window_bytes = int((bps / 8) * suture_timeout)
        if suture_window_bytes > 0:
            uniqueness_pct = max(0.02, min(0.10, 8192.0 / suture_window_bytes))
            calc_tail = int(suture_window_bytes * uniqueness_pct)
        else:
            calc_tail = int(target_size * 0.05)
        calc_tail = (calc_tail // TS_PACKET_SIZE) * TS_PACKET_SIZE
        MIN_TAIL, MAX_TAIL = 64 * TS_PACKET_SIZE, 1024 * TS_PACKET_SIZE
        self.dyn_tail_size = max(MIN_TAIL, min(MAX_TAIL, calc_tail))
        self.dyn_tail_secondary = max(32 * TS_PACKET_SIZE, self.dyn_tail_size // 2)
        self.dyn_min_bytes = min(64 * TS_PACKET_SIZE, self.dyn_tail_size // 4)
        self.dyn_suture_window_max = max(self.dyn_tail_size * 256, int(target_size * 1.5))
        self.dyn_suture_timeout = suture_timeout

    def _find_match(self, buf, tail, label):
        buf_bytes = bytes(buf)
        for size, lbl, reverso in (
            (self.dyn_tail_size, 'PRIMÁRIA', True),
            (self.dyn_tail_secondary, 'SECUNDÁRIA', False),
        ):
            chunk = tail[-size:] if len(tail) >= size else (tail if lbl == 'PRIMÁRIA' else b'')
            if not chunk:
                continue
            if reverso:
                for offset in range(10):
                    search_end = len(buf_bytes) - offset * TS_PACKET_SIZE
                    if search_end <= 0:
                        continue
                    idx = buf_bytes.rfind(chunk, 0, search_end)
                    if idx != -1:
                        rem = buf_bytes[idx + len(chunk):]
                        align = self._find_sync_offset(rem)
                        if align > 0:
                            rem = rem[align:]
                        return True, rem
            else:
                for offset in range(10):
                    idx = buf_bytes.find(chunk, offset * TS_PACKET_SIZE)
                    if idx != -1:
                        rem = buf_bytes[idx + len(chunk):]
                        align = self._find_sync_offset(rem)
                        if align > 0:
                            rem = rem[align:]
                        return True, rem
        return False, b''

    def _slide_window(self, window, max_size):
        if len(window) <= max_size:
            return
        excess = len(window) - max_size
        search_end = min(excess + TS_PACKET_SIZE * 2, len(window) - TS_PACKET_SIZE)
        cut = excess
        for i in range(excess, search_end):
            if window[i] == TS_SYNC_BYTE and window[i + TS_PACKET_SIZE] == TS_SYNC_BYTE:
                cut = i
                break
        del window[:cut]

    def _preserve_tail_on_error(self):
        if len(self.stream_tail) >= self.dyn_min_bytes:
            self.tail_cache.update_live(
                bytes(self.stream_tail), self.dyn_tail_size, self.dyn_min_bytes
            )
            self.tail_cache.promote_to_backup(self.dyn_min_bytes)

    def _ensure_prefetch_worker(self):
        if self._prefetch is None or not self._prefetch.is_alive():
            if self._prefetch:
                self._prefetch.cancel_and_drain()
            self._prefetch = PrefetchWorker(self.url)
            self._prefetch.start()

    def _try_get_prefetched(self, timeout=0.0):
        if self._prefetch is None:
            return None
        result = self._prefetch.get_result(timeout=timeout)
        if result is None:
            return None
        kind, val = result
        if kind == 'ok':
            return val
        raise val

    def _trigger_prefetch(self):
        if not self._prefetch_triggered:
            self._ensure_prefetch_worker()
            self._prefetch.trigger()
            self._prefetch_triggered = True

    def _prepare_reconnect(self):
        self.lat_controller.reset()
        if not self._first_connection:
            if not self.prebuf_ready.is_set():
                self.prebuf_ready.set()

    def run(self):
        self._ensure_prefetch_worker()
        backoff = BACKOFF_FAST
        while not self._should_stop():
            if len(self.stream_tail) >= self.dyn_min_bytes:
                self.tail_cache.update_live(
                    bytes(self.stream_tail), self.dyn_tail_size, self.dyn_min_bytes
                )
                self.tail_cache.promote_to_backup(self.dyn_min_bytes)
            if self.circuit_breaker.is_open():
                self._sleep_backoff_with_nulls(CB_COOLDOWN_SEC)
                continue
            self._rotate_session()
            resp = None
            conn_error = None
            self._prefetch_triggered = False
            try:
                resp = self._try_get_prefetched(timeout=0.0)
            except Exception as e:
                conn_error = e
            if resp is None and conn_error is None:
                def fetch_stream():
                    nonlocal_resp = {'resp': None, 'conn_error': None}
                    try:
                        nonlocal_resp['resp'] = open_stream(
                            self.url,
                            ua=self._session_ua,
                            fwd_ip=self._session_ip,
                        )
                    except Exception as e:
                        nonlocal_resp['conn_error'] = e
                    return nonlocal_resp
                fetch_result = fetch_stream()
                resp = fetch_result.get('resp')
                conn_error = fetch_result.get('conn_error')
            if conn_error:
                self._preserve_tail_on_error()
                self.circuit_breaker.record_failure()
                if not self._first_connection and not self.prebuf_ready.is_set():
                    self.prebuf_ready.set()
                jitter = random.uniform(-BACKOFF_JITTER, BACKOFF_JITTER)
                backoff = min(backoff * 1.8 + jitter, BACKOFF_MAX)
                self._sleep_backoff_with_nulls(max(BACKOFF_FAST, backoff))
                self._inc('reconnections')
            elif resp:
                self.circuit_breaker.record_success()
                backoff = BACKOFF_FAST
                if self._first_connection:
                    self.prebuf_ready.clear()
                    self._bytes_sent = 0
                else:
                    self._prepare_reconnect()
                self._read_segment(resp)
                try:
                    resp.close()
                except Exception:
                    pass
                self._first_connection = False
            else:
                break
        if self._prefetch:
            self._prefetch.cancel_and_drain()

    def _sleep_backoff_with_nulls(self, delay):
        deadline = time.monotonic() + delay
        while time.monotonic() < deadline and not self._should_stop():
            self._pump_null()
            time.sleep(min(NULL_PUMP_INTERVAL, deadline - time.monotonic()))

    def _read_segment(self, resp):
        suture_window = bytearray()
        need_suture = self.tail_cache.has_any(self.dyn_min_bytes)
        suture_start_time = time.monotonic()
        content_length = resp.getheader('Content-Length')
        expected_size = int(content_length) if content_length and content_length.isdigit() else 0
        if expected_size > 0:
            self._adjust_dynamics(expected_size)
        bytes_read_this_conn = 0
        prefetch_threshold = (
            expected_size - int(PREFETCH_TRIGGER_MB * 1_048_576)
            if expected_size > 0
            else int(self._avg_segment_size * 0.85) if self._avg_segment_size > 0
            else int(PREFETCH_TRIGGER_MB * 2 * 1_048_576)
        )
        last_chunk_time = time.monotonic()
        while not self._should_stop():
            if time.monotonic() - last_chunk_time > STALL_TIMEOUT:
                self._preserve_tail_on_error()
                self._inc('stalls')
                break
            if need_suture:
                chunk_size = 512 * 1024
            else:
                chunk_size = self.lat_controller.chunk_size
                if self.bitrate_meter.bps > 0:
                    brate_chunk = self.bitrate_meter.chunk_size_for_target(
                        self.bitrate_meter.bps, interval_sec=0.1
                    )
                    chunk_size = min(chunk_size, brate_chunk)
                chunk_size = max(LAT_CHUNK_MIN, min(LAT_CHUNK_MAX, chunk_size))
            self.lat_controller.mark_read_start()
            try:
                chunk = resp.read(chunk_size)
            except Exception as e:
                self._preserve_tail_on_error()
                if bytes_read_this_conn > 0:
                    self._adjust_dynamics(bytes_read_this_conn)
                break
            self.lat_controller.mark_read_end(len(chunk) if chunk else 0)
            if not chunk:
                if expected_size == 0 and bytes_read_this_conn > 0:
                    self._adjust_dynamics(bytes_read_this_conn)
                break
            last_chunk_time = time.monotonic()
            bytes_read_this_conn += len(chunk)
            self.bitrate_meter.add(len(chunk))
            self._inc('bytes_total', len(chunk))
            if bytes_read_this_conn >= prefetch_threshold:
                self._trigger_prefetch()
            if need_suture:
                suture_window.extend(chunk)
                for getter, lbl in (
                    (self.tail_cache.get_for_suture, 'LIVE'),
                    (self.tail_cache.get_for_recovery, 'BACKUP'),
                ):
                    tail = getter()
                    if tail:
                        ok, rem = self._find_match(suture_window, tail, lbl)
                        if ok:
                            need_suture = False
                            self.has_initial_lock = False
                            if rem:
                                disco_pids = self.cc_fixer.detect_discontinuous_pids(rem)
                                if disco_pids:
                                    self.cc_fixer.mark_resync(disco_pids)
                            self._inc('sutures_ok')
                            self._process_and_push(rem)
                            suture_window.clear()
                            break
                if not need_suture:
                    if suture_window:
                        self._process_and_push(bytes(suture_window))
                        suture_window.clear()
                    continue
                elapsed_suture = time.monotonic() - suture_start_time
                if elapsed_suture > 0.5:
                    self._pump_null()
                if elapsed_suture > self.dyn_suture_timeout:
                    need_suture = False
                    self.has_initial_lock = False
                    self.cc_fixer.mark_resync(None)
                    self._inc('sutures_timeout')
                    suture_window.clear()
                    self._pump_null()
                    continue
                if len(suture_window) > self.dyn_suture_window_max:
                    self._slide_window(suture_window, self.dyn_suture_window_max)
            else:
                self._process_and_push(chunk)

    def _process_and_push(self, raw):
        if not raw:
            return
        self.residual_buffer.extend(raw)
        buf = self.residual_buffer
        if not self.has_initial_lock:
            idx = self._find_sync_offset(buf)
            if idx == -1:
                if len(buf) > TS_PACKET_SIZE * 8:
                    del buf[:len(buf) - TS_PACKET_SIZE * 8]
                return
            del buf[:idx]
            self.has_initial_lock = True
        n = len(buf) // TS_PACKET_SIZE
        if n == 0:
            return
        used = n * TS_PACKET_SIZE
        payload = bytes(buf[:used])
        del buf[:used]
        self.stream_tail.extend(payload)
        max_tail = self.dyn_tail_size + self.dyn_tail_secondary
        if len(self.stream_tail) > max_tail:
            del self.stream_tail[:len(self.stream_tail) - self.dyn_tail_size]
        fixed = b''.join(
            self.cc_fixer.fix(payload[i:i + TS_PACKET_SIZE])
            for i in range(0, len(payload), TS_PACKET_SIZE)
        )
        self.bus.publish(fixed)
        self._bytes_sent += len(fixed)
        if not self.prebuf_ready.is_set() and self._bytes_sent >= self._prebuf_bytes_first:
            self.prebuf_ready.set()

    def stop(self):
        self._stop_event.set()
        if self._prefetch:
            self._prefetch.cancel_and_drain()

class StreamManager(object):
    def __init__(self):
        self._streams = {}
        self._lock = threading.Lock()

    def get_or_create(self, url):
        with self._lock:
            eng = self._streams.get(url)
            if eng and not eng._stop_event.is_set():
                return eng
            eng = TSEngine(url)
            self._streams[url] = eng
            eng.start()
            return eng

    def cleanup(self, url):
        with self._lock:
            eng = self._streams.get(url)
            if eng and eng.bus.client_count == 0:
                del self._streams[url]

    def get_all_metrics(self):
        with self._lock:
            return dict((url, eng.get_metrics()) for url, eng in self._streams.items())

_stream_mgr = StreamManager()

class TSHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/metrics':
            self._serve_metrics()
            return
        params = parse_qs(parsed.query)
        url = params.get('url', [None])[0]
        if not url:
            self.send_error(400, 'Missing url parameter')
            return
        engine = _stream_mgr.get_or_create(url)
        cid, client_queue = engine.add_client()
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Connection', 'close')
            self.send_header('Transfer-Encoding', 'chunked')
            self.end_headers()
        except Exception:
            engine.remove_client(cid)
            _stream_mgr.cleanup(url)
            return
        try:
            engine.prebuf_ready.wait(PREBUF_WAIT_TIMEOUT)
            try:
                self.connection.settimeout(10.0)
            except Exception:
                pass
            while not engine._stop_event.is_set():
                try:
                    chunk = client_queue.get(timeout=1.0)
                    self.wfile.write(("%X\r\n" % len(chunk)).encode())
                    self.wfile.write(chunk)
                    self.wfile.write(b'\r\n')
                    self.wfile.flush()
                except queue.Empty:
                    continue
                except (BrokenPipeError, ConnectionResetError, ValueError, OSError):
                    break
                except Exception:
                    break
        finally:
            engine.remove_client(cid)
            if engine.bus.client_count == 0:
                engine.stop()
            _stream_mgr.cleanup(url)

    def _serve_metrics(self):
        data = _stream_mgr.get_all_metrics()
        body = json.dumps(data, indent=2).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    handle_error = lambda self, request, client_address: None

_server_instance = None
_server_lock = threading.Lock()

def _ensure_server_running(port=0):
    global _server_instance
    with _server_lock:
        if _server_instance is None:
            _server_instance = ThreadedHTTPServer(('127.0.0.1', port), TSHandler)
            t = threading.Thread(target=_server_instance.serve_forever, daemon=True)
            t.start()
    return _server_instance.server_address[1]

def handle_play(params, port=0):
    url = params.get('url', [None])[0]
    if not url:
        return
    real_port = _ensure_server_running(port)
    print("http://127.0.0.1:%d/stream?url=%s" % (real_port, quote(url, safe='')))

if __name__ == '__main__':
    if len(sys.argv) >= 3:
        p = parse_qs(sys.argv[2].lstrip('?'))
        handle_play(p, int(sys.argv[1]))
    else:
        real_port = _ensure_server_running()
        if real_port:
            print("[Deivid Silva] Stream:  http://127.0.0.1:%d/stream?url=<URL>" % real_port)
            print("[Deivid Silva] Metrics: http://127.0.0.1:%d/metrics" % real_port)
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass