# -*- coding: utf-8 -*-
"""
Proxy HLS Ultra-Resiliente para Kodi e InputStream Adaptive (Versão Dinâmica)

Novas funcionalidades:
- Chunk size dinâmico (se ajusta à média dos últimos segmentos).
- Retry dinâmico (baseado em histórico recente de erros/sucessos).
- Sempre retornar 200 OK em falhas, fornecendo segmento "silencioso" (dummy) adaptado ao tamanho
  dos últimos segmentos baixados para evitar interrupção de reprodução.
- Detecta #EXT-X-TARGETDURATION e tempo médio dos segmentos para reconexões proativas.
- Reinicia sessão, rotaciona User-Agent e reconsulta o manifesto automaticamente após falhas.
- Mantém HLSAddon inalterado (não remover).
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import re
from collections import OrderedDict, deque

# Bibliotecas de requisição
try:
    import requests as real_requests
    import requests.exceptions as req_exc
except ImportError:
    print("Erro: A biblioteca 'requests' é necessária. Instale com: pip install requests")
    sys.exit(1)

# Cliente DNS-over-HTTPS (DoH) para maior resiliência (opcional)
try:
    from doh_client import requests as doh_requests
except ImportError:
    logging.warning("doh_client não encontrado. Usando requests padrão, o que pode ser menos resiliente a bloqueios de DNS.")
    doh_requests = real_requests

# Mock para o ambiente Kodi, permitindo testes fora dele
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    class XBMCMock:
        LOGINFO = 1
        LOGERROR = 3
        def translatePath(self, path): return os.getcwd()
        def log(self, msg, level=0): print(f"[KODI-MOCK] {msg}")
    xbmc = XBMCMock()
    xbmcgui = xbmcplugin = xbmc

# ---------------- CONFIGURAÇÕES GLOBAIS ----------------
PROXY_HOST = "127.0.0.1"
CONNECTION_TIMEOUT = 15     # Timeout para estabelecer conexão
STREAM_TIMEOUT = 30         # Timeout para baixar cada segmento/manifesto (padrão)
SEGMENT_TTL = 300           # Tempo de vida do cache de segmentos (5 min)
MANIFEST_TTL = 6.0          # TTL padrão para manifestos (sobrescrito por detect)
MAX_CACHE_SIZE = 100 * 1024 * 1024  # 100 MB de cache máximo
MAX_MANIFEST_RETRIES = 12   # Máximo de tentativas antes de enviar o dummy manifesto
MAX_BACKOFF_DELAY = 20      # Máximo de atraso do backoff em segundos
EXTREME_429_WAIT_SECONDS = 45 # Tempo de espera dedicado para 429 persistente
CHUNK_SIZE_DEFAULT = 8 * 1024       # 8 KB por pedaço padrão
MIN_CHUNK_SIZE = 4 * 1024
MAX_CHUNK_SIZE = 64 * 1024

# Histórico para decisões dinâmicas
RECENT_SEGMENT_SIZES = deque(maxlen=50)     # mantém tamanhos em bytes dos últimos segmentos
RECENT_MANIFEST_DURATIONS = deque(maxlen=20) # mantém target durations detectados
RECENT_ERRORS = deque(maxlen=50)            # timestamps de erros recentes

# Caches e Segmento Dummy
manifest_cache = OrderedDict()
segment_cache = OrderedDict()
current_cache_size = 0

# Dummy TS base (um pacote TS válido repetido; será ajustado dinamicamente)
BASE_TS_PACKET = bytes([0x47] + [0x1F] * 187)  # 188 bytes por pacote TS

DUMMY_MANIFEST = (
    "#EXTM3U\n"
    "#EXT-X-VERSION:3\n"
    "#EXT-X-TARGETDURATION:3\n"
    "#EXT-X-MEDIA-SEQUENCE:0\n"
    "#EXTINF:3.0,\n"
    "dummy_segment.ts\n"
)

# Pool de User-Agents para o cycling
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Android 14; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0"
]

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- GERENCIADOR DE SESSÃO COM USER-AGENT CYCLING ----------------
class SessionManager:
    """Gerencia as sessões de requests, implementando o User-Agent Cycling e reinicialização."""
    
    def __init__(self):
        # armazenar um contador por session id para forçar rotação
        self.sid_counter = {}
    
    def _create_session(self, sid):
        # Preferir DoH client se disponível
        session = doh_requests.Session() if hasattr(doh_requests, "Session") else real_requests.Session()
        session.headers.update({
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
        })
        # podemos ajustar outros parâmetros: retries, pools etc. (requests.adapters não adicionado para simplicidade)
        return session

    def get_session(self, sid):
        # cria nova sessão por chamada para garantir cycling e evitar reuse de sockets problemáticos
        return self._create_session(sid)

    def reset_session(self, sid):
        logging.warning(f"[{sid}] Resetando sessão e rotacionando User-Agent.")
        return self._create_session(sid)

session_manager = SessionManager()

# ---------------- GERENCIADOR DE CACHE (LRU com limites) ----------------
def _evict_cache_if_needed():
    global current_cache_size
    while current_cache_size > MAX_CACHE_SIZE:
        if segment_cache:
            _, (ts, data, _) = segment_cache.popitem(last=False)
            current_cache_size -= len(data)
        elif manifest_cache:
            key_to_pop, (ts, data, _, _) = manifest_cache.popitem(last=False)
            current_cache_size -= len(data.encode("utf-8"))
        else:
            break

def cache_get(url):
    now = time.time()
    if url in segment_cache:
        ts, data, headers = segment_cache[url]
        if now - ts < SEGMENT_TTL:
            segment_cache.move_to_end(url)
            return data, headers
    if url in manifest_cache:
        ts, data, base_url, ttl = manifest_cache[url]
        if now - ts < ttl:
            manifest_cache.move_to_end(url)
            return data, base_url
    return None

def cache_set_manifest(url, data, base_url, ttl):
    global current_cache_size
    size = len(data.encode("utf-8"))
    manifest_cache[url] = (time.time(), data, base_url, ttl)
    manifest_cache.move_to_end(url)
    current_cache_size += size
    _evict_cache_if_needed()

def cache_set_segment(url, data, headers):
    global current_cache_size
    size = len(data)
    segment_cache[url] = (time.time(), data, headers)
    segment_cache.move_to_end(url)
    current_cache_size += size
    _evict_cache_if_needed()

def clear_manifest_cache():
    global current_cache_size
    logging.warning("Limpando cache de manifestos para forçar atualização.")
    keys_to_remove = list(manifest_cache.keys())
    for key in keys_to_remove:
        if key in manifest_cache:
            _, data, _, _ = manifest_cache.pop(key)
            current_cache_size -= len(data.encode("utf-8"))

# ---------------- UTILITÁRIOS ----------------
def _obfuscate_url_for_log(url):
    try:
        parsed = urllib.parse.urlparse(url)
        return "***" + os.path.basename(parsed.path) + ("?..." if parsed.query else "")
    except Exception:
        return "****"

def _record_segment_size(size):
    try:
        RECENT_SEGMENT_SIZES.append(size)
    except Exception:
        pass

def _average_recent_segment_size():
    if not RECENT_SEGMENT_SIZES:
        return 256 * 1024  # fallback 256KB
    return sum(RECENT_SEGMENT_SIZES) // len(RECENT_SEGMENT_SIZES)

def _adjust_chunk_size():
    avg = _average_recent_segment_size()
    # proporcional: quanto maior o segmento, maior o chunk, com limites
    chunk = min(MAX_CHUNK_SIZE, max(MIN_CHUNK_SIZE, int(avg / 64)))  # divide por 64 => ~4KB chunks para 256KB
    return chunk

def _record_manifest_duration(d):
    try:
        RECENT_MANIFEST_DURATIONS.append(d)
    except Exception:
        pass

def _average_manifest_target_duration():
    if RECENT_MANIFEST_DURATIONS:
        return sum(RECENT_MANIFEST_DURATIONS) / len(RECENT_MANIFEST_DURATIONS)
    return MANIFEST_TTL

def _record_error():
    RECENT_ERRORS.append(time.time())
    # optional: trim older than window (e.g., 10 minutes)
    cutoff = time.time() - 600
    while RECENT_ERRORS and RECENT_ERRORS[0] < cutoff:
        RECENT_ERRORS.popleft()

def _dynamic_retry_limit():
    # se muitos erros recentes -> aumentar tentativas para ser mais resiliente, senão reduzir
    errors = len(RECENT_ERRORS)
    if errors > 20:
        return min(MAX_MANIFEST_RETRIES, 20)
    if errors > 5:
        return min(MAX_MANIFEST_RETRIES, 14)
    return MAX_MANIFEST_RETRIES

def _compose_silent_segment(desired_size_bytes):
    # Gera um segmento "silencioso"/dummy composto por múltiplos pacotes TS para aproximar o tamanho desejado.
    if desired_size_bytes < 188:
        desired_size_bytes = 188
    packets = max(1, desired_size_bytes // 188)
    return BASE_TS_PACKET * packets

# ---------------- MANIPULADOR DO PROXY HLS ----------------
class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        # Sempre responde 200 OK para evitar que o player pare por erros de status — transformando erros em conteúdo de fallback.
        if "?url=" not in self.path:
            self.send_response(200)
            self.end_headers()
            return

        params = urllib.parse.parse_qs(self.path.split("?", 1)[1])
        url = urllib.parse.unquote_plus(params.get("url", [None])[0])
        sid = params.get("session_id", ["default"])[0]

        if not url:
            self.send_response(200)
            self.end_headers()
            return

        # rotaciona sessão proativa se houver histórico de erros
        if len(RECENT_ERRORS) > 0 and random.random() < 0.2:
            session_manager.reset_session(sid)

        if url.lower().endswith(".m3u8"):
            self._handle_manifest(url, sid)
        elif ".key" in url.lower() or "/key/" in url.lower():
            self._handle_key(url, sid)
        else:
            self._handle_segment(url, sid)

    def _handle_manifest(self, url, sid, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        dynamic_max_retries = _dynamic_retry_limit()

        cached = cache_get(url)
        if cached and retry_count == 0:
            content, base_url = cached
            return self._send_manifest(content, base_url, sid)

        if retry_count >= dynamic_max_retries:
            logging.error(f"[{sid}] Falha persistente ao baixar manifesto {log_url}. Enviando manifesto dummy (200 OK).")
            # registra erro e força limpeza de cache para próxima tentativa real
            _record_error()
            return self._send_manifest(DUMMY_MANIFEST, url, sid)

        try:
            sess = session_manager.get_session(sid)
            timeout_tuple = (CONNECTION_TIMEOUT, STREAM_TIMEOUT)
            r = sess.get(url, timeout=timeout_tuple, verify=False)

            # Lida com 429 separadamente com backoff e rotação de user agent
            if r.status_code == 429:
                wait_time = 0
                if 'Retry-After' in r.headers:
                    try:
                        wait_time = int(r.headers['Retry-After'])
                    except Exception:
                        pass
                if wait_time == 0:
                    wait_time = min(2 ** retry_count, MAX_BACKOFF_DELAY)
                    if retry_count >= 5:
                        wait_time = EXTREME_429_WAIT_SECONDS
                logging.error(f"[{sid}] 429 para manifesto {log_url}. Esperando {wait_time}s e rotacionando UA.")
                session_manager.reset_session(sid)
                time.sleep(wait_time)
                _record_error()
                return self._handle_manifest(url, sid, retry_count + 1)

            if r.status_code >= 400:
                logging.error(f"[{sid}] Status {r.status_code} ao baixar manifesto {log_url}. Forçando retry com reset.")
                r.raise_for_status()

            content = r.text
            base_url = r.url
            ttl = self._detect_manifest_ttl(content)
            _record_manifest_duration(ttl)

            # Reconexão proativa: se target duration alta, podemos reiniciar sessão para evitar reuse de sockets degradados
            if ttl > (MANIFEST_TTL * 2):
                logging.info(f"[{sid}] TargetDuration {ttl} detectado; reiniciando sessão proativa.")
                session_manager.reset_session(sid)

            logging.info(f"[{sid}] Manifesto {log_url} obtido com sucesso. TTL={ttl:.2f}s. Servindo para cliente e cacheando.")
            # limpa erros recentes após sucesso
            # keep a sliding window: remove old errors
            _record_error() if False else None  # noop; success means do not add error
            cache_set_manifest(url, content, base_url, ttl)
            return self._send_manifest(content, base_url, sid)

        except req_exc.RequestException as e:
            logging.error(f"[{sid}] Erro de rede ao obter manifesto {log_url} (Tentativa {retry_count + 1}/{dynamic_max_retries}): {e}. Rotacionando UA e aplicando backoff.")
            session_manager.reset_session(sid)
            delay = min(2 ** retry_count, MAX_BACKOFF_DELAY)
            _record_error()
            time.sleep(delay)
            # força limpar cache para garantir re-resolução em seguida
            clear_manifest_cache()
            return self._handle_manifest(url, sid, retry_count + 1)

        except Exception as e:
            logging.error(f"[{sid}] Erro inesperado ao obter manifesto {log_url}: {e}. Tentando novamente com reset.")
            session_manager.reset_session(sid)
            delay = min(2 ** retry_count, MAX_BACKOFF_DELAY)
            _record_error()
            time.sleep(delay)
            clear_manifest_cache()
            return self._handle_manifest(url, sid, retry_count + 1)

    def _detect_manifest_ttl(self, content):
        # Detecta EXT-X-TARGETDURATION e calcula TTL baseado no target e EXTINF médio
        match = re.search(r"#EXT-X-TARGETDURATION:([\d\.]+)", content)
        if match:
            try:
                td = float(match.group(1))
                # TTL menor que target para reconexão proativa (80% do target)
                ttl = max(1.0, td * 0.8)
                return ttl
            except Exception:
                pass
        # fallback: inferir a partir de EXTINF
        matches = re.findall(r"#EXTINF:([\d\.]+)", content)
        if matches:
            avg = sum(float(x) for x in matches) / len(matches)
            return max(3.0, avg * 2.0)
        return MANIFEST_TTL

    def _send_manifest(self, content, base_url, sid):
        proxy_lines = []
        for line in content.splitlines():
            if line.startswith("#EXT-X-ENDLIST"):
                continue

            if line.startswith("#EXT-X-KEY"):
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    key_url = urllib.parse.urljoin(base_url, match.group(1))
                    proxy_key_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(key_url)}&session_id={sid}"
                    line = line.replace(match.group(1), proxy_key_url)
                proxy_lines.append(line)
            elif line.startswith("#") or not line.strip():
                proxy_lines.append(line)
            else:
                # linhas de segmentos
                if line.strip() == "dummy_segment.ts" and content.strip() == DUMMY_MANIFEST.strip():
                    full_url = "DUMMY_FAIL_SEGMENT"
                else:
                    full_url = urllib.parse.urljoin(base_url, line)
                proxy_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={sid}"
                proxy_lines.append(proxy_url)

        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        try:
            self.wfile.write("\n".join(proxy_lines).encode("utf-8"))
        except BrokenPipeError:
            pass

    def _handle_key(self, url, sid, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        if retry_count >= 3:
            logging.critical(f"[{sid}] Falha persistente ao buscar chave {log_url}. Retornando 200 OK com conteúdo vazio.")
            # Retorna 200 mas conteúdo vazio para não quebrar fluxo; player provavelmente falhará na decriptação,
            # mas mantemos o comportamento pedido: não interromper com erro HTTP
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        try:
            sess = session_manager.get_session(sid)
            r = sess.get(url, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
            if r.status_code >= 400:
                raise req_exc.RequestException(f"Erro HTTP ao buscar chave: {r.status_code}")
            r.raise_for_status()
            headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding"]}
            # envia 200 com o conteúdo da chave
            self._send_response(r.content, headers)
        except Exception as e:
            logging.error(f"[{sid}] Falha ao buscar chave {log_url} (Tentativa {retry_count + 1}/3): {e}. Rotacionando sessão e tentando novamente.")
            session_manager.reset_session(sid)
            time.sleep(min(2 ** retry_count, 5))
            _record_error()
            return self._handle_key(url, sid, retry_count + 1)

    def _handle_segment(self, url, sid, retry_count=0):
        # Caso de segmento dummy interno (manifesto dummy)
        if url == "DUMMY_FAIL_SEGMENT":
            logging.info(f"[{sid}] Servindo segmento dummy devido a manifesto dummy anterior.")
            desired = int(_average_recent_segment_size() or (256 * 1024))
            dummy_data = _compose_silent_segment(desired)
            headers = {"Content-Type": "video/mp2t", "Content-Length": str(len(dummy_data))}
            return self._send_response(dummy_data, headers)

        log_url = _obfuscate_url_for_log(url)
        try:
            cached = cache_get(url)
            if cached:
                data, headers = cached
                return self._send_response(data, headers)

            sess = session_manager.get_session(sid)
            # chunk size dinâmico
            chunk_size = _adjust_chunk_size()
            timeout_tuple = (CONNECTION_TIMEOUT, STREAM_TIMEOUT)
            r = sess.get(url, stream=True, timeout=timeout_tuple, verify=False)

            if r.status_code >= 400:
                logging.warning(f"[{sid}] Status {r.status_code} recebido para segmento {log_url}. Forçando dummy com 200 OK.")
                raise req_exc.RequestException(f"Erro HTTP no segmento: {r.status_code}")

            r.raise_for_status()

            headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding", "content-length"]}
            # Stream para o cliente e construímos buffer para cache
            return self._stream_response_and_cache_dynamic(r, url, headers, chunk_size, sid)

        except Exception as e:
            logging.warning(f"[{sid}] Falha no segmento {log_url}: {e}. Forçando atualização do manifesto, rotacionando sessão e servindo dummy (200 OK).")
            _record_error()
            clear_manifest_cache()
            session_manager.reset_session(sid)
            # gera dummy adaptado: baseado nos últimos tamanhos
            desired = int(_average_recent_segment_size() or (128 * 1024))
            dummy_data = _compose_silent_segment(desired)
            headers = {"Content-Type": "video/mp2t", "Content-Length": str(len(dummy_data))}
            return self._send_response(dummy_data, headers)

    def _send_response(self, content, headers):
        """Envia uma resposta completa (bom para chaves/dummies e para segmentos cacheados)."""
        # Sempre 200 OK para manter a reprodução viva
        self.send_response(200)
        # Garante cabeçalhos mínimos
        hdrs = headers.copy()
        if "Content-Length" not in hdrs:
            hdrs["Content-Length"] = str(len(content))
        for k, v in hdrs.items():
            try:
                self.send_header(k, v)
            except Exception:
                pass
        self.end_headers()
        try:
            self.wfile.write(content)
        except BrokenPipeError:
            pass

    def _stream_response_and_cache_dynamic(self, response, url, headers, chunk_size, sid):
        """
        Transmite a resposta em pedaços (chunks) para o cliente e monta o conteúdo completo para armazenar em cache.
        Ajusta o comportamento dinamicamente e registra tamanhos para futuros ajustes.
        """
        # Envia headers (status 200)
        self.send_response(200)
        for k, v in headers.items():
            try:
                self.send_header(k, v)
            except Exception:
                pass
        self.end_headers()

        data_chunks = []
        total = 0
        try:
            for chunk in response.iter_content(chunk_size=chunk_size):
                if not chunk:
                    continue
                try:
                    self.wfile.write(chunk)
                except BrokenPipeError:
                    # cliente fechou a conexão; interrompe streaming
                    logging.warning(f"[{sid}] Conexão do player fechada durante streaming do segmento.")
                    break
                data_chunks.append(chunk)
                total += len(chunk)
        except (BrokenPipeError, ConnectionResetError) as e:
            logging.warning(f"[{sid}] Stream interrompido: {e}")
        finally:
            response.close()

        if total > 0:
            full_data = b"".join(data_chunks)
            cache_set_segment(url, full_data, headers)
            _record_segment_size(len(full_data))
            # registro de sucesso remove comportamento pessimista: opcional
            # se havia muitos erros, reduzir contagem aos poucos - aqui não implementado explicitamente
        else:
            # se nada foi recebido, servir dummy de fallback (mas isso deve ter sido tratado na exceção)
            desired = int(_average_recent_segment_size() or (64 * 1024))
            dummy_data = _compose_silent_segment(desired)
            try:
                self.wfile.write(dummy_data)
            except BrokenPipeError:
                pass
        return

    def log_message(self, format, *args):
        # Suprime logs nativos do BaseHTTPRequestHandler
        return

# ---------------- GERENCIADOR DO PROXY ----------------
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.port = None

    def start(self):
        for _ in range(30): # tentativas de porta
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.port = port
                xbmc.log(f"Proxy HLS Dinâmico iniciado em http://{PROXY_HOST}:{port}", xbmc.LOGINFO)
                return True
            except OSError:
                continue
        xbmc.log("FALHA: Não foi possível iniciar o proxy HLS. Nenhuma porta disponível.", xbmc.LOGERROR)
        return False

    def stop(self):
        if self.server:
            xbmc.log("Parando proxy HLS...", xbmc.LOGINFO)
            self.server.shutdown()
            self.server.server_close()

# ---------------- INTEGRAÇÃO COM O ADDON KODI ----------------
# NÃO REMOVER: HLSAddon deve permanecer presente conforme solicitado
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype="live"):
        if not self.proxy.start():
            try:
                xbmcgui.Dialog().notification("Erro de Proxy", "Não foi possível iniciar o proxy local.", xbmcgui.NOTIFICATION_ERROR)
            except Exception:
                xbmc.log("Não foi possível iniciar o proxy local.", xbmc.LOGERROR)
            return

        sid = f"stream_{int(time.time())}_{random.randint(0,9999)}"
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.port}/?url={urllib.parse.quote_plus(url)}&session_id={sid}"
        
        li = xbmcgui.ListItem(path=proxy_url)
        li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)

        if stype == "live":
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            li.setProperty("IsLive", "true")
            
            li.setProperty("inputstream.adaptive.live_delay", "99")
            li.setProperty("inputstream.adaptive.live_delay_automatic", "true")
            
            # Aumenta o buffer de memória do player (20 MB)
            li.setProperty("inputstream.adaptive.stream_buffer_size", "20971520") 
            
            # Aumenta o buffer inicial para 20 segundos
            li.setProperty("inputstream.adaptive.initial_buffer_duration", "20")
            
            li.setProperty("inputstream.adaptive.play_segment_stall_timeout", "60")
            
            li.setProperty("inputstream.adaptive.max_bandwidth", "0")
            li.setProperty("inputstream.adaptive.max_resolution_switch", "0")

        try:
            xbmcplugin.setResolvedUrl(self.handle, True, li)
        except Exception:
            xbmc.log("Falha ao resolver URL no Kodi (setResolvedUrl).", xbmc.LOGERROR)

# ---------------- PONTO DE ENTRADA ----------------
def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s T:%(thread)d %(levelname)s <general>: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

def main():
    setup_logging()
    if len(sys.argv) < 3:
        pass

    handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    addon = HLSAddon(handle)
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}

    if args.get("action", [None])[0] == "play_stream":
        stream_url = args.get("stream_url", [None])[0]
        if stream_url:
            addon.play_stream(stream_url)
        else:
            xbmc.log("Nenhuma URL de stream fornecida.", xbmc.LOGERROR)

if __name__ == "__main__":
    if 'xbmc' not in sys.modules:
        setup_logging()
    main()