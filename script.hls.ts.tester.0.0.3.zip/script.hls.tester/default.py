import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import os
import re
import socket
import ssl
import json
from functools import lru_cache
from collections import defaultdict
from typing import Optional, Dict, Tuple, List

# --- Configurações Globais ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE = int(sys.argv[1])

DEFAULT_PROXY_PORT = 65323
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 5
CHUNK_SIZE = 8192 * 50
CONNECTION_TIMEOUT = 15
STREAM_TIMEOUT = 30
MAX_CACHE_SIZE = 1024

HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate',
    'Connection': 'keep-alive'
})

ADAPTIVE_STREAMING = True
MIN_BITRATE = 500000
MAX_BITRATE = 8000000
BANDWIDTH_MONITOR_WINDOW = 10

# Servidores DoH alternativos compatíveis com Kodi
DOH_RESOLVERS = [
    'https://chrome.cloudflare-dns.com/dns-query',
    'https://dns.google/dns-query',
    'https://dns10.quad9.net/dns-query'
]
DOH_CACHE_TTL = 300  # 5 minutes TTL for DNS records
DOH_RETRIES = 3
DOH_RETRY_DELAY = 1

# --- Sistema de Log Melhorado ---
class KodiLogger:
    @staticmethod
    def log(msg: str, level: int = xbmc.LOGINFO):
        """Log formatado com nome do addon e níveis personalizados"""
        level_map = {
            'DEBUG': xbmc.LOGDEBUG,
            'INFO': xbmc.LOGINFO,
            'WARNING': xbmc.LOGWARNING,
            'ERROR': xbmc.LOGERROR,
            'FATAL': xbmc.LOGFATAL
        }
        if isinstance(level, str):
            level = level_map.get(level.upper(), xbmc.LOGINFO)
        xbmc.log(f"[{ADDON_NAME}] {msg}", level)

    @staticmethod
    def debug(msg: str):
        KodiLogger.log(msg, xbmc.LOGDEBUG)

    @staticmethod
    def info(msg: str):
        KodiLogger.log(msg, xbmc.LOGINFO)

    @staticmethod
    def warning(msg: str):
        KodiLogger.log(msg, xbmc.LOGWARNING)

    @staticmethod
    def error(msg: str):
        KodiLogger.log(msg, xbmc.LOGERROR)

log = KodiLogger.log
debug = KodiLogger.debug
info = KodiLogger.info
warning = KodiLogger.warning
error = KodiLogger.error

# --- DNS-over-HTTPS (DoH) Resolver Aprimorado e Compatível com Kodi ---
class DoHResolver:
    def __init__(self, resolver_urls: list = None, cache_ttl: int = DOH_CACHE_TTL, 
                 retries: int = DOH_RETRIES, retry_delay: int = DOH_RETRY_DELAY):
        self.resolver_urls = resolver_urls or DOH_RESOLVERS
        self.cache_ttl = cache_ttl
        self.retries = retries
        self.retry_delay = retry_delay
        self._cache: Dict[str, Tuple[str, float]] = {}  # {hostname: (ip_address, expiry_time)}
        self.current_resolver_index = 0

    def get_next_resolver(self) -> str:
        """Obtém o próximo resolvedor DNS da lista com fallback circular"""
        resolver = self.resolver_urls[self.current_resolver_index]
        self.current_resolver_index = (self.current_resolver_index + 1) % len(self.resolver_urls)
        return resolver

    def resolve(self, hostname: str) -> Optional[str]:
        """
        Resolve um hostname para um endereço IP usando DoH com cache, retries e fallback entre servidores.
        """
        # Verifica se é um IP válido diretamente
        if self._is_valid_ip(hostname):
            return hostname

        # 1. Tentar obter do cache
        cached_entry = self._cache.get(hostname)
        if cached_entry:
            ip_address, expiry_time = cached_entry
            if time.time() < expiry_time:
                debug(f"[DOH] Usando IP em cache para {hostname}: {ip_address}")
                return ip_address
            else:
                debug(f"[DOH] Cache expirado para {hostname}, buscando novamente.")
                self._cache.pop(hostname)  # Remove entrada expirada

        # 2. Tentar resolver via DoH com fallback entre servidores
        last_error = None
        for resolver_url in self.resolver_urls:
            for attempt in range(self.retries):
                try:
                    debug(f"[DOH] Tentando resolver {hostname} via {resolver_url} (tentativa {attempt + 1}/{self.retries})")
                    
                    params = {'name': hostname, 'type': 'A'}
                    headers = {
                        'accept': 'application/dns-json',
                        'User-Agent': HTTP_SESSION.headers['User-Agent']
                    }
                    
                    response = HTTP_SESSION.get(
                        resolver_url,
                        params=params,
                        headers=headers,
                        timeout=5
                    )
                    response.raise_for_status()
                    
                    data = response.json()
                    debug(f"[DOH] Resposta DoH para {hostname}: {data}")

                    # Processa a resposta DNS
                    ip_address = self._parse_doh_response(data, hostname)
                    if ip_address:
                        ttl = self._get_ttl_from_response(data) or self.cache_ttl
                        expiry_time = time.time() + ttl
                        self._cache[hostname] = (ip_address, expiry_time)
                        info(f"[DOH] Hostname {hostname} resolvido para {ip_address} via {resolver_url} (TTL: {ttl}s)")
                        return ip_address
                    
                    # Se chegou aqui, não encontrou IP válido
                    warning(f"[DOH] Nenhum registro A encontrado para {hostname} na resposta de {resolver_url}")
                    break  # Sai das tentativas para este resolvedor

                except requests.exceptions.Timeout as e:
                    last_error = f"Timeout ao resolver {hostname} via DoH: {e}"
                    warning(f"[DOH] {last_error} (tentativa {attempt + 1}/{self.retries})")
                    if attempt < self.retries - 1:
                        time.sleep(self.retry_delay)
                except requests.exceptions.RequestException as e:
                    last_error = f"Erro de requisição ao resolver {hostname} via DoH: {e}"
                    error(f"[DOH] {last_error} (tentativa {attempt + 1}/{self.retries})")
                    break  # Erros de requisição não são tentados novamente para o mesmo resolvedor
                except Exception as e:
                    last_error = f"Erro inesperado ao resolver {hostname}: {e}"
                    error(f"[DOH] {last_error} (tentativa {attempt + 1}/{self.retries})")
                    break  # Erros inesperados não são tentados novamente

        error(f"[DOH] Falha ao resolver {hostname} após tentar todos os resolvedores. Último erro: {last_error}")
        return None

    def _parse_doh_response(self, data: dict, hostname: str) -> Optional[str]:
        """Analisa a resposta DoH e extrai o endereço IP"""
        # Verifica respostas diretas
        for answer in data.get("Answer", []):
            if answer.get("type") == 1 and answer.get("name", "").lower() == hostname.lower():
                return answer.get("data")

        # Verifica se há CNAME e tenta resolver recursivamente
        for answer in data.get("Answer", []):
            if answer.get("type") == 5:  # CNAME record
                cname = answer.get("data", "").rstrip('.')
                if cname:
                    debug(f"[DOH] Encontrado CNAME {cname} para {hostname}, resolvendo recursivamente")
                    return self.resolve(cname)

        return None

    def _get_ttl_from_response(self, data: dict) -> Optional[int]:
        """Extrai o TTL da resposta DoH"""
        for answer in data.get("Answer", []):
            if "TTL" in answer:
                return answer["TTL"]
        return None

    def _is_valid_ip(self, address: str) -> bool:
        """Verifica se o endereço já é um IP válido"""
        try:
            socket.inet_aton(address)
            return True
        except socket.error:
            return False

# Cria o resolvedor DoH com fallback entre múltiplos servidores
doh_resolver = DoHResolver(DOH_RESOLVERS, cache_ttl=DOH_CACHE_TTL, retries=DOH_RETRIES)

# --- Monitor de Banda Larga Inteligente ---
class BandwidthMonitor:
    def __init__(self, window_size: int = BANDWIDTH_MONITOR_WINDOW):
        self.window_size = window_size
        self.samples = []
        self.timestamps = []
        
    def add_sample(self, bytes_transferred: int):
        """Adiciona uma amostra de transferência"""
        now = time.time()
        self.samples.append(bytes_transferred)
        self.timestamps.append(now)
        
        # Manter apenas as amostras mais recentes dentro da janela
        if len(self.samples) > self.window_size:
            self.samples.pop(0)
            self.timestamps.pop(0)
    
    def get_bandwidth(self) -> float:
        """Calcula a banda disponível em bps"""
        if len(self.samples) < 2:
            return 0
            
        total_bytes = sum(self.samples)
        time_span = self.timestamps[-1] - self.timestamps[0]
        
        if time_span <= 0:
            return 0
            
        return (total_bytes * 8) / time_span  # bits por segundo

# --- Cache Inteligente para Manifestos e Segmentos ---
class StreamCache:
    def __init__(self, max_size: int = MAX_CACHE_SIZE):
        self.max_size = max_size
        self.manifest_cache = {}
        self.segment_cache = {}
        self.access_times = {}
        self.current_size = 0
        
    def get_manifest(self, url: str) -> Optional[str]:
        """Obtém um manifesto do cache se existir e não estiver expirado"""
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            self.access_times[url] = time.time()
            return entry['content']
        return None
        
    def add_manifest(self, url: str, content: str, ttl: int = 10):
        """Adiciona um manifesto ao cache com TTL"""
        if len(self.manifest_cache) >= self.max_size:
            self._evict_oldest()
            
        self.manifest_cache[url] = {
            'content': content,
            'expires': time.time() + ttl
        }
        self.access_times[url] = time.time()
        
    def get_segment(self, url: str) -> Optional[bytes]:
        """Obtém um segmento do cache"""
        if url in self.segment_cache:
            self.access_times[url] = time.time()
            return self.segment_cache[url]
        return None
        
    def add_segment(self, url: str, data: bytes):
        """Adiciona um segmento ao cache"""
        if len(self.segment_cache) >= self.max_size:
            self._evict_oldest()
            
        self.segment_cache[url] = data
        self.access_times[url] = time.time()
        self.current_size += len(data)
        
    def _evict_oldest(self):
        """Remove os itens mais antigos do cache"""
        if not self.access_times:
            return
            
        oldest_url = min(self.access_times, key=self.access_times.get)
        if oldest_url in self.manifest_cache:
            del self.manifest_cache[oldest_url]
        if oldest_url in self.segment_cache:
            self.current_size -= len(self.segment_cache[oldest_url])
            del self.segment_cache[oldest_url]
        del self.access_times[oldest_url]

# --- Manipulador de Proxy Avançado ---
class AdvancedHLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.cache = StreamCache()
        self.bw_monitor = BandwidthMonitor()
        self.adaptive_streaming = ADAPTIVE_STREAMING
        super().__init__(*args, **kwargs)
    
    def log_message(self, format, *args):
        """Suprime logs padrão do HTTP server"""
        pass
    
    def do_GET(self):
        """Manipula requisições GET com tratamento avançado"""
        start_time = time.time()
        try:
            parsed_path = urllib.parse.urlparse(self.path)
            original_url = urllib.parse.unquote_plus(parsed_path.path.lstrip('/'))
            
            debug(f"Requisição recebida para: {original_url}")
            
            if ".m3u8" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
                
        except Exception as e:
            error(f"Erro ao processar requisição: {e}")
            self.send_error(500, f"Internal Server Error: {str(e)}")
        finally:
            debug(f"Tempo de processamento: {(time.time() - start_time):.2f}s")
    
    def _handle_manifest(self, url: str):
        """Processa manifestos M3U8 com reescrita inteligente de URLs"""
        cached = self.cache.get_manifest(url)
        if cached:
            debug(f"Retornando manifesto do cache: {url}")
            self._send_response(200, cached, 'application/vnd.apple.mpegurl')
            return
            
        try:
            response = self._fetch_url(url, stream=False)
            if not response:
                self.send_error(502, "Bad Gateway")
                return
                
            parsed_m3u8 = m3u8.loads(response.text, uri=url)
            
            # Ajuste dinâmico de qualidade baseado na banda disponível
            if self.adaptive_streaming and parsed_m3u8.playlists:
                bandwidth = self.bw_monitor.get_bandwidth()
                if bandwidth > 0:
                    self._adjust_quality(parsed_m3u8, bandwidth)
            
            # Reescreve URLs para apontar para o proxy
            actual_port = self.server.server_address[1]
            base_proxy_url = f"http://{PROXY_HOST}:{actual_port}/"
            
            for playlist in parsed_m3u8.playlists:
                playlist.uri = base_proxy_url + urllib.parse.quote_plus(playlist.absolute_uri)
                
            for segment in parsed_m3u8.segments:
                segment.uri = base_proxy_url + urllib.parse.quote_plus(segment.absolute_uri)
                
            rewritten = parsed_m3u8.dumps()
            self.cache.add_manifest(url, rewritten)
            
            self._send_response(200, rewritten, 'application/vnd.apple.mpegurl')
            
        except Exception as e:
            error(f"Erro ao processar manifesto: {url} - {e}")
            self.send_error(500, f"Internal Proxy Error: {str(e)}")
    
    def _handle_segment(self, url: str):
        """Processa segmentos de mídia com cache e monitoramento de banda"""
        cached = self.cache.get_segment(url)
        if cached:
            debug(f"Retornando segmento do cache: {url}")
            self._send_response(200, cached, 'video/MP2T')
            return
            
        try:
            response = self._fetch_url(url, stream=True)
            if not response:
                self.send_error(502, "Bad Gateway")
                return
                
            content_length = int(response.headers.get('Content-Length', 0))
            data = bytearray()
            
            self.send_response(200)
            self._copy_headers(response)
            self.end_headers()
            
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    break
                data.extend(chunk)
                self.wfile.write(chunk)
                
            # Atualiza monitor de banda e cache
            if content_length > 0 or data:
                actual_size = len(data) if data else content_length
                self.bw_monitor.add_sample(actual_size)
                
                if data and actual_size <= 5 * 1024 * 1024:  # Cache até 5MB
                    self.cache.add_segment(url, bytes(data))
                    
        except Exception as e:
            error(f"Erro ao processar segmento: {url} - {e}")
            self.send_error(500, f"Internal Proxy Error: {str(e)}")
    
    def _adjust_quality(self, m3u8_obj: m3u8.M3U8, bandwidth: float):
        """Seleciona a melhor qualidade baseado na banda disponível"""
        available_bandwidth = min(max(bandwidth, MIN_BITRATE), MAX_BITRATE)
        debug(f"Banda disponível: {available_bandwidth/1e6:.2f} Mbps")
        
        best_playlist = None
        closest_diff = float('inf')
        
        for playlist in m3u8_obj.playlists:
            playlist_bandwidth = playlist.stream_info.bandwidth
            diff = abs(playlist_bandwidth - available_bandwidth)
            
            # Prioriza playlists que estão dentro da banda disponível ou ligeiramente acima (1.2x)
            if playlist_bandwidth <= available_bandwidth * 1.2:
                if best_playlist is None or diff < closest_diff:
                    closest_diff = diff
                    best_playlist = playlist
                
        if best_playlist:
            # Reordena playlists para colocar a melhor opção primeiro
            m3u8_obj.playlists.sort(
                key=lambda p: abs(p.stream_info.bandwidth - best_playlist.stream_info.bandwidth)
            )
            info(f"Qualidade ajustada para: {best_playlist.stream_info.bandwidth/1e6:.2f} Mbps")
    
    def _fetch_url(self, url: str, stream: bool = False) -> Optional[requests.Response]:
        """Busca uma URL com tratamento de erros robusto e resolução DoH"""
        try:
            parsed_original_url = urllib.parse.urlparse(url)
            headers = HTTP_SESSION.headers.copy()
            headers['Referer'] = f"{parsed_original_url.scheme}://{parsed_original_url.netloc}"

            # Usando o resolvedor DoH aprimorado
            resolved_ip = doh_resolver.resolve(parsed_original_url.hostname)
            if resolved_ip:
                # Se o hostname foi resolvido, substitui na URL para a requisição direta ao IP
                # e mantém o cabeçalho 'Host' original para o servidor de destino.
                alt_url = url.replace(parsed_original_url.hostname, resolved_ip)
                headers['Host'] = parsed_original_url.hostname 
                debug(f"[FETCH] Resolvido {parsed_original_url.hostname} para {resolved_ip}. Buscando de {alt_url}")
                response = HTTP_SESSION.get(
                    alt_url,
                    stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers
                )
            else:
                # Se não foi resolvido ou não precisa, usa a URL original
                debug(f"[FETCH] Não foi possível resolver {parsed_original_url.hostname} via DoH ou não necessário. Buscando de {url}")
                response = HTTP_SESSION.get(
                    url,
                    stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers 
                )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            error(f"[FETCH] Erro ao buscar URL {url}: {e}")
            return None
    
    def _send_response(self, code: int, content: str, content_type: str):
        """Envia uma resposta HTTP com headers apropriados"""
        encoded = content.encode('utf-8') if isinstance(content, str) else content
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(encoded)))
        self.send_header('Cache-Control', 'max-age=10')
        self.end_headers()
        self.wfile.write(encoded)
    
    def _copy_headers(self, response: requests.Response):
        """Copia headers da resposta original, filtrando os problemáticos"""
        for header, value in response.headers.items():
            header_lower = header.lower()
            if header_lower not in {'transfer-encoding', 'connection', 'content-encoding'}:
                self.send_header(header, value)

# --- Gerenciador de Proxy Avançado ---
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.ready_event = threading.Event()
        self.active_port = None
        
    def start(self) -> Optional[int]:
        """Inicia o servidor proxy em uma porta disponível"""
        global DEFAULT_PROXY_PORT
        
        self.stop()  # Garante que não há servidores ativos
        
        for attempt in range(MAX_PORT_ATTEMPTS):
            port_to_try = DEFAULT_PROXY_PORT if attempt == 0 else 0
            server_address = (PROXY_HOST, port_to_try)
            
            try:
                self.server = socketserver.TCPServer(
                    server_address,
                    AdvancedHLSProxyHandler,
                    bind_and_activate=False
                )
                self.server.allow_reuse_address = True
                self.server.server_bind()
                self.server.server_activate()
                
                self.active_port = self.server.server_address[1]
                info(f"Servidor proxy iniciado em http://{PROXY_HOST}:{self.active_port}")
                
                self.server_thread = threading.Thread(
                    target=self.server.serve_forever,
                    daemon=True
                )
                self.server_thread.start()
                
                self.ready_event.set()
                return self.active_port
                
            except OSError as e:
                if "Address already in use" in str(e):
                    warning(f"Porta {port_to_try} em uso, tentando outra...")
                    if port_to_try == DEFAULT_PROXY_PORT and DEFAULT_PROXY_PORT != 0:
                        DEFAULT_PROXY_PORT = 0
                    continue
                error(f"Erro ao iniciar servidor proxy: {e}")
                break
            except Exception as e:
                error(f"Erro inesperado ao iniciar proxy: {e}")
                break
                
        self.ready_event.set()
        return None
    
    def stop(self):
        """Para o servidor proxy e limpa recursos"""
        if self.server:
            info("Parando servidor proxy...")
            try:
                self.server.shutdown()
                self.server.server_close()
                info("Servidor proxy parado.")
            except Exception as e:
                error(f"Erro ao parar o servidor proxy: {e}")
            finally:
                self.server = None
            
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=5)
            if self.server_thread.is_alive():
                warning("Thread do proxy não finalizou a tempo")
                
        self.active_port = None
        self.ready_event.clear()
    
    def get_proxy_url(self, original_url: str) -> Optional[str]:
        """Gera a URL do proxy para a URL original"""
        if not self.active_port:
            return None
        return f"http://{PROXY_HOST}:{self.active_port}/{urllib.parse.quote_plus(original_url)}"
    
    def wait_until_ready(self, timeout: float = 15) -> bool:
        """Aguarda até que o proxy esteja pronto"""
        return self.ready_event.wait(timeout)

# --- Interface do Addon ---
class HLSProxyAddon:
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.player = xbmc.Player()
        self.playback_monitor_thread = None
    
    def play_stream(self, url: str):
        """Prepara e inicia a reprodução de um stream HLS ou MP2T"""
        info(f"Iniciando reprodução para: {url}")
        
        # Inicia o proxy
        port = self.proxy_manager.start()
        if not port:
            xbmcgui.Dialog().notification(ADDON_NAME, "Falha ao iniciar proxy", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
            
        # Aguarda o proxy ficar pronto
        if not self.proxy_manager.wait_until_ready():
            xbmcgui.Dialog().notification(ADDON_NAME, "Proxy não iniciou a tempo", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            self.proxy_manager.stop()
            return
            
        # Prepara o item para reprodução
        proxy_url = self.proxy_manager.get_proxy_url(url)
        if not proxy_url:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            self.proxy_manager.stop()
            return

        list_item = xbmcgui.ListItem(path=proxy_url)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')

        # Define tipo HLS ou MP2T e propriedades específicas
        parsed_original_url = urllib.parse.urlparse(url)
        headers = f"Referer={parsed_original_url.scheme}://{parsed_original_url.netloc}"

        if '.m3u8' in url.lower():
            list_item.setContentLookup(False)
            list_item.setMimeType('application/vnd.apple.mpegurl')
            list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'application/vnd.apple.mpegurl')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
            list_item.setProperty('inputstream.ffmpegdirect.stream_headers', headers)
            list_item.setProperty('inputstream.ffmpegdirect.hls_segment_duration_limit', '60')
            list_item.setProperty('inputstream.ffmpegdirect.hls_min_buffer_duration', '3')
            list_item.setProperty('inputstream.ffmpegdirect.hls_max_bitrate', str(MAX_BITRATE))
            list_item.setProperty('inputstream.ffmpegdirect.hls_allow_partial_segments', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_update_parameter', 'full')

            # Timeshift/Catchup para HLS
            list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
            list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
            list_item.setProperty('inputstream.ffmpegdirect.is_catchup_stream', 'catchup')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_granularity', '60')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_terminates', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.default_url', url)
            list_item.setProperty('inputstream.ffmpegdirect.catchup_url_format_string', url)
            list_item.setProperty('inputstream.ffmpegdirect.programme_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.programme_end_time', '19')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_offset', '1')
            list_item.setProperty('inputstream.ffmpegdirect.default_programme_duration', '19')

        else:
            # MP2T Direto (sem manifesto)
            list_item.setContentLookup(False)
            list_item.setMimeType('video/mp2t')
            list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp2t')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'none')
            list_item.setProperty('inputstream.ffmpegdirect.stream_headers', headers)
            list_item.setProperty('inputstream.ffmpegdirect.http_connect_timeout', str(CONNECTION_TIMEOUT))
            list_item.setProperty('inputstream.ffmpegdirect.http_read_timeout', str(STREAM_TIMEOUT))
            list_item.setProperty('inputstream.ffmpegdirect.reconnect_on_error', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.live_threshold', '5')
            list_item.setProperty('inputstream.ffmpegdirect.fast_seek', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.seek_method', 'byte')
            list_item.setProperty('inputstream.ffmpegdirect.chunk_size', str(CHUNK_SIZE))
            list_item.setProperty('inputstream.ffmpegdirect.low_delay', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.readrate_start', '1.0')
            list_item.setProperty('inputstream.ffmpegdirect.readrate_max', '2.0')
            list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'catchup')
            list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.is_catchup_stream', 'catchup')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_granularity', '60')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_terminates', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.default_url', url)
            list_item.setProperty('inputstream.ffmpegdirect.catchup_url_format_string', url)
            list_item.setProperty('inputstream.ffmpegdirect.programme_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.programme_end_time', '19')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_offset', '1')
            list_item.setProperty('inputstream.ffmpegdirect.default_programme_duration', '19')

        list_item.setProperty('ForceResolvePlugin','false')
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        
        self._start_playback_monitor()
        
        if self.playback_monitor_thread:
            self.playback_monitor_thread.join()
            info("Monitor de reprodução finalizado.")
        else:
            warning("Monitor de reprodução não foi iniciado corretamente.")

    def _start_playback_monitor(self):
        """Inicia uma thread para monitorar a reprodução e limpar o proxy quando terminar"""
        if self.playback_monitor_thread and self.playback_monitor_thread.is_alive():
            return

        def monitor():
            info("Iniciando monitor de reprodução...")
            
            # Aguarda até 45 segundos para a reprodução começar
            start_time = time.time()
            is_playing_after_wait = False
            while time.time() - start_time < 45:
                if self.player.isPlaying():
                    is_playing_after_wait = True
                    break
                time.sleep(0.5)
            
            if not is_playing_after_wait:
                warning("Reprodução não iniciada dentro do tempo limite ou falha do player. Parando proxy.")
                self.proxy_manager.stop()
                return
            
            info("Reprodução iniciada. Monitorando...")
            # Monitora enquanto estiver reproduzindo
            while self.player.isPlaying():
                time.sleep(1)
                
            info("Reprodução terminada ou parada. Parando proxy...")
            self.proxy_manager.stop()
            
        self.playback_monitor_thread = threading.Thread(target=monitor, daemon=True)
        self.playback_monitor_thread.start()
    
    def show_test_streams(self):
        """Mostra uma lista de streams de teste para demonstração"""
        test_streams = [
            ("Live Stream Exemplo 1 (M3U8)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Live Stream Exemplo 2 (MP2T)", "http://tvhdbalck.pro:80/live/6464779/0577073/329.ts"),
            ("VOD Apple Sample (Estável M3U8)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8"),
            ("Big Buck Bunny (Demo M3U8)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8")
        ]
        
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=name)
            li.setProperty('IsPlayable', 'true')
            li.setInfo('video', {'title': name})
            
            # Set initial MIME type based on URL extension
            if '.m3u8' in url.lower():
                li.setMimeType('application/vnd.apple.mpegurl')
            elif '.ts' in url.lower():
                li.setMimeType('video/mp2t')
            else:
                li.setMimeType('video/x-mpegurl')
            
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
            
        xbmcplugin.endOfDirectory(HANDLE)

# --- Ponto de Entrada do Addon ---
if __name__ == '__main__':
    addon_instance = HLSProxyAddon()
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url = params.get('url')

    if action == 'play' and url:
        info(f"Ação 'play' recebida para URL: {url}")
        addon_instance.play_stream(url)
    else:
        info("Exibindo lista de streams de teste.")
        addon_instance.show_test_streams()