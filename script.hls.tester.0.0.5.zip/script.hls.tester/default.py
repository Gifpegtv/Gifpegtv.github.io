# -*- coding: utf-8 -*-

# ==============================================================================
# MÓDULOS PADRÃO E DE TERCEIROS
# ==============================================================================
import sys
import os
import threading
import time
import random
import logging
import logging.handlers
import queue
import urllib.parse
from collections import OrderedDict, deque
from typing import Optional, Dict, Any, List, Tuple, Union

# ==============================================================================
# MÓDULOS KODI
# ==============================================================================
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin

# ==============================================================================
# MÓDULOS DO PROXY (INCLUINDO FLASK)
# ==============================================================================
import requests
import m3u8
import ipaddress
from werkzeug.serving import make_server

# Tenta importar o Flask.
try:
    from flask import Flask, request, Response, make_response, stream_with_context
except ImportError:
    xbmcgui.Dialog().ok("Erro de Dependência", "O addon 'script.module.flask' não foi encontrado. Por favor, instale-o para que o HLS Tester funcione.")
    sys.exit(1)

# ==============================================================================
# MÓDULO DE DESBLOQUEIO DE REDE (DoH)
# ==============================================================================
try:
    from doh import DNSOverrideDoH
    doh_resolver = DNSOverrideDoH()
    logging.info("Módulo netunblock (DoH) carregado e inicializado com sucesso.")
except ImportError:
    logging.warning("Módulo netunblock (DoH) não encontrado. Usando resolução DNS padrão.")
    doh_resolver = None
except Exception as e:
    logging.error(f"Erro ao inicializar o módulo netunblock (DoH): {e}")
    doh_resolver = None

# ==============================================================================
# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO (AJUSTADO PARA TV BOX) ---
# ==============================================================================
MAX_CONSECUTIVE_SEGMENT_FAILURES = 5  # Aumentado para maior tolerância a falhas
FETCHER_MAX_RETRIES = 4  # Aumentado para melhor recuperação
RETRY_BACKOFF_FACTOR = 0.3  # Reduzido para reconexão mais rápida
CONNECTION_TIMEOUT = 8.0  # Reduzido para resposta mais rápida
STREAM_TIMEOUT = 15.0  # Reduzido para evitar longas esperas
DEFAULT_CHUNK_SIZE = 256 * 1024  # Reduzido para 256KB para melhor fluxo
MAX_STREAM_LIFETIME_SECONDS = 15  # Aumentado para reduzir recargas frequentes
MAX_CACHE_MB = 64  # Aumentado para 64MB para melhor buffer
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
MAX_SEGMENT_SIZE_MB = 15  # Aumentado para 15MB
MAX_SEGMENT_SIZE_BYTES = MAX_SEGMENT_SIZE_MB * 1024 * 1024
PREFETCH_SEGMENTS_COUNT = 4  # Aumentado para melhor pré-carregamento
MAX_PREFETCH_SEGMENTS = 8  # Aumentado para melhor pré-carregamento
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 15  # Aumentado para mais tentativas de porta
LIMIT_COOLDOWN_SECONDS = 10  # Reduzido para recuperação mais rápida
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Kodi/20.0 (Windows NT 10.0; Win64; x64) App/1.0"
]
LOG_MAX_BYTES = 1048576 * 5  # Mantido em 5MB
LOG_BACKUP_COUNT = 2  # Aumentado para mais logs de histórico
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy_flask.log')
LOG_LEVEL = logging.INFO

# Configurações avançadas para reconexão inteligente
ADAPTIVE_BACKOFF_ENABLED = True  # Habilitado para melhor recuperação
MAX_BACKOFF_TIME = 20  # Reduzido para reconexão mais rápida
HEALTH_CHECK_INTERVAL = 8  # Reduzido para verificação mais frequente
MANIFEST_REFRESH_THRESHOLD = 0.7  # Ajustado para atualização mais antecipada

# Configurações de buffer adaptativo
MIN_BUFFER_SEGMENTS = 4  # Aumentado para mais estabilidade
MAX_BUFFER_SEGMENTS = 10  # Aumentado para melhor buffer
TARGET_BUFFER_DURATION = 12  # Aumentado para melhor experiência

# Configurações de buffer de reprodução contínua
MIN_BUFFER_SECONDS = 8  # Aumentado para mais estabilidade
MAX_BUFFER_SECONDS = 30  # Aumentado para melhor buffer

# Configurações de recuperação inteligente
SMART_RECOVERY_ENABLED = True
BUFFER_LOW_THRESHOLD = 3  # Segmentos
BUFFER_CRITICAL_THRESHOLD = 1  # Segmentos
RECOVERY_ATTEMPTS_BEFORE_RESET = 3

# Configurações de qualidade adaptativa
ADAPTIVE_QUALITY_ENABLED = True
QUALITY_DEGRADATION_THRESHOLD = 5  # Falhas consecutivas
MIN_QUALITY_INDEX = 0  # Qualidade mais baixa disponível

_SENSITIVE_HEADERS = {'X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                       'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP',
                      'Content-Length', 'Connection', 'Transfer-Encoding'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}


# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# ==============================================================================

def setup_logging():
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT, encoding='utf-8'
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s',
        force=True
    )

def is_valid_ip(address: str) -> bool:
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "*/*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": origin,
        "X-Forwarded-For": "1.1.1.1"
    }

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith(('.m3u8', '.m3u')):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.aac'):
        return 'audio/aac'
    if path.endswith('.mp4'):
        return 'video/mp4'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content:
        return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u":
        return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections",
               "max session", "#error", "offline", "geoblocked", "stream not found",
                "access denied", "blocked", "forbidden", "unavailable", "invalid",
                "authentication failed", "unauthorized", "bad request", "service unavailable"]
    return any(keyword in txt for keyword in keywords)

def calculate_backoff(attempt: int) -> float:
    if not ADAPTIVE_BACKOFF_ENABLED:
        return RETRY_BACKOFF_FACTOR
    
    # Backoff exponencial com jitter adaptativo
    base_backoff = RETRY_BACKOFF_FACTOR * (2 ** min(attempt, 5))  # Limitar expoente
    backoff = min(base_backoff, MAX_BACKOFF_TIME)
    
    # Jitter adaptativo - menor jitter em tentativas iniciais
    jitter_factor = 0.1 + (0.4 * min(attempt / 5, 1.0))
    jitter = random.uniform(-jitter_factor, jitter_factor) * backoff
    
    return max(0.1, backoff + jitter)  # Garantir mínimo de 0.1s


# ==============================================================================
# --- CLASSES DE CACHE E REDE ---
# ==============================================================================

class RotatingChunkCache:
    """
    Cache de blocos rotativo otimizado para LRU (Least Recently Used) simplificado.
    """
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.chunks: OrderedDict[str, bytes] = OrderedDict()
        self.total_bytes = 0
        self.access_times: Dict[str, float] = {}
        self.hit_count: Dict[str, int] = {}
        self.continuous_buffer = bytearray()
        self.buffer_lock = threading.Lock()
        self.eviction_count = 0
        self.hits = 0
        self.misses = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            data = self.chunks.get(url)
            if data:
                self.chunks.move_to_end(url)
                self.access_times[url] = time.time()
                self.hit_count[url] = self.hit_count.get(url, 0) + 1
                self.hits += 1
                logging.debug(f"[Cache] Hit para {url}")
            else:
                self.misses += 1
            return data

    def add(self, url: str, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))
        
            chunk_size = len(data)
            if chunk_size > self.max_bytes:
                return
                
            self.chunks[url] = data
            self.total_bytes += chunk_size
            self.access_times[url] = time.time()
            self.hit_count[url] = self.hit_count.get(url, 0) + 1
            
            with self.buffer_lock:
                self.continuous_buffer.extend(data)
                # Limita o tamanho do buffer com margem de segurança
                max_buffer_size = MAX_BUFFER_SECONDS * 1024 * 1024
                if len(self.continuous_buffer) > max_buffer_size:
                    excess = len(self.continuous_buffer) - max_buffer_size
                    del self.continuous_buffer[:excess]

            self._manage_cache_size()

    def _manage_cache_size(self):
        evicted = 0
        while self.total_bytes > self.max_bytes and len(self.chunks) > 1:
            oldest_key = next(iter(self.chunks))
            old_data = self.chunks.pop(oldest_key)
            self.total_bytes -= len(old_data)
            self.access_times.pop(oldest_key, None)
            self.hit_count.pop(oldest_key, None)
            evicted += 1
        
        if evicted > 0:
            self.eviction_count += evicted
            logging.debug(f"[Cache] Removidos {evicted} itens do LRU. Total: {self.total_bytes / (1024*1024):.2f}MB")

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.total_bytes = 0
            self.access_times.clear()
            self.hit_count.clear()
        with self.buffer_lock:
            self.continuous_buffer.clear()
        logging.info("[RECONEXÃO] Cache de segmentos de vídeo limpo.")

    def has(self, url: str) -> bool:
        with self.lock:
            return url in self.chunks

    def get_stats(self) -> Dict[str, Any]:
        with self.lock:
            hit_rate = self.hits / (self.hits + self.misses) if (self.hits + self.misses) > 0 else 0
            return {
                'total_bytes': self.total_bytes,
                'total_items': len(self.chunks),
                'max_bytes': self.max_bytes,
                'usage_percent': (self.total_bytes / self.max_bytes) * 100 if self.max_bytes > 0 else 0,
                'hit_rate': hit_rate * 100,
                'eviction_count': self.eviction_count,
                'hits': self.hits,
                'misses': self.misses
            }

    def get_continuous_stream(self, chunk_size: int = DEFAULT_CHUNK_SIZE) -> bytes:
        with self.buffer_lock:
            if len(self.continuous_buffer) < chunk_size:
                return b''
            
            chunk = bytes(self.continuous_buffer[:chunk_size])
            del self.continuous_buffer[:chunk_size]
            return chunk

    def buffer_size(self) -> int:
        with self.buffer_lock:
            return len(self.continuous_buffer)

    def get_least_recent_items(self, count: int = 5) -> List[Tuple[str, float]]:
        """Retorna os itens menos recentemente acessados para análise."""
        with self.lock:
            items = list(self.access_times.items())
            items.sort(key=lambda x: x[1])  # Ordenar por tempo de acesso
            return items[:count]

class StreamCache:
    def __init__(self, chunk_cache: RotatingChunkCache):
        self.manifest_cache: Dict[str, Dict[str, Any]] = {}
        self.chunk_cache = chunk_cache
        self.lock = threading.Lock()
        self.last_manifest_refresh: Dict[str, float] = {}
        self.manifest_access_count: Dict[str, int] = {}

    def get_manifest(self, url: str) -> Optional[str]:
        with self.lock:
            entry = self.manifest_cache.get(url)
            if entry and time.time() < entry['expires']:
                self.manifest_access_count[url] = self.manifest_access_count.get(url, 0) + 1
                return entry['content']
            return None

    def add_manifest(self, url: str, content: str, ttl: int):
        with self.lock:
            now = time.time()
            self.manifest_cache[url] = {
                'content': content, 
                'expires': now + ttl, 
                'last_refresh_time': now
            }
            self.last_manifest_refresh[url] = now
            self.manifest_access_count[url] = self.manifest_access_count.get(url, 0) + 1

    def is_manifest_expired(self, url: str) -> bool:
        with self.lock:
            entry = self.manifest_cache.get(url)
            if not entry:
                return True
            
            # Lógica de expiração adaptativa com base no acesso
            access_count = self.manifest_access_count.get(url, 0)
            time_since_refresh = time.time() - entry.get('last_refresh_time', 0)
            
            # Manifestos acessados com frequência têm TTL mais longo
            adjusted_ttl = MAX_STREAM_LIFETIME_SECONDS * (1 + min(access_count * 0.2, 2))
            
            return time_since_refresh >= adjusted_ttl

    def get_segment(self, url: str) -> Optional[bytes]:
        return self.chunk_cache.get(url)

    def add_segment(self, url: str, data: bytes):
        self.chunk_cache.add(url, data)

    def has_segment(self, url: str) -> bool:
        return self.chunk_cache.has(url)

    def get_continuous_stream(self, chunk_size: int = DEFAULT_CHUNK_SIZE) -> bytes:
        return self.chunk_cache.get_continuous_stream(chunk_size)

    def buffer_size(self) -> int:
        return self.chunk_cache.buffer_size()

    def clear(self):
        with self.lock:
            self.manifest_cache.clear()
            self.last_manifest_refresh.clear()
            self.manifest_access_count.clear()
        self.chunk_cache.clear()

    def get_manifest_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas sobre o cache de manifestos."""
        with self.lock:
            return {
                'manifest_count': len(self.manifest_cache),
                'access_counts': self.manifest_access_count.copy()
            }

class UpstreamFetcher:
    def __init__(self, session: requests.Session):
        self.session = session
        self.last_failure_time: Dict[str, float] = {}
        self.failure_count: Dict[str, int] = {}
        self.success_count: Dict[str, int] = {}
        self.response_times: Dict[str, List[float]] = {}
        self.lock = threading.Lock()

    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        headers = get_player_headers(url)
        if original_headers:
            cleaned_original = clean_headers(original_headers)
            headers.update({k: v for k, v in cleaned_original.items() if k in ['Authorization', 'Cookie']})

        domain = urllib.parse.urlparse(url).netloc
        
        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                start_time = time.time()
                resp = self.session.get(
                    url, stream=stream, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                response_time = time.time() - start_time
                
                with self.lock:
                    # Registrar tempo de resposta
                    if domain not in self.response_times:
                        self.response_times[domain] = []
                    self.response_times[domain].append(response_time)
                    
                    # Manter apenas os últimos 10 tempos de resposta
                    if len(self.response_times[domain]) > 10:
                        self.response_times[domain] = self.response_times[domain][-10:]
                    
                    # Atualizar contadores
                    self.success_count[domain] = self.success_count.get(domain, 0) + 1
                    
                    # Resetar contadores de falha em caso de sucesso
                    if domain in self.failure_count:
                        del self.failure_count[domain]
                        del self.last_failure_time[domain]
                
                resp.raise_for_status()
                return resp
            except requests.RequestException as e:
                logging.warning(f"[Fetcher] Tentativa {attempt + 1} falhou para {url}: {e}")
                
                with self.lock:
                    self.failure_count[domain] = self.failure_count.get(domain, 0) + 1
                    self.last_failure_time[domain] = time.time()
                
                if attempt < FETCHER_MAX_RETRIES:
                    backoff = calculate_backoff(attempt)
                    logging.info(f"[Fetcher] Aguardando {backoff:.2f}s antes da próxima tentativa")
                    time.sleep(backoff)
                else:
                    raise

    def get_domain_stats(self, domain: str) -> Dict[str, Any]:
        """Retorna estatísticas sobre um domínio específico."""
        with self.lock:
            response_times = self.response_times.get(domain, [])
            avg_response_time = sum(response_times) / len(response_times) if response_times else 0
            return {
                'failure_count': self.failure_count.get(domain, 0),
                'success_count': self.success_count.get(domain, 0),
                'avg_response_time': avg_response_time,
                'last_failure': self.last_failure_time.get(domain, 0)
            }

class ManifestRewriter:
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        self.original_manifest_url = manifest_url

    def rewrite(self) -> str:
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri and not item.key.uri.startswith("data:"):
                item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self) -> int:
        target_duration = getattr(self.m3u8_obj, 'target_duration', 10)
        
        # TTL adaptativo com base no tipo de stream
        if self.is_live:
            # Para streams ao vivo, usar uma fração do target_duration
            return max(2, int(target_duration * 0.5))
        else:
            # Para VOD, usar TTL mais longo
            return max(60, int(target_duration * 3))
    
    def get_segment_durations(self) -> List[float]:
        durations = []
        for segment in getattr(self.m3u8_obj, 'segments', []):
            duration = getattr(segment, 'duration', 0)
            if duration > 0:
                durations.append(duration)
        return durations
    
    def get_total_duration(self) -> float:
        durations = self.get_segment_durations()
        return sum(durations) if durations else 0
    
    def get_bandwidth_info(self) -> List[Dict[str, Any]]:
        """Retorna informações sobre as faixas de largura de banda disponíveis."""
        playlists = getattr(self.m3u8_obj, 'playlists', [])
        bandwidth_info = []
        
        for playlist in playlists:
            if hasattr(playlist, 'stream_info') and playlist.stream_info:
                bandwidth = playlist.stream_info.bandwidth
                resolution = playlist.stream_info.resolution
                codecs = playlist.stream_info.codecs
                
                bandwidth_info.append({
                    'bandwidth': bandwidth,
                    'resolution': resolution,
                    'codecs': codecs,
                    'uri': playlist.uri
                })
        
        # Ordenar por largura de banda (da menor para a maior)
        bandwidth_info.sort(key=lambda x: x['bandwidth'])
        return bandwidth_info


# ==============================================================================
# --- CLASSE PRINCIPAL DE GERENCIAMENTO DO PROXY ---
# ==============================================================================

class HLSProxyManager:
    def __init__(self):
        self.server: Optional[make_server] = None
        self.server_thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None
        
        self.chunk_cache = RotatingChunkCache()
        self.stream_cache = StreamCache(self.chunk_cache)
        
        self._http_session: requests.Session = self._create_http_session()
        self.fetcher = UpstreamFetcher(self._http_session)
        
        self._failure_lock = threading.Lock()
        self._consecutive_failures = 0
        self._limit_hits: Dict[str, float] = {}
        
        self._segment_prefetch_queue = queue.Queue(maxsize=MAX_PREFETCH_SEGMENTS * 2)
        self._prefetch_thread: Optional[threading.Thread] = None
        self._prefetch_stop_event = threading.Event()
        
        self._health_check_thread: Optional[threading.Thread] = None
        self._health_check_stop_event = threading.Event()
        self._last_successful_segment_time: Dict[str, float] = {}
        self._current_manifest_url: Optional[str] = None
        self._current_bandwidth_index: Optional[int] = None  # Para qualidade adaptativa
        
        self._recovery_attempts: Dict[str, int] = {}
        self._recovery_lock = threading.Lock()
        
        self.app = self._create_flask_app()

    def _create_http_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({'User-Agent': random.choice(USER_AGENTS), 'Connection': 'keep-alive'})
        session.trust_env = False
        
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        
        retry_strategy = Retry(
            total=FETCHER_MAX_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[500, 502, 503, 504, 408, 429]  # Adicionados mais códigos de erro
        )
        
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=8,  # Aumentado para melhor concorrência
            pool_maxsize=8,      # Aumentado para melhor concorrência
            pool_block=False
        )
        
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session

    def reset_http_session(self):
        logging.info("[RECONEXÃO] Recriando sessão HTTP.")
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher = UpstreamFetcher(self._http_session)
        with self._segment_prefetch_queue.mutex:
            self._segment_prefetch_queue.queue.clear()

    def force_reconnection(self, url: str):
        logging.info(f"[RECONEXÃO] Forçando reconexão para URL base: {url}")
        self.stream_cache.clear()
        self.reset_http_session()
        
        with self._failure_lock:
            self._consecutive_failures = 0
        
        with self._recovery_lock:
            self._recovery_attempts.clear()
        
        self._limit_hits.clear()
        self._last_successful_segment_time.clear()
        self._current_bandwidth_index = None

    def increment_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures += 1
            logging.debug(f"Contador de falhas: {self._consecutive_failures}")

    def reset_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures = 0

    def should_force_reconnect(self) -> bool:
        with self._failure_lock:
            return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES

    def record_limit_hit(self, url: str):
        self._limit_hits[url] = time.time()

    def is_in_cooldown(self, url: str) -> bool:
        hit_time = self._limit_hits.get(url)
        return hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS

    def clear_limit_hit(self, url: str):
        if url in self._limit_hits:
            del self._limit_hits[url]

    def record_successful_segment(self, url: str):
        self._last_successful_segment_time[url] = time.time()
        self.reset_failure_count()
        
        # Resetar tentativas de recuperação para este segmento
        with self._recovery_lock:
            if url in self._recovery_attempts:
                del self._recovery_attempts[url]

    def queue_segment_for_prefetch(self, segment_url: str):
        try:
            self._segment_prefetch_queue.put_nowait(segment_url)
        except queue.Full:
            logging.warning("Fila de pré-busca cheia.")

    def _prefetch_worker(self):
        while not self._prefetch_stop_event.is_set():
            try:
                segment_url = self._segment_prefetch_queue.get(timeout=1)
                if self.stream_cache.has_segment(segment_url):
                    self._segment_prefetch_queue.task_done()
                    continue
                try:
                    response = self.fetcher.fetch(segment_url)
                    self.stream_cache.add_segment(segment_url, response.content)
                    logging.debug(f"[Prefetch] Sucesso para {segment_url}")
                except Exception as e:
                    logging.warning(f"[Prefetch] Falha para {segment_url}: {e}")
                finally:
                    self._segment_prefetch_queue.task_done()
            except queue.Empty:
                pass
        logging.info("Thread de pré-busca encerrada.")
    
    def _health_check_worker(self):
        logging.info("Iniciando monitor de saúde do stream")
        
        while not self._health_check_stop_event.is_set():
            time.sleep(HEALTH_CHECK_INTERVAL)
            
            if not self._current_manifest_url:
                continue
                
            now = time.time()
            recent_segments = [
                url for url, timestamp in self._last_successful_segment_time.items()
                if now - timestamp < HEALTH_CHECK_INTERVAL * 2
            ]
            
            # Verificar se o buffer está crítico
            buffer_size = self.stream_cache.buffer_size()
            buffer_size_mb = buffer_size / (1024 * 1024)
            
            if not recent_segments and self._current_manifest_url:
                logging.warning(f"[Health Check] Nenhum segmento bem-sucedido recentemente. Buffer: {buffer_size_mb:.2f}MB")
                
                try:
                    response = self.fetcher.fetch(self._current_manifest_url)
                    if response.status_code == 200:
                        content = response.text
                        
                        if is_manifest_limit_error(content):
                            logging.warning(f"[Health Check] Erro de limite detectado. Forçando reconexão.")
                            self.force_reconnection(self._current_manifest_url)
                        else:
                            logging.info(f"[Health Check] Manifesto OK, mas sem segmentos recentes. Possível pausa na reprodução.")
                            
                            # Tentar pré-buscar segmentos se o buffer estiver baixo
                            if buffer_size_mb < 5:  # Menos de 5MB no buffer
                                proxy_base = f"http://{PROXY_HOST}:{self.active_port}/?url="
                                rewriter = ManifestRewriter(content, response.url, proxy_base)
                                segments = rewriter.m3u8_obj.segments
                                
                                # Pré-buscar os próximos segmentos
                                for segment in segments[-PREFETCH_SEGMENTS_COUNT:]:
                                    if not self.stream_cache.has_segment(segment.absolute_uri):
                                        self.queue_segment_for_prefetch(segment.absolute_uri)
                    else:
                        logging.warning(f"[Health Check] Manifesto retornou status {response.status_code}. Forçando reconexão.")
                        self.force_reconnection(self._current_manifest_url)
                except Exception as e:
                    logging.error(f"[Health Check] Erro ao verificar manifesto: {e}")
                    self.force_reconnection(self._current_manifest_url)
            
            # Coletar estatísticas para diagnóstico
            cache_stats = self.chunk_cache.get_stats()
            manifest_stats = self.stream_cache.get_manifest_stats()
            
            # Obter estatísticas do domínio
            domain = urllib.parse.urlparse(self._current_manifest_url).netloc if self._current_manifest_url else None
            domain_stats = self.fetcher.get_domain_stats(domain) if domain else {}
            
            logging.debug(f"[Health Check] Cache: {cache_stats['usage_percent']:.1f}% | "
                         f"Buffer: {buffer_size_mb:.2f}MB | "
                         f"Manifestos: {manifest_stats['manifest_count']} | "
                         f"Falhas: {domain_stats.get('failure_count', 0)}")
            
            # Verificar se precisamos ajustar a qualidade adaptativa
            if ADAPTIVE_QUALITY_ENABLED and domain_stats.get('failure_count', 0) >= QUALITY_DEGRADATION_THRESHOLD:
                self._adjust_quality_down()
            
        logging.info("Monitor de saúde do stream encerrado.")
    
    def _adjust_quality_down(self):
        """Reduz a qualidade do stream em caso de falhas consecutivas."""
        if not self._current_manifest_url or self._current_bandwidth_index is None:
            return
            
        if self._current_bandwidth_index > MIN_QUALITY_INDEX:
            self._current_bandwidth_index -= 1
            logging.info(f"[Qualidade Adaptativa] Reduzindo qualidade para índice {self._current_bandwidth_index}")
            
            # Forçar recarga do manifesto com a nova qualidade
            self.force_reconnection(self._current_manifest_url)
    
    def _create_flask_app(self) -> Flask:
        app = Flask(ADDON_NAME)
        manager = self

        app.logger.disabled = True
        logging.getLogger('werkzeug').disabled = True

        @app.route('/')
        def proxy_route():
            original_url = request.args.get('url')
            if not original_url:
                return make_response("Parâmetro 'url' ausente", 200)

            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                return manager._handle_manifest_flask(original_url)
            else:
                return manager._handle_segment_flask(original_url)
        
        return app

    def _handle_manifest_flask(self, url: str) -> Response:
        logging.info(f"Manipulando manifesto: {url}")
        self._current_manifest_url = url
        
        if self.is_in_cooldown(url):
            logging.warning(f"Manifesto em cooldown. Enviando playlist vazia.")
            return make_response("#EXTM3U\n", 200, {'Content-Type': 'application/vnd.apple.mpegurl'})

        if self.stream_cache.is_manifest_expired(url):
            logging.info(f"Manifesto expirou. Forçando reconexão.")
            self.force_reconnection(url)

        cached_content = self.stream_cache.get_manifest(url)
        if cached_content:
            return make_response(cached_content, 200, {'Content-Type': 'application/vnd.apple.mpegurl'})

        try:
            response = self.fetcher.fetch(url, original_headers=request.headers)
            content = response.text

            if is_manifest_limit_error(content):
                logging.warning(f"Erro de limite/bloqueio detectado para {url}.")
                self.record_limit_hit(url)
                self.force_reconnection(url)
                return make_response("#EXTM3U\n", 200, {'Content-Type': 'application/vnd.apple.mpegurl'})
            
            proxy_base = f"http://{request.host}/?url="
            rewriter = ManifestRewriter(content, response.url, proxy_base)
            
            # Se a qualidade adaptativa estiver habilitada e não tivermos um índice definido,
            # selecionar uma qualidade média para começar
            if ADAPTIVE_QUALITY_ENABLED and self._current_bandwidth_index is None:
                bandwidth_info = rewriter.get_bandwidth_info()
                if bandwidth_info:
                    # Selecionar uma qualidade média (não a mais alta, não a mais baixa)
                    self._current_bandwidth_index = min(len(bandwidth_info) - 1, max(0, len(bandwidth_info) // 2))
                    logging.info(f"[Qualidade Adaptativa] Iniciando com índice de qualidade {self._current_bandwidth_index}")
            
            rewritten_content = rewriter.rewrite()
            self.stream_cache.add_manifest(url, rewritten_content, rewriter.get_ttl())
            self.clear_limit_hit(url)
            
            segments = rewriter.m3u8_obj.segments
            if rewriter.is_live:
                # Para streams ao vivo, pré-buscar os últimos segmentos
                segments_to_prefetch = segments[-PREFETCH_SEGMENTS_COUNT:]
            else: 
                # Para VOD, pré-buscar os primeiros segmentos
                segments_to_prefetch = segments[:PREFETCH_SEGMENTS_COUNT]
            
            for segment in segments_to_prefetch:
                if not self.stream_cache.has_segment(segment.absolute_uri):
                    self.queue_segment_for_prefetch(segment.absolute_uri)

            return make_response(rewritten_content, 200, {'Content-Type': 'application/vnd.apple.mpegurl'})
        except Exception as e:
            logging.error(f"Falha ao processar manifesto {url}: {e}")
            self.force_reconnection(url)
            return make_response("#EXTM3U\n", 200, {'Content-Type': 'application/vnd.apple.mpegurl'})

    def _handle_segment_flask(self, url: str) -> Response:
        mime_type = safe_mime_type(url)
        cached_segment = self.stream_cache.get_segment(url)
        if cached_segment:
            self.record_successful_segment(url)
            logging.debug(f"Segmento {url} servido do cache.")
            return Response(cached_segment, mimetype=mime_type, status=200)

        logging.debug(f"Iniciando streaming de segmento {url}")

        def stream_generator():
            segment_data = bytearray()
            try:
                with self.fetcher.fetch(url, stream=True, original_headers=request.headers) as response:
                    for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        if chunk:
                            segment_data.extend(chunk)
                            yield chunk
                
                self.stream_cache.add_segment(url, bytes(segment_data))
                self.record_successful_segment(url)
                logging.info(f"Segmento {url} (tamanho: {len(segment_data)}) streamado e cacheado com sucesso.")
            except Exception as e:
                self.increment_failure_count()
                logging.error(f"Erro durante o streaming do segmento {url}: {e}", exc_info=False)
                
                # Registrar tentativa de recuperação
                with self._recovery_lock:
                    self._recovery_attempts[url] = self._recovery_attempts.get(url, 0) + 1
                    recovery_attempts = self._recovery_attempts[url]
                
                # Em caso de falha, tenta fornecer um fluxo contínuo do cache
                while True:
                    continuous_stream = self.stream_cache.get_continuous_stream(DEFAULT_CHUNK_SIZE)
                    if continuous_stream:
                        logging.info(f"Fornecendo fluxo contínuo do cache (tamanho: {len(continuous_stream)})")
                        yield continuous_stream
                    else:
                        # Se o buffer estiver esgotado e atingimos o limite de tentativas, forçar reconexão
                        if recovery_attempts >= RECOVERY_ATTEMPTS_BEFORE_RESET:
                            logging.warning("Limite de tentativas de recuperação atingido. Forçando reconexão.")
                            if self._current_manifest_url:
                                self.force_reconnection(self._current_manifest_url)
                            break
                        
                        logging.warning("Buffer contínuo esgotado. Tentando reconectar...")
                        time.sleep(1)
                        
                        try:
                            if self._current_manifest_url:
                                response = self.fetcher.fetch(self._current_manifest_url)
                                if response.status_code == 200:
                                    content = response.text
                                    if not is_manifest_limit_error(content):
                                        proxy_base = f"http://{request.host}/?url="
                                        rewriter = ManifestRewriter(content, response.url, proxy_base)
                                        rewritten_content = rewriter.rewrite()
                                        self.stream_cache.add_manifest(self._current_manifest_url, rewritten_content, rewriter.get_ttl())
                                        
                                        segments = rewriter.m3u8_obj.segments
                                        for segment in segments[-PREFETCH_SEGMENTS_COUNT:]:
                                            if not self.stream_cache.has_segment(segment.absolute_uri):
                                                self.queue_segment_for_prefetch(segment.absolute_uri)
                                        
                                        logging.info("Reconexão ao manifesto bem-sucedida. Retomando streaming...")
                                        break
                        except Exception as reconnect_error:
                            logging.error(f"Falha na reconexão: {reconnect_error}")
                            time.sleep(2)

        try:
            return Response(stream_with_context(stream_generator()), mimetype=mime_type, status=200)
        except Exception:
            if self.should_force_reconnect():
                logging.error(f"Limite de falhas atingido. Forçando reconexão total.")
                self.force_reconnection(url)
                self.reset_failure_count()
            return make_response("Falha ao obter segmento", 200)

    def start(self) -> Optional[int]:
        self.stop()
        os.environ['WERKZEUG_RUN_MAIN'] = 'true'

        for i in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                
                self._prefetch_stop_event.clear()
                self._prefetch_thread = threading.Thread(target=self._prefetch_worker, daemon=True)
                self._prefetch_thread.start()
                
                self._health_check_stop_event.clear()
                self._health_check_thread = threading.Thread(target=self._health_check_worker, daemon=True)
                self._health_check_thread.start()

                logging.info(f"Proxy HLS (Flask) otimizado iniciado em http://{PROXY_HOST}:{port}")
                return port
            except Exception as e:
                logging.warning(f"Porta {port} em uso ou falhou. Tentativa {i+1}/{MAX_PORT_ATTEMPTS}. Erro: {e}")
        
        logging.error("Não foi possível encontrar uma porta disponível para o proxy.")
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o proxy",5000)')
        return None

    def stop(self):
        if self._health_check_thread and self._health_check_thread.is_alive():
            self._health_check_stop_event.set()
            self._health_check_thread.join(timeout=2)

        if self._prefetch_thread and self._prefetch_thread.is_alive():
            self._prefetch_stop_event.set()
            self._prefetch_thread.join(timeout=2)

        if self.server:
            try:
                self.server.shutdown()
            except Exception as e:
                logging.error(f"Erro ao desligar o servidor proxy: {e}")
            self.server = None
        
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2)
            self.server_thread = None

        self.stream_cache.clear()
        self.reset_http_session()
        self.active_port = None
        self._current_manifest_url = None
        self._last_successful_segment_time.clear()
        self._current_bandwidth_index = None
        with self._recovery_lock:
            self._recovery_attempts.clear()
        logging.info("Proxy HLS (Flask) otimizado parado e recursos liberados.")

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        if not self.active_port:
            return None
        encoded_url = urllib.parse.quote_plus(original_url)
        return f"http://{PROXY_HOST}:{self.active_port}/?url={encoded_url}"


# ==============================================================================
# --- INTEGRAÇÃO COM O KODI ---
# ==============================================================================

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event
        self.last_position = 0
        self.last_update_time = time.time()
        self.stall_count = 0
        self._monitor_thread = None
        self._monitor_stop_event = threading.Event()
        self.buffer_health = 100  # Percentual de saúde do buffer
        self.last_buffer_check = time.time()

    def onPlayBackStarted(self):
        logging.info("Playback iniciado (onPlayBackStarted).")
        self.last_position = 0
        self.last_update_time = time.time()
        self.stall_count = 0
        self.buffer_health = 100
        
        self._monitor_stop_event.clear()
        self._monitor_thread = threading.Thread(target=self._monitor_buffer, daemon=True)
        self._monitor_thread.start()

    def onPlayBackEnded(self):
        logging.info("Playback finalizado (onPlayBackEnded).")
        self.stop_event.set()
        self._stop_monitor()

    def onPlayBackError(self):
        logging.error("Erro no Playback (onPlayBackError).")
        self.stop_event.set()
        self._stop_monitor()

    def onPlayBackStopped(self):
        logging.info("Playback parado pelo usuário (onPlayBackStopped).")
        self.stop_event.set()
        self._stop_monitor()
    
    def _stop_monitor(self):
        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_stop_event.set()
            self._monitor_thread.join(timeout=1)
    
    def _monitor_buffer(self):
        logging.info("Monitor de buffer iniciado.")
        
        while not self._monitor_stop_event.is_set():
            try:
                time.sleep(2)
                
                if not self.isPlaying():
                    continue
            
                current_time = self.getTime()
                current_position = int(current_time)
                
                # Verificar a saúde do buffer a cada 5 segundos
                now = time.time()
                if now - self.last_buffer_check >= 5:
                    self.last_buffer_check = now
                    
                    # Obter informações do buffer
                    try:
                        cache_buffer = self.getCacheBuffer()
                        if cache_buffer:
                            # Ajustar a saúde do buffer com base no tamanho do cache
                            if cache_buffer > 30:
                                self.buffer_health = min(100, self.buffer_health + 5)
                            elif cache_buffer > 10:
                                self.buffer_health = max(50, self.buffer_health - 2)
                            else:
                                self.buffer_health = max(0, self.buffer_health - 10)
                            
                            logging.debug(f"Buffer: {cache_buffer}% | Saúde: {self.buffer_health}%")
                    except:
                        pass
                
                # Detectar travamento
                if current_position == self.last_position:
                    self.stall_count += 1
                    logging.warning(f"Buffer possivelmente travado. Contador: {self.stall_count}")
                    
                    if self.stall_count >= 3:
                        logging.error("Detectado travamento de buffer. Tentando recuperar.")
                        
                        # Se a saúde do buffer estiver baixa, tentar uma recuperação mais agressiva
                        if self.buffer_health < 30:
                            logging.warning("Saúde do buffer crítica. Tentando recuperação agressiva.")
                            self.pause()
                            time.sleep(1)
                            self.pause()
                        else:
                            self.pause()
                            time.sleep(0.5)
                            self.pause()
                        
                        self.stall_count = 0
                else:
                    if self.stall_count > 0:
                        logging.info(f"Buffer recuperado. Resetando contador de travamentos.")
                    self.stall_count = 0
                    self.last_position = current_position
                
                self.last_update_time = now
            except Exception as e:
                logging.error(f"Erro no monitor de buffer: {e}")
                
        logging.info("Monitor de buffer encerrado.")

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)

    def _convert_to_m3u8(self, url: str) -> str:
        try:
            if any(ext in url for ext in ['.m3u8', '/hl', '.mp4', '.avi']):
                return url.split('|')[0]
            
            if url.count("/") > 4 and '.ts' in url:
                base_url, ts_file = url.rsplit('/', 1)
                m3u8_file = ts_file.replace('.ts', '.m3u8')
                return f"{base_url}/{m3u8_file}"
            
            return f"{url}.m3u8"
        except Exception as e:
            logging.warning(f"Falha na conversão para m3u8 (usando URL original): {e}")
            return url.split('|')[0]

    def play_stream(self, url: str, channel_name: Optional[str] = None):
        logging.info(f"Iniciando stream para: {url}")
        processed_url = self._convert_to_m3u8(url)
        logging.info(f"URL processada para HLS: {processed_url}")

        if not self.proxy_manager.start():
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if not proxy_url:
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        display_name = f"{channel_name or 'Stream'} [COLOR cyan](HLS Tester Flask Proxy)[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_name)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        
        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
        logging.info(f"Kodi resolvido para a URL do proxy: {proxy_url}")

        threading.Thread(target=self.monitor_playback, daemon=True).start()

    def monitor_playback(self):
        logging.info("Monitor de playback iniciado.")
        self.playback_stop_event.wait()
        logging.info("Evento de parada de playback recebido. Liberando proxy.")
        self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Big Buck Bunny (VOD)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Live Stream (Teste)", "https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8"),
            ("Adaptive Bitrate", "https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8"),
            ("Live News", "https://nhkworld.webcdn.stream.ne.jp/www11/nhkworld-tv/global/2003458/live.m3u8")
        ]
        for name, url in test_streams:
            list_item = xbmcgui.ListItem(label=name)
            list_item.setProperty('IsPlayable', 'true')
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, list_item, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

def main():
    setup_logging()
    
    try:
        handle = int(sys.argv[1])
        params_str = sys.argv[2][1:]
        params = dict(urllib.parse.parse_qsl(params_str))
        
        addon = HLSProxyAddon(handle)
        action = params.get('action')

        if action == 'play':
            url_to_play = params.get('url')
            title = params.get('title')
            if url_to_play:
                addon.play_stream(url_to_play, title)
        else:
            addon.show_test_streams()
            
    except Exception as e:
        logging.error(f"Erro fatal na execução principal do addon: {e}", exc_info=True)

if __name__ == '__main__':
    main()