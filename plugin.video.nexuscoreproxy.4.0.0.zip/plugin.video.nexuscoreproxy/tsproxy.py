#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Nexus Core MPEG-TS Proxy (Curl Mode Edition)
# Author: Deivid Silva

import json
import time
import uuid
import random
import os
import threading
import queue
import socketserver
import urllib.request
import urllib.error
import socket
import sys
from typing import Dict, Optional, Set
from collections import defaultdict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, urlencode, quote

class ThreadedHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads     = True
    allow_reuse_address = True

DEFAULT_PORT    = 0
VERBOSE_LOGGING = False
SILENT_RECONNECTION = True

SERVIDORES_FIXOS = {
}

TS_PACKET_SIZE   = 188
TAIL_SIZE        = 174 * 188
TAIL_SECONDARY   = 43  * 188
TAIL_SAVE_MIN_BYTES = TS_PACKET_SIZE * 8

SUTURE_CHUNK_SIZE = 256 * 1024
TS_CHUNK_SIZE     = 50  * 1024

SUTURE_RESYNC_TRIM_THRESHOLD = 32 * 1024 * 1024
SUTURE_RESYNC_KEEP_MARGIN    = TAIL_SIZE * 8 + TAIL_SECONDARY * 4 + (2 * 1024 * 1024)
SUTURE_WINDOW_TIMEOUT = 8.0

FETCH_TIMEOUT        = 15
QUEUE_SIZE           = 2048
PREBUFFER_BYTES      = 50 * 1024 * 40
ENGINE_IDLE_TIMEOUT  = 60

BACKOFF_BASE  = 1.0
BACKOFF_MAX   = 12.0
BACKOFF_MULT  = 1.5

_ALL_REFERER  = ['https://www.google.com/', 'https://www.bing.com/', 'https://www.youtube.com/']
_ACCEPT_LANG  = ['pt-BR,pt;q=0.9,en;q=0.8', 'en-US,en;q=0.9']

def generate_exoplayer_ua():
    version = f"2.{random.randint(14, 19)}.{random.randint(0, 5)}"
    return f"ExoPlayer/{version} (Linux; Android {random.randint(9, 14)}) ExoPlayerLib/{version}"

_RESERVED_OCTETS = frozenset({10, 127, 169, 172, 192, 198, 203, 224})

def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 not in _RESERVED_OCTETS:
            return f"{o1}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"

def get_stream_headers(target_url, ua=None, fake_ip=None):
    if ua is None:
        ua = generate_exoplayer_ua()
    if fake_ip is None:
        fake_ip = random_ip()
    return {
        'User-Agent':      ua,
        'Accept':          '*/*',
        'Accept-Language': random.choice(_ACCEPT_LANG),
        'Connection':      'keep-alive',
        'X-Forwarded-For': fake_ip,
        'X-Real-IP':       fake_ip,
        'Referer':         random.choice(_ALL_REFERER),
    }

def add_log(message, level='INFO', force_silent=False):
    if SILENT_RECONNECTION and not force_silent:
        keywords = ['Reconexão', 'SUTURA', 'Erro de conexão', 'Transient', '406', 'retry']
        if any(k in message for k in keywords):
            return

    if not VERBOSE_LOGGING and 'LEGACY' not in message and 'ENGINE' not in message:
        if level != 'ERROR':
            return

    ts = datetime.now().strftime("%H:%M:%S")
    try:
        import xbmc
        lvl_map = {'WARNING': xbmc.LOGWARNING, 'ERROR': xbmc.LOGERROR}
        xbmc.log(f"[TSProxy] {message}", level=lvl_map.get(level, xbmc.LOGINFO))
    except ImportError:
        print(f"[{ts}][{level}] {message}", file=sys.stderr, flush=True)

class ProxyStats:
    def __init__(self):
        self.lock                = threading.Lock()
        self.total_transmitted   = 0
        self.total_skipped       = 0
        self.total_reconnections = 0
        self.active_engines      = 0
        self.total_clients       = 0

    def inc(self, field, value=1):
        with self.lock:
            setattr(self, field, getattr(self, field) + value)

    def set(self, field, value):
        with self.lock:
            setattr(self, field, value)

stats = ProxyStats()

class XStore:
    def __init__(self):
        self.data = {"servers": {}}
        self.lock = threading.Lock()
        for sid, srv in SERVIDORES_FIXOS.items():
            self.data["servers"][sid] = srv

    def get_server(self, sid):
        with self.lock:
            return self.data["servers"].get(sid)

    def add_server(self, sid, name, url, user, password):
        with self.lock:
            if not sid:
                sid = str(uuid.uuid4())[:8]
            self.data["servers"][sid] = {
                "name":   name,
                "url":    url.rstrip('/'),
                "user":   user,
                "pass":   password,
                "active": True
            }
            return sid

store = XStore()

class StreamManager:
    def __init__(self):
        self._engines = {}
        self._clients = defaultdict(set)
        self._timers  = {}
        self._lock    = threading.Lock()

    def _get_key(self, sid, stream_id):
        return f"{sid}_{stream_id}"

    def get_or_create_engine(self, sid, stream_id, url):
        key = self._get_key(sid, stream_id)
        with self._lock:
            eng = self._engines.get(key)
            if eng and eng.is_alive():
                t = self._timers.get(key)
                if t:
                    t.cancel()
                    self._timers[key] = None
                return eng
            engine = TSEngine(stream_id, url)
            engine.start()
            self._engines[key] = engine
            stats.set('active_engines', len(self._engines))
            return engine

    def register_client(self, sid, stream_id, client_id):
        key    = self._get_key(sid, stream_id)
        server = store.get_server(sid)
        if not server:
            raise Exception("Server not found")
        # Suporte a ambos os formatos:
        # - Xtream Codes: /live/user/pass/stream_id.ts
        # - Direto:       /user/pass/stream_id.ts  (quando sid contém "_direto" ou não há prefixo live)
        name = server.get('name', '')
        if 'direto' in name.lower() or '(direto)' in name.lower():
            url = f"{server['url']}/{server['user']}/{server['pass']}/{stream_id}.ts"
        else:
            url = f"{server['url']}/live/{server['user']}/{server['pass']}/{stream_id}.ts"
        engine = self.get_or_create_engine(sid, stream_id, url)
        with self._lock:
            self._clients[key].add(client_id)
            stats.set('total_clients', sum(len(c) for c in self._clients.values()))
        return engine

    def unregister_client(self, sid, stream_id, client_id):
        key = self._get_key(sid, stream_id)
        with self._lock:
            self._clients[key].discard(client_id)
            stats.set('total_clients', sum(len(c) for c in self._clients.values()))
            if len(self._clients[key]) == 0 and key in self._engines:
                t = self._timers.get(key)
                if t:
                    t.cancel()
                timer = threading.Timer(ENGINE_IDLE_TIMEOUT, self._delayed_shutdown, args=[key])
                timer.daemon = True
                timer.start()
                self._timers[key] = timer

    def _delayed_shutdown(self, key):
        with self._lock:
            if key in self._engines and len(self._clients.get(key, set())) == 0:
                self._engines[key].stop()
                del self._engines[key]
                self._clients.pop(key, None)
                self._timers.pop(key, None)
                stats.set('active_engines', len(self._engines))

    def force_stop_all(self):
        with self._lock:
            for engine in list(self._engines.values()):
                engine.stop()
            self._engines.clear()
            self._clients.clear()
            for t in self._timers.values():
                if t:
                    t.cancel()
            self._timers.clear()
            stats.set('active_engines', 0)
            stats.set('total_clients', 0)

stream_manager = StreamManager()

class ReconnectionSystem:
    def __init__(self):
        self.history          = []
        self.last_success_idx = None
        self.locked_ip        = random_ip()
        self.locked_ua        = generate_exoplayer_ua()
        self.failure_count    = 0
        self.lock             = threading.Lock()

    def reset_identity(self):
        with self.lock:
            self.locked_ip = random_ip()
            self.locked_ua = generate_exoplayer_ua()

    def _do_get(self, url, extra=None):
        h = get_stream_headers(url, ua=self.locked_ua, fake_ip=self.locked_ip)
        if extra:
            h.update(extra)
        return urllib.request.Request(url, headers=h)

    def _s0_fast(self, url):
        return self._do_get(url, extra={'X-Request-Id': str(uuid.uuid4())})

    def _s1_backoff(self, url):
        time.sleep(random.uniform(0.3, 0.8))
        return self._do_get(url)

    def _s3_alt_proto(self, url):
        alt = (url.replace('https://', 'http://', 1)
               if url.startswith('https://') else
               url.replace('http://', 'https://', 1))
        return self._do_get(alt)

    def _s4_cache_bust(self, url):
        sep    = '&' if '?' in url else '?'
        busted = f"{url}{sep}_t={int(time.time())}"
        return self._do_get(busted, extra={'Cache-Control': 'no-cache, no-store'})

    def _s5_new_identity(self, url):
        self.reset_identity()
        return self._do_get(url)

    _STRATEGIES = [_s0_fast, _s1_backoff, _s3_alt_proto, _s4_cache_bust, _s5_new_identity]

    def next_idx(self):
        with self.lock:
            if self.last_success_idx is not None and self.failure_count == 0:
                return self.last_success_idx
            if not self.history:
                return 0
            recent = set(self.history[-3:])
            avail  = [i for i in range(len(self._STRATEGIES)) if i not in recent]
            if not avail:
                last = self.history[-1] if self.history else 0
                return (last + 1) % len(self._STRATEGIES)
            return random.choice(avail)

    def execute(self, idx, url):
        return self._STRATEGIES[idx % len(self._STRATEGIES)](self, url)

class SingleTailCache:
    def __init__(self):
        self._live   = b''
        self._backup = b''
        self.lock    = threading.Lock()

    def update_live(self, tail):
        if not tail or len(tail) < TAIL_SAVE_MIN_BYTES:
            return False
        remainder = len(tail) % TS_PACKET_SIZE
        if remainder:
            tail = tail[remainder:]
        if len(tail) < TAIL_SAVE_MIN_BYTES:
            return False
        with self.lock:
            self._live = tail[-TAIL_SIZE:] if len(tail) > TAIL_SIZE else tail
        return True

    def promote_to_backup(self):
        with self.lock:
            if self._live and len(self._live) >= TAIL_SAVE_MIN_BYTES:
                self._backup = self._live
                self._live   = b''
                return True
        return False

    def get_for_suture(self):
        with self.lock:
            return self._live

    def get_for_recovery(self):
        with self.lock:
            return self._backup if not self._live else b''

    def clear_all(self):
        with self.lock:
            self._live   = b''
            self._backup = b''

    @property
    def has_any(self):
        with self.lock:
            return bool(
                (self._live   and len(self._live)   >= TAIL_SAVE_MIN_BYTES) or
                (self._backup and len(self._backup) >= TAIL_SAVE_MIN_BYTES)
            )

class TSEngine(threading.Thread):
    def __init__(self, stream_id, url):
        super().__init__(daemon=True)
        self.stream_id           = stream_id
        self.base_url            = url
        self.data_queue          = queue.Queue(maxsize=QUEUE_SIZE)
        self._stop_event         = threading.Event()
        self.prebuf_ready        = threading.Event()
        self.reconn              = ReconnectionSystem()
        self.stream_tail         = bytearray()
        self.residual_buffer     = bytearray()
        self.has_initial_lock    = False
        self.tail_cache          = SingleTailCache()
        self._prebuf_bytes       = 0
        self._bytes_streamed     = 0
        self.consecutive_failures     = 0
        self.last_reconnect_attempt   = 0.0
        self.backoff_delay            = BACKOFF_BASE
        self._last_successful_read    = time.time()
        self._null_packet = b'\x47\x00\x1F\xFF' + b'\xFF' * (TS_PACKET_SIZE - 4)
        self._tail_lock     = threading.Lock()
        self._residual_lock = threading.Lock()

    def is_alive(self):
        return not self._stop_event.is_set() and super().is_alive()

    def stop(self):
        self._stop_event.set()
        try:
            while True:
                self.data_queue.get_nowait()
        except queue.Empty:
            pass

    def _tail_saver(self):
        while not self._stop_event.is_set():
            time.sleep(0.25)
            if self._stop_event.is_set():
                break
            with self._tail_lock:
                if (self.stream_tail and
                        len(self.stream_tail) >= TAIL_SAVE_MIN_BYTES and
                        self._bytes_streamed > 0):
                    self.tail_cache.update_live(bytes(self.stream_tail))

    def _prepare_for_reset(self):
        with self._tail_lock:
            if self.stream_tail and len(self.stream_tail) >= TAIL_SAVE_MIN_BYTES:
                if self.tail_cache.update_live(bytes(self.stream_tail)):
                    self.tail_cache.promote_to_backup()

    def _session_reset(self, keep_prebuf=False):
        self._prepare_for_reset()
        if not keep_prebuf:
            self._prebuf_bytes = 0
            self.prebuf_ready.clear()
        with self._tail_lock:
            self.stream_tail = bytearray()
        with self._residual_lock:
            self.residual_buffer = bytearray()
        self.has_initial_lock = False

    def _try_suture(self, buf):
        buf_len = len(buf)
        min_search_len = TAIL_SIZE + TAIL_SECONDARY + TS_PACKET_SIZE * 10
        if buf_len < min_search_len:
            return False, b''

        for tail, label in [
            (self.tail_cache.get_for_suture(),   'LIVE'),
            (self.tail_cache.get_for_recovery(), 'BACKUP'),
        ]:
            if tail:
                ok, rem = self._find_match(buf, tail, label)
                if ok:
                    return True, rem

        if buf_len > SUTURE_RESYNC_TRIM_THRESHOLD:
            keep_start = buf_len - SUTURE_RESYNC_KEEP_MARGIN
            if keep_start > 0:
                keep_start -= keep_start % TS_PACKET_SIZE
                discarded   = keep_start
                del buf[:keep_start]
                add_log(f'[SUTURA] Janela deslizante: descartou {discarded // 1024:,} KB', 'INFO')

        return False, b''

    def _find_match(self, buf, tail, label):
        primary = tail[-TAIL_SIZE:] if len(tail) >= TAIL_SIZE else tail
        if primary:
            idx = buf.rfind(primary)
            if idx != -1:
                skip      = idx + len(primary)
                remainder = bytes(buf[skip:])
                align     = self._find_sync_offset(remainder)
                if align > 0:
                    remainder = remainder[align:]
                    skip     += align
                add_log(f'[SUTURA] Perfeita [{label}] pulou {skip // 1024:,} KB', 'INFO')
                stats.inc('total_skipped', skip)
                return True, remainder

        secondary = tail[-TAIL_SECONDARY:] if len(tail) >= TAIL_SECONDARY else b''
        if secondary and len(buf) > TAIL_SECONDARY + 188 * 50:
            idx = buf.rfind(secondary)
            if idx != -1:
                skip      = idx + len(secondary)
                remainder = bytes(buf[skip:])
                align     = self._find_sync_offset(remainder)
                if align > 0:
                    remainder = remainder[align:]
                    skip     += align
                add_log(f'[SUTURA] Secundária [{label}] pulou {skip // 1024:,} KB', 'INFO')
                stats.inc('total_skipped', skip)
                return True, remainder

        return False, b''

    @staticmethod
    def _find_sync_offset(data):
        length = len(data)
        for i in range(min(length, 1000)):
            if data[i] == 0x47:
                n1 = i + TS_PACKET_SIZE
                n2 = i + TS_PACKET_SIZE * 2
                n3 = i + TS_PACKET_SIZE * 3
                if n1 < length and data[n1] == 0x47:
                    if n2 < length and data[n2] == 0x47:
                        if n3 >= length or data[n3] == 0x47:
                            return i
        return -1

    def _process(self, raw):
        if not raw:
            return
        with self._residual_lock:
            self.residual_buffer.extend(raw)
            batch = self.residual_buffer

            if not self.has_initial_lock:
                idx = self._find_sync_offset(batch)
                if idx == -1:
                    if len(batch) > TS_PACKET_SIZE * 4:
                        del batch[:len(batch) - TS_PACKET_SIZE * 4]
                    return
                del batch[:idx]
                self.has_initial_lock = True

            n = len(batch) // TS_PACKET_SIZE
            if n == 0:
                return
            used    = n * TS_PACKET_SIZE
            payload = bytes(batch[:used])
            del batch[:used]

        with self._tail_lock:
            self.stream_tail.extend(payload)
            if len(self.stream_tail) > (TAIL_SIZE + TAIL_SECONDARY):
                del self.stream_tail[:len(self.stream_tail) - TAIL_SIZE]

        stats.inc('total_transmitted', len(payload))
        self._bytes_streamed       += len(payload)
        self._last_successful_read  = time.time()

        if not self.prebuf_ready.is_set():
            self._prebuf_bytes += len(payload)
            if self._prebuf_bytes >= PREBUFFER_BYTES:
                self.prebuf_ready.set()

        try:
            self.data_queue.put_nowait(payload)
        except queue.Full:
            try:
                self.data_queue.get_nowait()
                self.data_queue.put_nowait(payload)
            except Exception:
                pass

    def _send_null_packets(self, count=10):
        null_data = self._null_packet * count
        try:
            self.data_queue.put_nowait(null_data)
        except queue.Full:
            pass

    def run(self):
        add_log(f"[ENGINE] Iniciado stream {self.stream_id}", 'INFO')
        tail_thread = threading.Thread(target=self._tail_saver, daemon=True)
        tail_thread.start()

        while not self._stop_event.is_set():
            response = None
            try:
                need_reconnect = (
                    self.consecutive_failures > 0 or
                    (time.time() - self._last_successful_read > 5 and self._bytes_streamed > 0)
                )

                if need_reconnect:
                    stats.inc('total_reconnections')
                    strategy_idx = self.reconn.next_idx()
                    delay = min(
                        BACKOFF_BASE * (BACKOFF_MULT ** self.consecutive_failures),
                        BACKOFF_MAX
                    ) + random.uniform(0, 0.5)

                    add_log(f'[PRODUCER] Reconexão S{strategy_idx} (falha #{self.consecutive_failures})', 'INFO')
                    self.reconn.history.append(strategy_idx)
                    self._session_reset(keep_prebuf=True)

                    now = time.time()
                    if now - self.last_reconnect_attempt < delay:
                        wait_time = delay - (now - self.last_reconnect_attempt)
                        steps     = int(wait_time / 0.1)
                        for _ in range(steps):
                            if self._stop_event.is_set():
                                break
                            time.sleep(0.1)
                            if int(time.time() * 10) % 5 == 0:
                                self._send_null_packets(5)

                    self.last_reconnect_attempt = time.time()
                    req = self.reconn.execute(strategy_idx, self.base_url)
                else:
                    h   = get_stream_headers(self.base_url,
                                             ua=self.reconn.locked_ua,
                                             fake_ip=self.reconn.locked_ip)
                    req = urllib.request.Request(self.base_url, headers=h)

                try:
                    response = urllib.request.urlopen(req, timeout=FETCH_TIMEOUT)
                    code     = response.getcode()

                    if code == 406:
                        self.consecutive_failures = 0
                        self.reconn.failure_count = 0
                        self.reconn.reset_identity()
                        continue

                    if code not in (200, 206):
                        self.consecutive_failures  += 1
                        self.reconn.failure_count  += 1
                        if self.reconn.failure_count >= 3:
                            self.reconn.reset_identity()
                            self.reconn.failure_count = 0
                        time.sleep(1)
                        continue

                    self.consecutive_failures       = 0
                    self.reconn.failure_count       = 0
                    self.reconn.last_success_idx    = 0
                    self.backoff_delay              = BACKOFF_BASE
                    self._last_successful_read      = time.time()

                    resync_buf   = bytearray()
                    need_suture  = self.tail_cache.has_any
                    suture_start = time.time()
                    chunk_size   = SUTURE_CHUNK_SIZE if need_suture else TS_CHUNK_SIZE

                    while not self._stop_event.is_set():
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break

                        if need_suture:
                            resync_buf.extend(chunk)
                            ok, remainder = self._try_suture(resync_buf)
                            if ok:
                                del resync_buf[:]
                                need_suture = False
                                self.has_initial_lock = False
                                with self._residual_lock:
                                    self.residual_buffer = bytearray()
                                self.tail_cache.clear_all()
                                self._process(remainder)
                                if not self.prebuf_ready.is_set():
                                    self.prebuf_ready.set()
                            else:
                                if time.time() - suture_start > SUTURE_WINDOW_TIMEOUT:
                                    add_log(f'[SUTURA] Timeout ({SUTURE_WINDOW_TIMEOUT}s) — transmitindo bruto', 'WARNING')
                                    need_suture = False
                                    self.tail_cache.clear_all()
                                    self._process(bytes(resync_buf))
                                    del resync_buf[:]
                        else:
                            self._process(chunk)

                except urllib.error.HTTPError as e:
                    if e.code == 406:
                        self.consecutive_failures = 0
                        self.reconn.reset_identity()
                        continue
                    add_log(f'[PRODUCER] Erro HTTP {e.code}', 'WARNING')
                    self.consecutive_failures += 1
                    time.sleep(1)

                except (TypeError, ValueError) as e:
                    add_log(f'[PRODUCER] Erro de formato: {e}', 'ERROR')
                    self.consecutive_failures += 1
                    self._session_reset(keep_prebuf=True)
                    time.sleep(1)

                except Exception:
                    self.consecutive_failures += 1
                    time.sleep(1)

                finally:
                    if response is not None:
                        try:
                            response.close()
                        except Exception:
                            pass
                        response = None

            except Exception as e:
                add_log(f'[PRODUCER] Erro crítico: {type(e).__name__}', 'ERROR')
                self.consecutive_failures += 1
                self._session_reset(keep_prebuf=True)
                time.sleep(1)

        add_log(f'[PRODUCER] Finalizado para stream {self.stream_id}', 'INFO')

    def get_chunk(self, timeout=30.0):
        try:
            return self.data_queue.get(timeout=timeout)
        except queue.Empty:
            # Retorna pacotes nulos para manter a conexão viva (keep-alive)
            return self._null_packet * 7

class TSHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, format, *args):
        pass

    def handle(self):
        try:
            super().handle()
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass
        except Exception:
            pass

    def do_GET(self):
        path = self.path

        if path == '/health':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                "status":        "ok",
                "engines":       stats.active_engines,
                "clients":       stats.total_clients,
                "reconnections": stats.total_reconnections,
            }).encode())
            return

        legacy_mode = False
        sid = stream_id = None

        if path.startswith('/stream') and '?url=' in path:
            legacy_mode = True
            try:
                parsed        = urlparse(path)
                qs            = parse_qs(parsed.query)
                remote_ts_url = qs.get('url', [None])[0]
                if not remote_ts_url:
                    raise ValueError("Missing url parameter")

                rparsed  = urlparse(remote_ts_url)
                parts    = [p for p in rparsed.path.strip('/').split('/') if p]
                fake_host = rparsed.hostname or 'unknown'

                # Formato Xtream Codes com /live/: /live/user/pass/stream_id[.ts]
                if len(parts) >= 3 and parts[0] == 'live':
                    user      = parts[1]
                    password  = parts[2]
                    stream_id = parts[3].replace('.ts', '') if len(parts) >= 4 else ''
                    fake_sid  = f"legacy_{fake_host}_{user[:8] if len(user) > 8 else user}"
                    if not store.get_server(fake_sid):
                        base_url = f"{rparsed.scheme}://{rparsed.netloc}"
                        add_server_config(fake_sid, f"Legacy {fake_host}", base_url, user, password)
                        add_log(f"[LEGACY] Servidor auto-registrado (Xtream): {fake_sid}", 'INFO')

                # Formato sem /live/: /user/pass/stream_id[.ts]
                elif len(parts) >= 3:
                    user      = parts[0]
                    password  = parts[1]
                    stream_id = parts[2].replace('.ts', '')
                    fake_sid  = f"legacy_{fake_host}_{user[:8] if len(user) > 8 else user}"
                    if not store.get_server(fake_sid):
                        base_url = f"{rparsed.scheme}://{rparsed.netloc}"
                        add_server_config(fake_sid, f"Legacy {fake_host} (direto)", base_url, user, password)
                        add_log(f"[LEGACY] Servidor auto-registrado (direto): {fake_sid}", 'INFO')

                else:
                    raise ValueError(f"URL inválida, partes insuficientes: {parts}")

                sid = fake_sid
                add_log(f"[LEGACY] URL parseada → sid={fake_sid} stream={stream_id}")
            except Exception as e:
                add_log(f"[LEGACY] Erro parsing: {e}", 'ERROR')
                self.send_error(400, "Legacy URL parse failed")
                return

        elif path.startswith('/live/'):
            try:
                parts     = path.split('/')
                sid       = parts[2]
                stream_id = parts[-1].replace('.ts', '')
            except Exception:
                self.send_error(400, "Bad Request")
                return
        else:
            self.send_error(404, "Not Found")
            return

        server = store.get_server(sid)
        if not server or not server.get('active', True):
            self.send_error(404, "Server not found or inactive")
            return

        client_id = str(uuid.uuid4())
        add_log(f"[STREAM] Cliente {client_id[:8]} → {server['name']} / stream {stream_id} {'(LEGACY)' if legacy_mode else ''}")

        try:
            engine = stream_manager.register_client(sid, stream_id, client_id)
        except Exception as e:
            self.send_error(500, str(e))
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'keep-alive')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        try:
            if not engine.prebuf_ready.wait(timeout=15.0):
                self.wfile.write(engine._null_packet * 20)
                self.wfile.flush()

            _last_data_time = time.time()
            while True:
                chunk = engine.get_chunk(timeout=45.0)
                if chunk:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                    _last_data_time = time.time()
                # Lógica de keep-alive removida para "nunca fechar"
                # O get_chunk já retorna nulos, mantendo o fluxo.
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            pass
        except Exception:
            pass
        finally:
            stream_manager.unregister_client(sid, stream_id, client_id)

class ProxyServer:
    def __init__(self):
        self.server        = None
        self.server_thread = None
        self.port          = None
        self._lock         = threading.Lock()
        self._running      = False

    def start(self, port=0, host='127.0.0.1'):
        with self._lock:
            if self._running:
                return self.port
            self.server = ThreadedHTTPServer((host, port), TSHandler)
            try:
                self.server.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            except Exception:
                pass
            self.port          = self.server.server_address[1]
            self.server_thread = threading.Thread(
                target=self.server.serve_forever, daemon=True)
            self.server_thread.start()
            self._running = True
            add_log(f"Servidor iniciado em {host}:{self.port}")
            return self.port

    def stop(self):
        with self._lock:
            if not self._running:
                return
            add_log("Desligando servidor...")
            stream_manager.force_stop_all()
            self.server.shutdown()
            self.server.server_close()
            self._running = False
            self.port     = None

    def is_running(self):
        return self._running

_server_instance = ProxyServer()

def get_free_port(start_port=49200, max_tries=100):
    if _server_instance.is_running():
        return _server_instance.port
    for offset in range(max_tries):
        test_port = start_port + offset
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(('127.0.0.1', test_port))
            sock.close()
            if result != 0:
                return start_server(port=test_port, host='127.0.0.1')
        except Exception:
            continue
    return start_server(port=0, host='127.0.0.1')

def start_server(port=None, host='127.0.0.1'):
    if port is None:
        port = DEFAULT_PORT
    return _server_instance.start(port=port, host=host)

def stop_server():
    _server_instance.stop()

def add_server_config(sid, name, url, user, password):
    return store.add_server(sid, name, url, user, password)


class TSProxyServer:
    def __init__(self, port=None, host='127.0.0.1'):
        if port and _server_instance.is_running() and _server_instance.port == port:
            self.port = port
            self.host = host
        else:
            self.port = _server_instance.start(port=port or 0, host=host)
            self.host = host

    def get_stream_url(self, sid, stream_id):
        return f"http://{self.host}:{self.port}/live/{sid}/{stream_id}.ts"

    def start(self, port=None, host=None):
        if _server_instance.is_running():
            self.port = _server_instance.port
            return self.port
        use_port = port or self.port or 0
        use_host = host or self.host or '127.0.0.1'
        self.port = _server_instance.start(port=use_port, host=use_host)
        self.host = use_host
        return self.port

    def stop(self):
        _server_instance.stop()

    def is_running(self):
        return _server_instance.is_running()

    def get_port(self):
        return self.port

    def get_stats(self):
        return {
            "port":                self.port,
            "active_engines":      stats.active_engines,
            "total_clients":       stats.total_clients,
            "total_reconnections": stats.total_reconnections,
            "total_transmitted_mb": round(stats.total_transmitted / 1024 / 1024, 2),
        }

def _probe_port(port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('127.0.0.1', port))
        s.close()
        return True
    except (PermissionError, OSError):
        return False


def _find_bindable_port(candidates=(49200, 50000, 51000, 52000, 53000,
                                    54000, 55000, 56000, 57000, 58000)):
    for base in candidates:
        for offset in range(50):
            p = base + offset
            if _probe_port(p):
                return p
    raise RuntimeError("Nenhuma porta disponível para bind em 127.0.0.1")


def _ensure_server_running():
    if _server_instance.is_running():
        return _server_instance.port
    port = _find_bindable_port()
    return start_server(port=port, host='127.0.0.1')


def handle_play(params, handle):
    try:
        import xbmcplugin
        import xbmcgui
    except ImportError:
        add_log("[ROUTER] Módulos Kodi não disponíveis (execução fora do Kodi)", 'WARNING')
        return

    remote_url = params.get('url', [None])[0]
    if not remote_url:
        add_log("[ROUTER] action=play sem parâmetro url", 'ERROR')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    add_log(f"[ROUTER] action=play → {remote_url[:80]}", 'INFO')

    try:
        proxy_port = _ensure_server_running()
    except Exception as e:
        add_log(f"[ROUTER] Falha ao iniciar servidor: {e}", 'ERROR')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    local_url = f"http://127.0.0.1:{proxy_port}/stream?url={quote(remote_url, safe='')}"
    add_log(f"[ROUTER] URL proxy local → {local_url}", 'INFO')

    li = xbmcgui.ListItem(path=local_url)
    li.setMimeType('video/mp2t')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, li)


def _router():
    if len(sys.argv) < 3:
        return

    handle = int(sys.argv[1])
    params = parse_qs(sys.argv[2].lstrip('?'))
    action = params.get('action', [None])[0]

    if action == 'play':
        handle_play(params, handle)
    else:
        try:
            import xbmcplugin
            import xbmcgui
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        except ImportError:
            pass

def _is_kodi_context():
    return (
        len(sys.argv) >= 1 and
        isinstance(sys.argv[0], str) and
        sys.argv[0].startswith('plugin://')
    )

# --- MODO CURL IMPLEMENTADO ---
def run_curl_mode(url):
    """
    Modo Curl: Conecta diretamente a uma URL e exibe o stream no stdout.
    Reconecta automaticamente e nunca fecha a reprodução.
    """
    add_log(f"[CURL] Iniciando modo curl para: {url}", 'INFO', force_silent=True)
    
    # Cria um motor direto sem passar pelo gerenciador/servidor HTTP
    engine = TSEngine("curl_stream", url)
    engine.start()
    
    try:
        # Aguarda prebuffer inicial
        if not engine.prebuf_ready.wait(timeout=20.0):
            add_log("[CURL] Timeout no prebuffer inicial, iniciando mesmo assim...", 'WARNING', force_silent=True)
        
        while True:
            # Get_chunk já lida com reconexão interna e envia nulos se necessário
            chunk = engine.get_chunk(timeout=30.0)
            if chunk:
                # Escreve diretamente no stdout (binário)
                sys.stdout.buffer.write(chunk)
                sys.stdout.buffer.flush()
                
    except KeyboardInterrupt:
        add_log("\n[CURL] Interrompido pelo usuário.", 'INFO', force_silent=True)
    except Exception as e:
        add_log(f"[CURL] Erro fatal: {e}", 'ERROR', force_silent=True)
    finally:
        engine.stop()

if __name__ == "__main__":
    # Verifica se é contexto Kodi
    if _is_kodi_context():
        _router()
    else:
        # Verifica argumentos de linha de comando
        if len(sys.argv) > 1:
            arg1 = sys.argv[1]
            # Se o argumento parece uma URL, entra no modo Curl
            if arg1.startswith("http://") or arg1.startswith("https://"):
                run_curl_mode(arg1)
            else:
                # Se não for URL, assume que é uma porta e inicia o servidor
                try:
                    port = int(arg1)
                    print(f"Iniciando Nexus Core MPEG-TS Proxy na porta {port}...")
                    start_server(port=port, host='127.0.0.1')
                    while True:
                        time.sleep(1)
                except ValueError:
                    print(f"Argumento inválido: {arg1}. Use uma URL para modo Curl ou uma porta para modo Servidor.")
                except KeyboardInterrupt:
                    stop_server()
                    print("Servidor encerrado.")
        else:
            # Sem argumentos: inicia servidor na porta padrão
            print("Uso:")
            print("  python tsproxy.py <porta>       -> Inicia servidor proxy na porta especificada")
            print("  python tsproxy.py <url>         -> Modo Curl: exibe stream da URL no stdout")
            print("\nIniciando servidor na porta padrão 8010...")
            try:
                start_server(port=8010, host='127.0.0.1')
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                stop_server()
                print("Servidor encerrado.")