#!/usr/bin/env python3

import sys
import os
import re

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if _ADDON_DIR not in sys.path:
    sys.path.insert(0, _ADDON_DIR)

from urllib.parse import parse_qs, quote, urlparse, urlunparse

_RE_NUMERIC_END = re.compile(r'/\d+$')


def _path_only(url):
    return urlparse(url).path.lower()


def _is_hls(url):
    return _path_only(url).endswith('.m3u8')


def _is_ts_explicit(url):
    return _path_only(url).endswith('.ts')


def _is_ts_no_ext(url):
    return bool(_RE_NUMERIC_END.search(_path_only(url)))


def _url_type(url):
    if _is_hls(url):          return 'hls'
    if _is_ts_explicit(url):  return 'ts_ext'
    if _is_ts_no_ext(url):    return 'ts_noext'
    return 'unknown'


def _convert_to_ts(url):
    t = _url_type(url)
    parsed = urlparse(url)

    if t == 'ts_ext':
        path_parts = [p for p in parsed.path.split('/') if p]
        if path_parts and path_parts[0].lower() != 'live':
            path_parts.insert(0, 'live')
            new_path = '/' + '/'.join(path_parts)
            return urlunparse(parsed._replace(path=new_path))
        return url

    path_parts = [p for p in parsed.path.split('/') if p]
    
    if path_parts and path_parts[0].lower() != 'live':
        path_parts.insert(0, 'live')

    base_path = '/' + '/'.join(path_parts)

    if t == 'hls':
        new_path = base_path[:-5] + '.ts'
    else:
        new_path = base_path + '.ts'
        
    return urlunparse(parsed._replace(path=new_path))


def _convert_to_hls(url):
    t = _url_type(url)
    parsed = urlparse(url)

    if t == 'hls':
        return url

    if t == 'ts_ext':
        return urlunparse(parsed._replace(path=parsed.path[:-3] + '.m3u8'))

    path_parts = [p for p in parsed.path.split('/') if p]
    
    if path_parts and path_parts[0].lower() != 'live':
        path_parts.insert(0, 'live')
        
    new_path = '/' + '/'.join(path_parts) + '.m3u8'
    return urlunparse(parsed._replace(path=new_path))


_TYPE_LABELS = {
    'hls':      'HLS (.m3u8)',
    'ts_ext':   'MPEG-TS (.ts)',
    'ts_noext': 'MPEG-TS (sem extensão)',
    'unknown':  'stream',
}


def _url_type_label(url):
    return _TYPE_LABELS.get(_url_type(url), 'stream')


def _dialog_choose_proxy(url):
    import xbmcgui

    label = _url_type_label(url)
    dialog = xbmcgui.Dialog()
    opcoes = [
        'Proxy MPEG-TS  (tsproxy)',
        'Proxy HLS  (hlsproxy)',
    ]
    return dialog.select(
        f'NEXUS CORE — Escolha o Proxy  [{label}]',
        opcoes
    )


def _play_ts(handle, url):
    import xbmcplugin
    import xbmcgui
    import xbmc

    url_final = _convert_to_ts(url)
    if url_final != url:
        xbmc.log(f'[NexusCore] Convertido para TS: {url_final}', xbmc.LOGINFO)
    xbmc.log(f'[NexusCore] tsproxy ← {url_final[:120]}', xbmc.LOGINFO)

    try:
        import tsproxy
        proxy_port = tsproxy._ensure_server_running()
    except Exception as e:
        xbmc.log(f'[NexusCore] Falha ao iniciar tsproxy: {e}', xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    local_url = (
        f'http://127.0.0.1:{proxy_port}/stream'
        f'?url={quote(url_final, safe="")}'
    )
    xbmc.log(f'[NexusCore] tsproxy local: {local_url}', xbmc.LOGINFO)

    li = xbmcgui.ListItem(path=local_url)
    li.setMimeType('video/mp2t')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, li)


def _play_hls(handle, url):
    import xbmcplugin
    import xbmcgui
    import xbmc

    url_final = _convert_to_hls(url)
    if url_final != url:
        xbmc.log(f'[NexusCore] Convertido para HLS: {url_final}', xbmc.LOGINFO)
    xbmc.log(f'[NexusCore] hlsproxy ← {url_final[:120]}', xbmc.LOGINFO)

    try:
        import hlsproxy
        addon = hlsproxy.HLSAddon(addon_handle=handle)
    except Exception as e:
        xbmc.log(f'[NexusCore] Falha ao iniciar hlsproxy: {e}', xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    try:
        addon.play_stream(url_final)
    except Exception as e:
        xbmc.log(f'[NexusCore] Erro em hlsproxy.play_stream: {e}', xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _action_play(handle, params):
    import xbmcplugin
    import xbmcgui
    import xbmc

    url = params.get('url', [None])[0]
    if not url:
        xbmc.log('[NexusCore] action=play sem parâmetro url', xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    tipo = _url_type(url)
    xbmc.log(f'[NexusCore] action=play tipo={tipo} url={url[:120]}', xbmc.LOGINFO)

    proxy_type = params.get('proxy_type', [None])[0]

    if proxy_type == 'ts':
        escolha = 0
    elif proxy_type == 'hls':
        escolha = 1
    else:
        escolha = _dialog_choose_proxy(url)

    if escolha == -1:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    elif escolha == 0:
        _play_ts(handle, url)
    elif escolha == 1:
        _play_hls(handle, url)
    else:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _router():
    if len(sys.argv) < 3:
        return

    handle = int(sys.argv[1])
    raw_params = sys.argv[2].lstrip('?')
    params = parse_qs(raw_params)
    action = params.get('action', [None])[0]

    if action == 'play':
        _action_play(handle, params)
    else:
        try:
            import xbmcplugin
            import xbmcgui
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        except Exception:
            pass


if __name__ == '__main__':
    _router()