import sys
import six
import os
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
if six.PY3:
    from urllib.parse import unquote, quote_plus, unquote_plus, urlencode  # Python 3
    from urllib.request import Request, urlopen, URLError  # Python 3
else:
    from urllib import unquote, quote_plus, unquote_plus, urlencode
    from urllib2 import Request, urlopen, URLError  # Python 2
import re
import time
import server
import threading
import requests

plugin = sys.argv[0]
handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addonid = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
fanart_default = os.path.join(home, 'fanart.png')
dialog = xbmcgui.Dialog()

def route(f):
    action_f = f.__name__
    params_dict = {}
    param_string = sys.argv[2]
    if param_string:
        split_commands = param_string[param_string.find('?') + 1:].split('&')
        for command in split_commands:
            if len(command) > 0:
                if "=" in command:
                    split_command = command.split('=')
                    key = split_command[0]
                    value = split_command[1]
                    try:
                        key = unquote_plus(key)
                    except:
                        pass
                    try:
                        value = unquote_plus(value)
                    except:
                        pass
                    params_dict[key] = value
                else:
                    params_dict[command] = ""
    action = params_dict.get('action')
    url = params_dict.get('url')
    if action is None and action_f == 'main':
        f()
    elif url and action is None and action_f == 'playitem':
        f(params_dict)
    elif action == action_f:
        f(params_dict)

def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, iconimage, time, sound=sound)

def SetView(name):
    try:
        view_map = {
            'Wall': 500,
            'List': 50,
            'Poster': 51,
            'Shift': 53,
            'InfoWall': 54,
            'WideList': 55,
            'Fanart': 502
        }
        view_id = view_map.get(name)
        if view_id:
            xbmc.executebuiltin('Container.SetViewMode(%d)' % view_id)
    except Exception:
        pass

def get_kversion():
    full_version_info = xbmc.getInfoLabel('System.BuildVersion')
    baseversion = full_version_info.split(".")
    try:
        intbase = int(baseversion[0])
    except Exception:
        intbase = 17  # Fallback safe
    return intbase

def get_url(params):
    if params:
        url = '%s?%s' % (plugin, urlencode(params))
    else:
        url = ''
    return url

def item(params, folder=True):
    u = get_url(params)
    name = params.get("name", "Unknown")
    iconimage = params.get("iconimage") or params.get("iconImage", icon)
    fanart = params.get("fanart", fanart_default)
    description = params.get("description", '')
    playable = params.get("playable")
    liz = xbmcgui.ListItem(name)
    liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    if get_kversion() > 19:
        info = liz.getVideoInfoTag()
        info.setTitle(name)
        info.setMediaType('video')
        info.setPlot(description)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
    if playable == 'true':
        liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
    return ok

class MyPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
    def play(self, url, listitem):
        xbmc.Player().play(url, listitem)

def monitor():
    while True:
        if not xbmc.Player().isPlaying():
            server.req_shutdown()
            break

def req(url):
    try:
        r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'}, timeout=20)
        return r.text
    except:
        return ''

def re_me(data, re_patten):
    m = re.search(re_patten, data)
    if m:
        return m.group(1)
    return ''

@route
def playlist(param):
    url = param.get('url', '')
    infoDialog('Loading, wait...', iconimage='INFO')
    data = req(url)
    if re.search("#EXTM3U", data) or re.search("#EXTINF", data):
        xbmcplugin.setContent(handle, 'videos')
        content = data.rstrip()
        match1 = re.compile(r'#EXTINF:.+?tvg-logo="(.*?)".+?group-title="(.*?)",(.*?)[\n\r]+([^\r\n]+)').findall(content)
        if match1:
            group_list = []
            for thumbnail, cat, channel_name, stream_url in match1:
                if not any(ext in stream_url for ext in ['.mp4', '.mkv', '.avi', '.wmv', '.mp3']):
                    if cat not in group_list:
                        group_list.append(cat)
                        item({'name': cat, 'action': 'playlist2', 'url': url, 'iconimage': ''})
        else:
            match2 = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)').findall(content)
            group_list = []
            if match2:
                for other, channel_name, stream_url in match2:
                    if not any(ext in stream_url for ext in ['.mp4', '.mkv', '.avi', '.wmv', '.mp3']):
                        thumbnail = re_me(other, 'tvg-logo=[\'"](.*?)[\'"]') if 'tvg-logo' in other else ''
                        cat = re_me(other, 'group-title=[\'"](.*?)[\'"]') if 'group-title' in other else ''
                        if cat:
                            if cat not in group_list:
                                group_list.append(cat)
                                item({'name': cat, 'action': 'playlist2', 'url': url, 'iconimage': ''})
                        else:
                            stream_url = stream_url.replace(' ', '').replace('\r', '').replace('\n', '')
                            item({'name': channel_name, 'action': 'playitem', 'url': stream_url, 'iconimage': thumbnail}, folder=False)
            else:
                infoDialog('Playlist indisponivel', iconimage='INFO')
        xbmcplugin.endOfDirectory(handle)

@route
def playlist2(param):
    name = param.get('name', '')
    url = param.get('url', '')
    infoDialog('Loading, Wait...', iconimage='INFO')
    data = req(url)
    if re.search("#EXTM3U", data) or re.search("#EXTINF", data):
        xbmcplugin.setContent(handle, 'videos')
        content = data.rstrip()
        match1 = re.compile(r'#EXTINF:.+?tvg-logo="(.*?)".+?group-title="(.*?)",(.*?)[\n\r]+([^\r\n]+)').findall(content)
        if match1:
            for thumbnail, cat, channel_name, stream_url in match1:
                if not any(ext in stream_url for ext in ['.mp4', '.mkv', '.avi', '.wmv', '.mp3']):
                    if cat == name:
                        stream_url = stream_url.replace(' ', '').replace('\r', '').replace('\n', '')
                        item({'name': channel_name, 'action': 'playitem', 'url': stream_url, 'iconImage': thumbnail}, folder=False)
        else:
            match2 = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)').findall(content)
            if match2:
                for other, channel_name, stream_url in match2:
                    if not any(ext in stream_url for ext in ['.mp4', '.mkv', '.avi', '.wmv', '.mp3']):
                        thumbnail = re_me(other, 'tvg-logo=[\'"](.*?)[\'"]') if 'tvg-logo' in other else ''
                        cat = re_me(other, 'group-title=[\'"](.*?)[\'"]') if 'group-title' in other else ''
                        if cat == name:
                            stream_url = stream_url.replace(' ', '').replace('\r', '').replace('\n', '')
                            item({'name': channel_name, 'mode': 'playitem', 'url': stream_url, 'iconImage': thumbnail}, folder=False)
            else:
                infoDialog('Playlist indisponivel', iconimage='INFO')
        xbmcplugin.endOfDirectory(handle)

@route
def main():
    xbmcplugin.setContent(handle, 'movies')
    item({'name': 'My playlists', 'action': 'myplaylists'})
    item({'name': 'Add Playlist', 'action': 'settings'})
    xbmcplugin.endOfDirectory(handle)
    SetView('WideList')

@route
def myplaylists(param):
    listas_disponiveis = []
    for i in range(1, 11):
        tag = 'lista' + str(i)
        if 'http' in addon.getSetting(tag):
            listas_disponiveis.append(addon.getSetting(tag))
    if listas_disponiveis:
        for n, i in enumerate(listas_disponiveis, 1):
            name = 'LISTA ' + str(n)
            item({'name': name, 'action': 'playlist', 'url': i})
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')
    else:
        infoDialog('No playlist added', iconimage='INFO')

@route
def settings(param):
    addon.openSettings()

@route
def playitem(param):
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    name = param.get('name', '')
    url = param.get('url', '')
    iconimage = param.get('iconImage', '') or param.get('iconimage', '')

    stop_flag = threading.Event()

    class MyMonitor(xbmc.Monitor):
        def onAbortRequested(self):
            stop_flag.set()

    def start_playback(playback_url, playback_name, playback_iconimage):
        if 'plugin://' in playback_url:
            xbmc.executebuiltin('RunPlugin(%s)' % playback_url)
        else:
            url_to_play = server.prepare_url(playback_url)
            infoDialog('ABRINDO O CANAL...', iconimage='INFO')
            media_server_instance = server.MediaServer()
            if not media_server_instance.is_in_use():
                media_server_instance.start()
                time.sleep(1)
            if not playback_name:
                playback_name = 'F4mTester'

            liz = xbmcgui.ListItem(playback_name)
            liz.setPath(url_to_play)
            if playback_iconimage:
                liz.setArt({"icon": playback_iconimage, "thumb": playback_iconimage})
            else:
                liz.setArt({"icon": icon, "thumb": icon})
            if get_kversion() > 19:
                info = liz.getVideoInfoTag()
                info.setTitle(playback_name)
            else:
                liz.setInfo(type='video', infoLabels={'Title': playback_name})
            liz.setMimeType("application/vnd.apple.mpegurl")
            liz.setContentLookup(False)
            xbmc.Player().play(url_to_play, liz)

    def monitor_and_reconnect(original_url, original_name, original_iconimage, max_retries=5, retry_delay=5):
        monitor = MyMonitor()
        player = xbmc.Player()
        retries = 0
        while not stop_flag.is_set():
            time.sleep(2)
            if not player.isPlaying():
                # Se foi parada manual (stop_flag), não reconecta
                if stop_flag.is_set() or xbmc.abortRequested:
                    break
                # Testa se o servidor do canal está online antes de tentar reconectar
                try:
                    resp = requests.head(original_url, timeout=5)
                    if resp.status_code >= 400:
                        infoDialog('Canal offline ou servidor indisponível.', iconimage='ERROR')
                        server.req_shutdown()
                        break
                except Exception:
                    infoDialog('Canal offline ou servidor indisponível.', iconimage='ERROR')
                    server.req_shutdown()
                    break
                # Se desconectou prematuramente, tenta reconectar
                if retries < max_retries:
                    retries += 1
                    infoDialog(f'Conexão perdida. Tentando reconectar ({retries}/{max_retries})...', iconimage='WARNING', time=2000)
                    server.req_shutdown()
                    time.sleep(retry_delay)
                    start_playback(original_url, original_name, original_iconimage)
                else:
                    infoDialog('Não foi possível reconectar após várias tentativas.', iconimage='ERROR')
                    server.req_shutdown()
                    break

    start_playback(url, name, iconimage)
    t2 = threading.Thread(target=monitor_and_reconnect, args=(url, name, iconimage))
    t2.daemon = True
    t2.start()