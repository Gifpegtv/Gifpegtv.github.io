import six
import os
import threading
import socket
import requests
import time
import json
import collections
import re
import ipaddress
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import logging
import socketserver
from queue import Queue, Empty

# ========== LOGGING CONFIGURATION ==========
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode
except ImportError:
    from urlparse import urlparse, parse_qs
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from SimpleHTTPServer import SimpleHTTPRequestHandler

class ThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 65321
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

ALLOWED_HEADERS = [
    "User-Agent", "Referer", "Origin", "Cookie", "Accept", "Accept-Language",
    "Range", "Connection", "Accept-Encoding", "Accept-Charset", "Host", "Authorization",
    "X-Requested-With", "Sec-Fetch-Mode", "Sec-Fetch-User", "Sec-Fetch-Site", "Sec-Fetch-Dest",
    "DNT", "Pragma", "Cache-Control", "Upgrade-Insecure-Requests", "TE", "Accept-Range",
    "If-None-Match", "If-Modified-Since", "X-Playback-Session-Id", "X-Session-Id", "X-Device-User-Agent",
    "X-Client-Data", "X-Apple-Request-UUID", "X-Plex-Client-Identifier", "X-Plex-Device",
    "X-Plex-Platform", "X-Plex-Version",
]

BLACKLIST_HEADERS = [
    "X-Forwarded-For", "Via", "X-Real-IP", "Proxy-Connection", "X-ProxyUser", "X-Proxy-Id"
]

MEMORY_CACHE_LIMIT_BYTES = 50 * 1024 * 1024  # 50 MB
ADAPTIVE_PREFETCH_THREADS = 2

class SegmentPrefetcher(threading.Thread):
    def __init__(self, queue, buffer, headers, session):
        super(SegmentPrefetcher, self).__init__()
        self.queue = queue
        self.buffer = buffer
        self.headers = headers
        self.session = session
        self.daemon = True
        self.running = True

    def run(self):
        while self.running:
            try:
                url, seq, duration = self.queue.get(timeout=1)
            except Empty:
                continue
            if not self.buffer.get_segment(url):
                try:
                    r = self.session.get(url, headers=self.headers, stream=True, timeout=10)
                    r.raise_for_status()
                    content = b''
                    for chunk in r.iter_content(chunk_size=16384):
                        if chunk:
                            content += chunk
                    r.close()
                    self.buffer.add_segment(url, content, time.time(), seq)
                    logger.debug(f"Prefetched {url} (size: {len(content)} bytes)")
                except Exception as e:
                    logger.warning(f"Prefetch failed for {url}: {e}")
            self.queue.task_done()

    def stop(self):
        self.running = False

class AdaptiveStreamBuffer:
    def __init__(self, max_size_bytes=MEMORY_CACHE_LIMIT_BYTES):
        self.lock = threading.Lock()
        self.segments = collections.OrderedDict()
        self.max_size_bytes = max_size_bytes
        self.current_size_bytes = 0
        self.segment_duration = 6.0
        self.last_segment_timestamp = 0.0
        self.prefetch_queue = Queue(maxsize=30)
        self.prefetch_threads = []
        self.active = True
        self.prefetch_headers = {}
        self.prefetch_session = None
        logger.info(f"Cache em memória inicializado com um limite de {self.max_size_bytes / 1024 / 1024:.2f} MB.")
        self._start_prefetchers()

    def _start_prefetchers(self):
        self.stop_prefetchers()
        self.prefetch_threads = []
        for _ in range(ADAPTIVE_PREFETCH_THREADS):
            thread = SegmentPrefetcher(self.prefetch_queue, self, self.prefetch_headers, self.prefetch_session or requests.Session())
            thread.start()
            self.prefetch_threads.append(thread)

    def set_prefetch_context(self, headers, session):
        self.prefetch_headers = headers
        self.prefetch_session = session
        self._start_prefetchers()

    def stop_prefetchers(self):
        for thread in self.prefetch_threads:
            thread.stop()
        for thread in self.prefetch_threads:
            thread.join()
        self.prefetch_threads = []

    def add_segment(self, url, data, timestamp=None, sequence_number=None):
        with self.lock:
            segment_size = len(data)
            if segment_size > self.max_size_bytes:
                logger.warning(f"Segmento {url} (size: {segment_size} bytes) é maior que o limite do cache ({self.max_size_bytes} bytes) e não será adicionado.")
                return

            while (self.current_size_bytes + segment_size) > self.max_size_bytes and self.segments:
                evicted_url, (evicted_data, _, _) = self.segments.popitem(last=False)
                evicted_size = len(evicted_data)
                self.current_size_bytes -= evicted_size
                logger.info(f"Cache cheio. Removendo segmento mais antigo: {evicted_url} (size: {evicted_size} bytes) para liberar espaço.")

            ts = timestamp if timestamp is not None else time.time()
            self.segments[url] = (data, ts, sequence_number)
            self.current_size_bytes += segment_size
            self.last_segment_timestamp = ts
            logger.debug(f"Segmento {url} adicionado. Tamanho do cache atual: {self.current_size_bytes / 1024 / 1024:.2f} MB")

    def get_segment(self, url):
        with self.lock:
            return self.segments.get(url)

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.current_size_bytes = 0
            self.last_segment_timestamp = 0.0
            while not self.prefetch_queue.empty():
                try:
                    self.prefetch_queue.get_nowait()
                except Empty:
                    pass
            logger.info("Cache em memória foi limpo.")

    def destroy(self):
        self.stop_prefetchers()
        self.clear()
        logger.info("Buffer de stream e prefetchers foram destruídos.")

    def fill_prefetch(self, segment_urls, headers, session):
        self.set_prefetch_context(headers, session)
        for (url, seq, duration) in segment_urls:
            if not self.get_segment(url):
                try:
                    self.prefetch_queue.put_nowait((url, seq, duration))
                except:
                    pass

    def get_all_segments(self):
        with self.lock:
            return list(self.segments.items())

stream_buffer = AdaptiveStreamBuffer()
GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}
GLOBAL_URL = ''
_media_server_instance = None

def filter_headers(headers):
    filtered = {}
    for k, v in headers.items():
        if k in ALLOWED_HEADERS and k not in BLACKLIST_HEADERS:
            filtered[k] = v
    return filtered

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.debug(format % args)

    _session = None
    active_connections = collections.defaultdict(int)
    MAX_CONNECTIONS_PER_IP = 3

    @classmethod
    def get_session(cls):
        if cls._session is None:
            retry_strategy = Retry(
                total=3,
                backoff_factor=1,
                status_forcelist=[429, 500, 502, 503, 504],
                allowed_methods=["HEAD", "GET", "OPTIONS"]
            )
            adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=20, pool_maxsize=20)
            cls._session = requests.Session()
            cls._session.mount("http://", adapter)
            cls._session.mount("https://", adapter)
        return cls._session

    def _get_client_ip(self):
        try:
            if hasattr(self, 'client_address'):
                return self.client_address[0]
        except Exception:
            return "unknown"
        return "unknown"

    def _reset_stream_state(self):
        global GLOBAL_HEADERS, GLOBAL_URL
        logger.info("Resetando estado do stream global (headers e base URL).")
        GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}
        stream_buffer.clear()
        GLOBAL_URL = ''

    def _get_parsed_url_param(self):
        try:
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            raw_param = query_params.get('url', [None])[0]
            if raw_param:
                decoded_param = unquote_plus(raw_param)
                decoded_param = unquote(decoded_param)
                return decoded_param
            return None
        except Exception as e:
            logger.error(f"Erro ao decodificar parâmetro URL '{self.path}': {e}")
            return None

    def get_headers_from_url_params(self, url_with_params):
        custom_headers = {}
        try:
            header_str = None
            if '|' in url_with_params:
                parts = url_with_params.split('|', 1)
                url_with_params = parts[0]
                if len(parts) > 1:
                    header_str = parts[1]
            elif '&h123' in url_with_params:
                parts = url_with_params.split('&h123', 1)
                url_with_params = parts[0]
                if len(parts) > 1:
                    header_str = parts[1]
            if header_str:
                for part in header_str.split('&'):
                    if '=' in part:
                        key, value = part.split('=', 1)
                        key = unquote_plus(key).strip()
                        value = unquote_plus(value).strip()
                        if key in ALLOWED_HEADERS and key not in BLACKLIST_HEADERS:
                            custom_headers[key] = value
            parsed_param_url = urlparse(url_with_params)
            params_qs = parse_qs(parsed_param_url.query)
            for h_key in ALLOWED_HEADERS:
                if h_key in params_qs and h_key not in BLACKLIST_HEADERS:
                    custom_headers[h_key] = unquote_plus(params_qs[h_key][0])
        except Exception as e:
            logger.debug(f"Erro ao parsear cabeçalhos de '{url_with_params}': {e}")
        return custom_headers

    def clean_url_from_headers_params(self, url):
        if '|' in url:
            url = url.split('|')[0]
        elif '&h123' in url:
            url = url.split('&h123')[0]
        parsed = urlparse(url)
        query_params = parse_qs(parsed.query)
        clean_query = {}
        for key, value in query_params.items():
            if key not in [k for k in ALLOWED_HEADERS]: 
                clean_query[key] = value
        if clean_query:
            return parsed._replace(query=urlencode(clean_query, doseq=True)).geturl()
        else:
            return parsed._replace(query='').geturl()

    def convert_to_m3u8_url(self, url):
        if '|' in url:
            url = url.split('|')[0]
        elif '%7C' in url:
            url = url.split('%7C')[0]
        if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
            parsed_url = urlparse(url)
            try:
                host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                url = host_part1 + '/live' + host_part2
                
                # Adaptando a função 'basename' do hlsretry.py
                i = url.rfind('/') + 1
                file = url[i:]
                
                if '.ts' in file:
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                else:
                    url = url + '.m3u8'
            except:
                pass
        return url

    # ==================== ALTERAÇÃO PRINCIPAL ====================
    # Remove DoH, faz requisições sempre pelo hostname original.
    def _make_request_upstream(self, url, headers, stream=False, head=False, timeout=10):
        effective_headers = filter_headers(headers)
        for k in list(effective_headers.keys()):
            if k in BLACKLIST_HEADERS:
                del effective_headers[k]
        s = self.get_session()
        try:
            if head:
                response = s.head(url, headers=effective_headers, timeout=timeout, allow_redirects=True)
            else:
                response = s.get(url, headers=effective_headers, stream=stream, timeout=timeout, allow_redirects=True)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            logger.error(f"ERRO na requisição para {url}: {e}")
            raise
    # ============================================================

    def handle_one_request(self):
        client_ip = self._get_client_ip()
        if Handler.active_connections[client_ip] >= Handler.MAX_CONNECTIONS_PER_IP:
            self.send_response(429)
            self.send_header('Retry-After', '3')
            self.end_headers()
            self.wfile.write(b"Limite de conexoes simultaneas atingido para seu IP.")
            return
        Handler.active_connections[client_ip] += 1
        try:
            SimpleHTTPRequestHandler.handle_one_request(self)
        finally:
            Handler.active_connections[client_ip] -= 1

    def _handle_ts_request(self, target_url, current_headers):
        global GLOBAL_URL
        if not target_url.startswith('http') and GLOBAL_URL:
            parsed_global = urlparse(GLOBAL_URL)
            if target_url.startswith('/'):
                full_url = f"{parsed_global.scheme}://{parsed_global.netloc}{target_url}"
            else:
                global_path_parts = parsed_global.path.split('/')
                if '.' in global_path_parts[-1]:
                    base_path = '/'.join(global_path_parts[:-1])
                else:
                    base_path = parsed_global.path
                full_url = f"{parsed_global.scheme}://{parsed_global.netloc}{base_path.rstrip('/')}/{target_url}"
            full_url = re.sub(r'(?<!:)/{2,}', '/', full_url)
            logger.debug(f"Resolvendo URL relativa do TS: {target_url} -> {full_url}")
        else:
            full_url = target_url
        buffered_data = stream_buffer.get_segment(full_url)
        if buffered_data:
            logger.info(f"Servindo segmento TS do cache de memória: {full_url}")
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                self.wfile.write(buffered_data[0])
            except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                logger.warning(f"Conexão interrompida ao enviar TS do buffer: {e}")
            return

        logger.info(f"Segmento TS não encontrado no buffer, buscando na origem: {full_url}")
        try:
            r = self._make_request_upstream(full_url, current_headers, stream=True, timeout=10)
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            segment_data = b''
            for chunk in r.iter_content(chunk_size=16384):
                if chunk:
                    segment_data += chunk
                    try:
                        self.wfile.write(chunk)
                    except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                        logger.warning(f"Conexão interrompida ao enviar TS: {e}")
                        r.close()
                        return
            r.close()
            stream_buffer.add_segment(full_url, segment_data, time.time(), sequence_number=None)
        except requests.exceptions.RequestException as e:
            logger.error(f"Falha ao buscar segmento TS {full_url}: {e}")
            self.send_error(404, f"Falha ao buscar TS: {e}")
        except Exception as e:
            logger.exception(f"ERRO inesperado ao processar TS {full_url}: {e}")
            self.send_error(500, f"Erro interno ao processar TS: {e}")

    def _handle_m3u8_request(self, target_url, current_headers):
        global GLOBAL_URL
        try:
            r = self._make_request_upstream(target_url, current_headers, timeout=10)
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            playlist_content = r.text
            parsed_response_url = urlparse(r.url)
            path_parts = parsed_response_url.path.split('/')
            if len(path_parts) > 1 and ('.' in path_parts[-1] or path_parts[-1] == ''):
                base_path_for_segments = '/'.join(path_parts[:-1])
            else:
                base_path_for_segments = parsed_response_url.path
            if not base_path_for_segments.startswith('/'):
                base_path_for_segments = '/' + base_path_for_segments
            if len(base_path_for_segments) > 1 and base_path_for_segments.endswith('/'):
                base_path_for_segments = base_path_for_segments[:-1]
            GLOBAL_URL = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{base_path_for_segments}"
            logger.info(f"GLOBAL_URL base para segmentos definida como: {GLOBAL_URL}")
            processed_lines = []
            current_segment_duration = 6.0
            original_media_sequence = -1
            segments_in_playlist = []
            lines = playlist_content.splitlines()
            for i, line in enumerate(lines):
                line = line.strip()
                if not line:
                    continue
                if line.startswith('#EXTINF:'):
                    try:
                        duration_match = re.search(r'#EXTINF:([\d.]+),', line)
                        if duration_match:
                            current_segment_duration = float(duration_match.group(1))
                            stream_buffer.segment_duration = current_segment_duration
                    except ValueError:
                        pass
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                    try:
                        original_media_sequence = int(line.split(':')[1])
                        processed_lines.append(line)
                    except ValueError:
                        processed_lines.append(line)
                elif line.startswith('#EXT-X-TARGETDURATION:'):
                    try:
                        td = int(line.split(':')[1])
                        stream_buffer.segment_duration = float(td)
                    except ValueError:
                        pass
                    processed_lines.append(line)
                elif line.startswith('#EXT-X-KEY'):
                    if 'URI="' in line and not '://' in line.split('URI="')[1].split('"')[0]:
                        key_uri_part = line.split('URI="')[1].split('"')[0]
                        if key_uri_part.startswith('/'):
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(parsed_response_url.scheme)}%3A%2F%2F{quote_plus(parsed_response_url.netloc)}{quote_plus(key_uri_part)}"
                        else:
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(GLOBAL_URL.rstrip('/') + '/' + key_uri_part)}"
                        line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri}"')
                        logger.info(f"Chave URI proxyada: {line}")
                    processed_lines.append(line)
                elif line.startswith('#'):
                    processed_lines.append(line)
                else:
                    full_original_segment_url = ""
                    if line.startswith('http://') or line.startswith('https://'):
                        full_original_segment_url = line
                    elif line.startswith('/'):
                        full_original_segment_url = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{line}"
                    else:
                        full_original_segment_url = f"{GLOBAL_URL.rstrip('/')}/{line}"
                    seq = original_media_sequence + len(segments_in_playlist) if original_media_sequence != -1 else None
                    segments_in_playlist.append((full_original_segment_url, seq, current_segment_duration))
                    proxied_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(full_original_segment_url)}"
                    processed_lines.append(proxied_url)
            session = self.get_session()
            stream_buffer.fill_prefetch(segments_in_playlist, current_headers, session)
            final_playlist = "\n".join(processed_lines)
            self.wfile.write(final_playlist.encode("utf-8"))
            r.close()
        except requests.exceptions.RequestException as e:
            logger.error(f"Falha ao buscar M3U8 {target_url}: {e}")
            self.send_error(404, f"Falha ao buscar M3U8: {e}")
        except Exception as e:
            logger.exception(f"ERRO inesperado ao processar M3U8 {target_url}: {e}")
            self.send_error(500, f"Erro interno ao processar M3U8: {e}")

    def _handle_file_request(self, target_url, current_headers):
        try:
            r = self._make_request_upstream(target_url, current_headers, stream=True, timeout=20)
            content_type = r.headers.get('Content-Type', 'application/octet-stream')
            content_length = r.headers.get('Content-Length')
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Access-Control-Allow-Origin', '*')
            if content_length:
                self.send_header('Content-Length', content_length)
            self.end_headers()
            for chunk in r.iter_content(chunk_size=16384):
                if chunk:
                    try:
                        self.wfile.write(chunk)
                    except (socket.error, BrokenPipeError, ConnectionResetError):
                        break
            r.close()
        except Exception as e:
            logger.error(f"Falha ao baixar arquivo genérico {target_url}: {e}")
            self.send_error(404, f"Falha ao baixar arquivo: {e}")

    def _handle_generic_request(self, target_url, current_headers):
        logger.warning(f"Lidando com requisição genérica {target_url} como se fosse arquivo.")
        self._handle_file_request(target_url, current_headers)

    def _shutdown_server(self):
        logger.info("Agendando desligamento do servidor...")
        req_shutdown()

    def _process_request(self, method_is_head=False):
        global GLOBAL_HEADERS, GLOBAL_URL
        original_path = self.path
        if original_path == '/check':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"OK")
            return
        elif original_path == '/stop':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"Stopping server...")
            self._shutdown_server()
            return
        elif original_path == '/buffer_info':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            segments_info = [
                {"url": url, "timestamp": ts, "sequence": seq, "size_bytes": len(data)}
                for url, (data, ts, seq) in stream_buffer.get_all_segments()
            ]
            info = {
                "cache_type": "In-Memory",
                "max_size_mb": stream_buffer.max_size_bytes / 1024 / 1024,
                "current_size_mb": stream_buffer.current_size_bytes / 1024 / 1024,
                "buffered_segments_count": len(segments_info),
                "last_segment_timestamp": stream_buffer.last_segment_timestamp,
                "buffered_segments": segments_info
            }
            self.wfile.write(json.dumps(info, indent=2).encode('utf-8'))
            return

        target_url_from_param = self._get_parsed_url_param()
        current_headers = GLOBAL_HEADERS.copy()
        if original_path.startswith('/?url=') and target_url_from_param:
            cleaned_target_url = self.clean_url_from_headers_params(target_url_from_param)
            new_potential_base_url = urlparse(cleaned_target_url)._replace(query='', fragment='').geturl()
            current_global_base = urlparse(GLOBAL_URL)._replace(query='', fragment='').geturl()
            if (new_potential_base_url != current_global_base) or \
               (not GLOBAL_URL and cleaned_target_url.startswith('http')):
                logger.info(f"Nova URL principal detectada: {target_url_from_param}. Resetando estado.")
                self._reset_stream_state()
                current_headers = GLOBAL_HEADERS.copy()
            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
            target_url_for_fetching = self.clean_url_from_headers_params(target_url_from_param)
        elif target_url_from_param:
            target_url_for_fetching = self.clean_url_from_headers_params(target_url_from_param)
            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
        else:
            target_url_for_fetching = original_path
        processed_target_url = target_url_for_fetching
        if processed_target_url.startswith('http'):
            processed_target_url = self.convert_to_m3u8_url(target_url_for_fetching)
        if not processed_target_url.startswith('http') and not GLOBAL_URL and not original_path.startswith('/'):
            self.send_error(400, "URL base não definida para caminho relativo e sem parâmetro 'url'.")
            return
        if '.m3u8' in processed_target_url:
            logger.debug(f"Roteando para M3U8: {processed_target_url}")
            if method_is_head:
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.end_headers()
                return
            self._handle_m3u8_request(processed_target_url, current_headers)
        elif '.ts' in processed_target_url or ('/hl' in processed_target_url and not processed_target_url.endswith(".m3u8")):
            logger.debug(f"Roteando para TS: {processed_target_url}")
            if method_is_head:
                self.send_response(200)
                self.send_header('Content-type', 'video/mp2t')
                self.end_headers()
                return
            self._handle_ts_request(processed_target_url, current_headers)
        elif target_url_from_param and (target_url_from_param.endswith(".html") or target_url_from_param.endswith(".php") or not '.' in urlparse(target_url_from_param).path.split('/')[-1]):
            logger.debug(f"Roteando para genérico (original .html/.php etc): {processed_target_url}")
            if method_is_head:
                self.send_response(200)
                self.end_headers()
                return
            self._handle_generic_request(processed_target_url, current_headers)
        elif not target_url_from_param and (('.m3u8' in original_path and not original_path.endswith('.m3u8/')) or '.ts' in original_path or '/hl' in original_path):
            if '.m3u8' in original_path:
                logger.debug(f"Roteando para M3U8 (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-Type', 'application/vnd.apple.mpegurl'); self.end_headers(); return
                self._handle_m3u8_request(original_path, current_headers)
            elif '.ts' in original_path or '/hl' in original_path:
                logger.debug(f"Roteando para TS (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-type', 'video/mp2t'); self.end_headers(); return
                self._handle_ts_request(original_path, current_headers)
        else:
            if target_url_from_param:
                 logger.warning(f"Tipo de URL não explicitamente tratado via ?url=: {target_url_from_param}. Tentando como genérico.")
                 if method_is_head: self.send_response(200); self.end_headers(); return
                 self._handle_file_request(processed_target_url, current_headers)
            else:
                 logger.error(f"Path não reconhecido: {original_path}")
                 self.send_error(404, "Recurso não encontrado ou tipo não suportado.")

    def do_HEAD(self):
        self._process_request(method_is_head=True)

    def do_GET(self):
        self._process_request(method_is_head=False)

class MediaServer:
    def __init__(self):
        self.server_thread = None
        self.httpd_instance = None

    def is_in_use(self):
        if self.httpd_instance and self.server_thread and self.server_thread.is_alive():
            return True
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.1)
            try:
                s.bind((HOST_NAME, PORT_NUMBER))
                s.listen(1)
                logger.debug(f"Porta {PORT_NUMBER} está livre.")
                return False
            except socket.error as e:
                logger.warning(f"Porta {PORT_NUMBER} em uso por outro processo ou instância não gerenciada: {e}")
                return True

    def start(self):
        if not self.is_in_use():
            logger.info("Iniciando servidor HTTP MediaServer...")
            try:
                self.httpd_instance = ThreadingHTTPServer((HOST_NAME, PORT_NUMBER), Handler)
                self.server_thread = threading.Thread(target=self.httpd_instance.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                time.sleep(0.5)
                if self.server_thread.is_alive():
                    logger.info(f"MediaServer iniciado com sucesso em http://{HOST_NAME}:{PORT_NUMBER}")
                else:
                    logger.error("Falha ao iniciar MediaServer: thread do servidor não iniciou.")
                    self.httpd_instance = None
            except Exception as e:
                logger.error(f"Erro ao iniciar MediaServer na porta {PORT_NUMBER}: {e}")
                self.httpd_instance = None
        else:
            logger.info("MediaServer já está em execução ou a porta está ocupada.")

    def stop(self):
        logger.info("Solicitando parada do MediaServer...")
        stream_buffer.destroy()
        if self.httpd_instance:
            self.httpd_instance.shutdown()
            self.httpd_instance.server_close()
            logger.info("Aguardando thread do servidor finalizar...")
            if self.server_thread and self.server_thread.is_alive():
                 self.server_thread.join(timeout=5)
            if self.server_thread and not self.server_thread.is_alive():
                 logger.info("Thread do servidor finalizada.")
            else:
                 logger.warning("Timeout ao esperar thread do servidor, ou thread não encontrada/não finalizada.")
            self.httpd_instance = None
            self.server_thread = None
            logger.info("MediaServer parado.")
        else:
            logger.info("MediaServer não estava em execução (instância httpd não encontrada).")
            try:
                requests.get(f'http://{HOST_NAME}:{PORT_NUMBER}/stop', timeout=1)
            except requests.exceptions.ConnectionError:
                logger.debug(f"Nenhum servidor encontrado na porta {PORT_NUMBER} para enviar comando de parada externo.")
            except Exception as e:
                logger.warning(f"Erro ao tentar parar servidor externo: {e}")

def req_shutdown():
    global _media_server_instance
    if _media_server_instance:
        logger.info("req_shutdown() chamado. Solicitando parada do MediaServer.")
        _media_server_instance.stop()
    else:
        logger.warning("req_shutdown() chamado, mas MediaServer não está ativo ou inicializado.")

def prepare_url(url_to_proxy, custom_headers_dict=None): 
    try:
        url_to_proxy_decoded = unquote_plus(url_to_proxy)
        url_to_proxy_decoded = unquote(url_to_proxy_decoded)
    except Exception as e:
        logger.warning(f"Erro ao decodificar URL de entrada '{url_to_proxy}': {e}. Usando URL original.")
        url_to_proxy_decoded = url_to_proxy
    parsed_original = urlparse(url_to_proxy_decoded)
    base_url_for_params = parsed_original.geturl()
    combined_query_params = parse_qs(parsed_original.query, keep_blank_values=True)
    if custom_headers_dict:
        for key, value in custom_headers_dict.items():
            param_key = f"h_{key}"
            combined_query_params[param_key] = [value]
            logger.debug(f"Adicionando header param: {param_key}={value}")
    new_query_string = urlencode(combined_query_params, doseq=True)
    effective_url_to_proxy = parsed_original._replace(query=new_query_string).geturl()
    encoded_target_url = quote_plus(effective_url_to_proxy)
    final_proxy_url = f'http://{HOST_NAME}:{PORT_NUMBER}/?url={encoded_target_url}'
    logger.debug(f"URL Original: {url_to_proxy_decoded}")
    logger.debug(f"URL Efetiva para proxy: {effective_url_to_proxy}")
    logger.debug(f"URL Final do Proxy: {final_proxy_url}")
    return final_proxy_url

if __name__ == '__main__':
    _media_server_instance = MediaServer()
    _media_server_instance.start()
    logger.info(f"Servidor rodando. Acesse http://{HOST_NAME}:{PORT_NUMBER}/check para verificar.")
    logger.info(f"Para ver informações do buffer: http://{HOST_NAME}:{PORT_NUMBER}/buffer_info")
    logger.info(f"Para parar o servidor, acesse http://{HOST_NAME}:{PORT_NUMBER}/stop ou pressione Ctrl+C.")
    try:
        while True:
            if _media_server_instance and _media_server_instance.server_thread and _media_server_instance.server_thread.is_alive():
                time.sleep(1)
            else:
                logger.info("Servidor não está mais ativo ou não foi iniciado. Saindo.")
                break
    except KeyboardInterrupt:
        logger.info("\nInterrupção de teclado no script principal. Parando o servidor...")
    finally:
        if _media_server_instance:
            _media_server_instance.stop()
        logger.info("Script principal finalizado.")
