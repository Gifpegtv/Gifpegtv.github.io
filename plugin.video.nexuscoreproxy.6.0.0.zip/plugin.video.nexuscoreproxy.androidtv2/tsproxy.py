#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# tsproxy.py — NEXUS CORE MPEG-TS PROXY
# Otimizado para Kodi, Android, Termux e dispositivos de pouca RAM.
#
# PYTHON 3 ONLY — Kodi 19-22 (Matrix, Nexus, Omega, Piers).
# Sem compatibilidade com Kodi 17/18 (Python 2.7).
#
# Recursos:
# - Sessão persistente: o player recebe UMA resposta HTTP 200 contínua e nunca
#   vê status de erro da origem. Queda, EOF, timeout, 4xx/5xx e redirects
#   quebrados viram reconexão interna com backoff.
# - Uma única conexão upstream por vez: a sessão anterior no mesmo host é
#   encerrada (socket fechado de verdade) antes da nova abrir.
# - Proxy MPEG-TS com alinhamento de 188 bytes.
# - Sutura em streaming, sem acúmulo de memória: descarta exatamente o que o
#   player já recebeu e retoma no pacote seguinte (overlap de qualquer tamanho).
# - Sem overlap utilizável (origem retomou no live edge ou remuxou o stream):
#   decide por PCR, retoma somente em keyframe (nunca no meio de um GOP) e
#   marca discontinuity_indicator nos PIDs de áudio/vídeo.
# - Encaminhamento HTTP Range para origens finitas que suportam seek.
# - Sem reescrita de continuity counters e sem injeção de pacotes nulos.
# - Redirects tratados manualmente; a URL original é reaberta a cada
#   reconexão para renovar tokens/CDN.
#
# Nota: seek real depende de suporte da origem; stream ao vivo não tem seek.

import collections
import http.server
import logging
import random
import re
import select
import socket
import socketserver
import sys
import threading
import time
import traceback
import urllib.parse

import urllib3

try:  # dentro do Kodi (Python 3) xbmc existe; fora dele (Termux/testes) não.
    import xbmc
except ImportError:  # pragma: no cover
    class _XbmcStub:
        """Stub mínimo de xbmc para uso standalone (Termux / testes)."""
        LOGDEBUG = logging.DEBUG
        LOGINFO = logging.INFO
        LOGWARNING = logging.WARNING
        LOGERROR = logging.ERROR
        LOGFATAL = logging.CRITICAL

        _stub_logger = logging.getLogger("tsproxy")

        @staticmethod
        def log(msg, level=logging.INFO):
            try:
                _XbmcStub._stub_logger.log(level, msg)
            except Exception:
                pass

    xbmc = _XbmcStub()

# time.monotonic sempre existe em Python 3.
_now = time.monotonic

# ============================================================
# CONFIGURAÇÃO
# ============================================================

_LOG_ENABLED = False

TS_PACKET_SIZE = 188
TS_SYNC_BYTE = 0x47
_SYNC = b'\x47'

CHUNK_SIZE = 188 * 348
MAX_REDIRECT_HOPS = 8

CONNECT_TIMEOUT = 8.0
READ_TIMEOUT = 10.0

# Backoff entre tentativas (zera quando a conexão entrega dados de verdade).
RECONNECT_DELAY = 0.5
MAX_RECONNECT_DELAY = 3.0
ERROR_RETRY_DELAY = 1.0          # piso após HTTP 4xx/5xx da origem
MAX_ERROR_RETRY_DELAY = 8.0

# Tempo máximo tentando abrir a origem ANTES de responder 200 ao player.
# Depois disso o 200 sai mesmo assim e as tentativas continuam em background.
INITIAL_OPEN_BUDGET = 12.0

# Sem nenhum byte entregue por esse tempo a sessão é encerrada (0 = nunca).
MAX_OUTAGE_SECONDS = 120.0

HEALTHY_BYTES = 256 * 1024        # bytes recebidos p/ considerar a conexão boa
NO_SYNC_ABORT_BYTES = 2 * 1024 * 1024
EVICT_WAIT = 3.0                  # espera pela sessão anterior fechar a origem

# Sutura
SUTURE_HASH_COUNT = 8             # pacotes de contexto comparados
SUTURE_MIN_MATCH = 3              # mínimo p/ casar com overlap curto
SUTURE_DEADLINE = 20.0            # tempo máx. procurando contexto
SUTURE_MAX_SKIP = 64 * 1024 * 1024
PCR_HZ = 90000
PCR_WRAP = 1 << 33
SUTURE_PCR_MARGIN = int(0.25 * PCR_HZ)
SUTURE_PCR_MAX_BEHIND = 45 * PCR_HZ
JOIN_PCR_SLACK = int(0.10 * PCR_HZ)
KEYFRAME_WAIT = 6.0               # depois: qualquer início de PES de vídeo; 2x: qualquer pacote
MIN_DISCONTINUITY_SPACING = 2.5   # espaço mínimo entre cortes entregues ao decoder
MARK_DISCONTINUITY = True
MARK_WINDOW_PACKETS = 30000

_RANGE_FROM_ZERO = re.compile(r'^bytes\s*=\s*0\s*-\s*$', re.I)


def set_log_enabled(enabled):
    global _LOG_ENABLED
    _LOG_ENABLED = bool(enabled)


def _log(message, level=xbmc.LOGDEBUG):
    if not _LOG_ENABLED:
        return
    try:
        xbmc.log(
            '[NexusCore-TSProxy] {}'.format(message),
            level
        )
    except Exception:
        pass


def _quiet_handle_error(self, request, client_address):
    """handle_error do servidor: suprime traceback de desconexões do cliente.

    Em Python 3 BrokenPipeError/ConnectionResetError/ConnectionAbortedError
    são subclasses de OSError (e de ConnectionError): filtramos todas de uma
    vez. O resto vira log de erro para diagnóstico.
    """
    exc = sys.exc_info()[1]
    if isinstance(exc, (OSError, ConnectionError)):
        _log('Conexão {} encerrada: {}'.format(client_address[0], exc),
             xbmc.LOGDEBUG)
        return
    _log('Erro no servidor: {}'.format(traceback.format_exc()),
         xbmc.LOGERROR)


# ============================================================
# POOL DE CONEXÕES
# ============================================================

class SingleHostConnectionPool:

    def __init__(self):
        self._pools = {}
        self._lock = threading.Lock()

    def get_session_for_host(self, hostname):
        with self._lock:
            item = self._pools.get(hostname)

            if item is None:
                item = {
                    'session': urllib3.PoolManager(
                        num_pools=2,
                        maxsize=1,
                        block=True
                    ),
                    'lock': threading.Lock(),
                    'last_used': time.time()
                }
                self._pools[hostname] = item

            item['last_used'] = time.time()

            return item['session'], item['lock']

    def invalidate_host(self, hostname):
        with self._lock:
            item = self._pools.pop(hostname, None)

        if item:
            try:
                item['session'].clear()
            except Exception:
                pass

    def close_all(self):
        with self._lock:
            items = list(self._pools.values())
            self._pools.clear()

        for item in items:
            try:
                item['session'].clear()
            except Exception:
                pass


_global_pool = SingleHostConnectionPool()


# ============================================================
# LEITURA HTTP / ENCERRAMENTO DE CONEXÃO
# ============================================================

def _make_reader(response):
    """Devolve uma função read1-style para a resposta urllib3.

    Em Python 3 urllib3.HTTPResponse tem read1() nativamente; se faltar,
    cai no fallback com read(n, decode_content=False).
    """
    reader = getattr(response, 'read1', None)

    if reader:
        return reader

    reader = getattr(
        getattr(response, '_fp', None),
        'read1',
        None
    )

    if reader:
        return reader

    return lambda n: response.read(n, decode_content=False)


def _response_socket(response):
    try:
        conn = (
            getattr(response, '_connection', None) or
            getattr(response, 'connection', None)
        )
        sock = getattr(conn, 'sock', None)

        if sock is not None:
            return sock
    except Exception:
        pass

    try:
        fp = getattr(response, '_fp', None)
        raw = getattr(getattr(fp, 'fp', None), 'raw', None)
        return getattr(raw, '_sock', None)
    except Exception:
        return None


def _force_close_response(response):
    """Interrompe um read() bloqueado em outra thread (shutdown do socket)."""
    sock = _response_socket(response)

    if sock is None:
        return

    try:
        sock.shutdown(socket.SHUT_RDWR)
    except Exception:
        pass


def _close_response(response):
    """Fecha o socket de verdade e devolve o slot ao pool (idempotente)."""
    if response is None:
        return

    try:
        response.close()
    except Exception:
        pass

    try:
        response.release_conn()
    except Exception:
        pass


def _wait_readable(sock, timeout):
    # poll() não tem o limite de 1024 descritores do select() (Android/Kodi).
    if hasattr(select, 'poll'):
        poller = select.poll()
        poller.register(
            sock.fileno(),
            select.POLLIN | select.POLLERR | select.POLLHUP
        )
        return bool(poller.poll(int(timeout * 1000)))

    readable, _w, _x = select.select([sock], [], [], timeout)
    return bool(readable)


def _host_header(parsed):
    host = parsed.hostname

    if not host:
        return parsed.netloc

    if ':' in host:
        host = '[{}]'.format(host)

    try:
        port = parsed.port
    except ValueError:
        port = None

    default = 443 if parsed.scheme == 'https' else 80

    if port and port != default:
        return '{}:{}'.format(host, port)

    return host


def _backoff_delay(failures, http_error=False):
    if failures <= 0:
        return 0.0

    base = RECONNECT_DELAY * (2 ** min(failures - 1, 6))

    if http_error:
        delay = min(MAX_ERROR_RETRY_DELAY, max(ERROR_RETRY_DELAY, base))
    else:
        delay = min(MAX_RECONNECT_DELAY, base)

    return delay * random.uniform(0.8, 1.2)


# ============================================================
# PRIMITIVAS MPEG-TS
# ============================================================

def _fingerprint_at(data, o):
    # Impressão digital de um pacote (cabeçalho + início do payload).
    # Pacotes null, sem payload ou com payload curto não servem de âncora.
    if data[o] != TS_SYNC_BYTE:
        return None

    if (data[o + 1] & 0x1F) == 0x1F and data[o + 2] == 0xFF:
        return None

    afc = (data[o + 3] >> 4) & 3

    if afc == 1:
        start = o + 4
    elif afc == 3:
        start = o + 5 + data[o + 4]
    else:
        return None

    if start + 16 > o + TS_PACKET_SIZE:
        return None

    return bytes(data[o + 1:o + 4]) + bytes(data[start:start + 16])


def _packet_hash(packet):
    if len(packet) != TS_PACKET_SIZE:
        return None
    return _fingerprint_at(packet, 0)


def _pcr_at(data, o):
    if not (data[o + 3] & 0x20):
        return None

    if data[o + 4] < 7 or not (data[o + 5] & 0x10):
        return None

    return (
        (data[o + 6] << 25) |
        (data[o + 7] << 17) |
        (data[o + 8] << 9) |
        (data[o + 9] << 1) |
        (data[o + 10] >> 7)
    )


def _pcr_diff(a, b):
    d = (a - b) % PCR_WRAP

    if d >= (PCR_WRAP >> 1):
        d -= PCR_WRAP

    return d


_HEVC_KEY_NALS = frozenset((
    0x20, 0x22, 0x24, 0x26, 0x28, 0x2A,   # BLA/IDR/CRA
    0x40, 0x42, 0x44                      # VPS/SPS/PPS
))


def _video_pes_payload(data, o):
    # (offset do ES, random_access_indicator) se o pacote inicia um PES de
    # vídeo; caso contrário None.
    if not (data[o + 1] & 0x40):
        return None

    afc = (data[o + 3] >> 4) & 3
    rai = False

    if afc == 1:
        start = o + 4
    elif afc == 3:
        af = data[o + 4]
        rai = af > 0 and bool(data[o + 5] & 0x40)
        start = o + 5 + af
    else:
        return None

    end = o + TS_PACKET_SIZE

    if start + 9 > end:
        return None

    if data[start] != 0 or data[start + 1] != 0 or data[start + 2] != 1:
        return None

    stream_id = data[start + 3]

    if stream_id < 0xE0 or stream_id > 0xEF:
        return None

    return min(start + 9 + data[start + 8], end), rai


def _is_video_pes_start(data, o):
    return _video_pes_payload(data, o) is not None


def _is_keyframe_start(data, o):
    # Início de access unit com ponto de acesso aleatório: flag RAI, ou
    # SPS/IDR (H.264), VPS/SPS/PPS/IRAP (HEVC), sequence/GOP header (MPEG-2).
    info = _video_pes_payload(data, o)

    if info is None:
        return False

    pos, rai = info

    if rai:
        return True

    end = o + TS_PACKET_SIZE

    while True:
        pos = data.find(b'\x00\x00\x01', pos, end)

        if pos < 0 or pos + 3 >= end:
            return False

        nal = data[pos + 3]

        if nal == 0xB3 or nal == 0xB8:
            return True

        if (nal & 0x80) == 0:
            if (nal & 0x1F) in (5, 7):
                return True

            if (
                nal in _HEVC_KEY_NALS and
                pos + 4 < end and
                data[pos + 4] == 0x01
            ):
                return True

        pos += 3


def _adaptation_marker(pid, cc):
    # Pacote só de adaptation field com discontinuity_indicator=1. Não leva
    # payload, então o CC não avança: usa o CC do pacote anterior ao próximo.
    pkt = bytearray(b'\xff' * TS_PACKET_SIZE)
    pkt[0] = TS_SYNC_BYTE
    pkt[1] = (pid >> 8) & 0x1F
    pkt[2] = pid & 0xFF
    pkt[3] = 0x20 | (cc & 0x0F)
    pkt[4] = 183
    pkt[5] = 0x80
    return pkt


# ============================================================
# ALINHAMENTO MPEG-TS
# ============================================================

class TsBuffer:

    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._errors = 0
        self.total_out = 0

    def clear_partial_buffer(self):
        self._buf = bytearray()
        self._aligned = False

    def begin_phase_shift(self, align=True):
        # Intencionalmente não altera CC.
        # Reescrever CC pode mascarar duplicatas e corromper PES.
        return

    def cc_stats(self):
        return (0, 0)

    def _find_sync(self):
        data = self._buf
        limit = len(data) - 377
        pos = 0

        while pos <= limit:
            pos = data.find(_SYNC, pos)

            if pos < 0 or pos > limit:
                return -1

            if (
                data[pos + 188] == TS_SYNC_BYTE and
                data[pos + 376] == TS_SYNC_BYTE
            ):
                return pos

            pos += 1

        return -1

    def feed(self, raw):
        # Devolve somente pacotes inteiros, todos começando em 0x47. O resto
        # (pacote parcial) fica retido até o próximo read.
        if raw:
            self._buf.extend(raw)

        if not self._aligned:
            idx = self._find_sync()

            if idx < 0:
                # Preserva bytes suficientes para sincronizar no próximo read.
                if len(self._buf) > 752:
                    del self._buf[:-376]

                return b''

            if idx:
                del self._buf[:idx]

            self._aligned = True

        usable = len(self._buf) - (
            len(self._buf) % TS_PACKET_SIZE
        )

        if usable <= 0:
            return b''

        block = bytes(self._buf[:usable])
        del self._buf[:usable]
        count = usable // TS_PACKET_SIZE

        # Caminho rápido: todos os sync bytes na posição certa (em C).
        if block[::TS_PACKET_SIZE] == _SYNC * count:
            self.total_out += usable
            return block

        # Perdeu a malha TS no meio do bloco: entrega só o trecho válido e
        # ressincroniza o resto. Nada fora da malha chega ao player.
        good = 0

        while good < count:
            pos = good * TS_PACKET_SIZE

            if block[pos:pos + 1] != _SYNC:
                break

            good += 1

        self._errors += 1
        self._buf = bytearray(block[good * TS_PACKET_SIZE:]) + self._buf
        self._aligned = False

        out = block[:good * TS_PACKET_SIZE]
        self.total_out += len(out)

        return out


# ============================================================
# ÚLTIMO TRECHO ENTREGUE AO PLAYER
# ============================================================

class SutureManager:

    def __init__(self):
        self._recent = collections.deque(
            maxlen=SUTURE_HASH_COUNT
        )
        self._tail_packets = 0
        self._last_pcr = None

    def add_played(self, data):
        # `data` deve ser exatamente o que veio da origem e foi entregue
        # (sem pacotes de marcação injetados).
        if not data:
            return

        count = len(data) // TS_PACKET_SIZE

        if count <= 0:
            return

        hashes = []
        tail = 0
        pcr = None
        pos = (count - 1) * TS_PACKET_SIZE

        # Varredura reversa: contexto (últimos pacotes hashable), quantos
        # pacotes não hashable vieram depois dele e o último PCR entregue.
        while pos >= 0:
            fp = _fingerprint_at(data, pos)

            if fp is None:
                if not hashes:
                    tail += 1
            elif len(hashes) < SUTURE_HASH_COUNT:
                hashes.append(fp)

            if pcr is None and (data[pos + 3] & 0x20):
                pcr = _pcr_at(data, pos)

            if pcr is not None and len(hashes) >= SUTURE_HASH_COUNT:
                break

            pos -= TS_PACKET_SIZE

        if pcr is not None:
            self._last_pcr = pcr

        if hashes:
            for h in reversed(hashes):
                self._recent.append(h)

            self._tail_packets = tail
        else:
            self._tail_packets += count

    def get_target(self):
        if len(self._recent) < SUTURE_MIN_MATCH:
            return None

        return (
            list(self._recent),
            self._tail_packets
        )

    def get_last_pcr(self):
        return self._last_pcr

    def clear(self):
        self._recent.clear()
        self._tail_packets = 0
        self._last_pcr = None


# ============================================================
# BUSCA DE SUTURA EM STREAMING
# ============================================================

class SutureSearchState:
    # Processa a nova conexão pacote a pacote, SEM acumular nada:
    #
    #   search  descarta o que o player já recebeu até reencontrar o contexto
    #           (últimos pacotes entregues) e retoma no pacote seguinte;
    #   join    sem contexto utilizável: descarta até um keyframe (nunca
    #           retoma no meio de um GOP) e pede marca de descontinuidade.
    #
    # O PCR decide cedo entre "ainda estou no overlap" e "já passei do ponto
    # em que a conexão anterior caiu", em vez de esperar um limite de bytes.

    def __init__(self, target=None, last_pcr=None, earliest_join=0.0):
        self.finished = False
        self.result = None
        self.reason = ''
        self.mark_pids = set()
        self.skipped_packets = 0
        self.started = _now()
        self.last_pcr = last_pcr
        self.cur_pcr = None
        self.mode = 'search'

        self._earliest_join = earliest_join
        self._pes_pids = set()
        self._target = None
        self._tail = 0
        self._win = None
        self._seen = 0
        self._matched = False
        self._skip_left = 0
        self._pcr_gate = last_pcr is not None
        self._join_started = None
        self._now = self.started

        if target and len(target[0]) >= SUTURE_MIN_MATCH:
            self._target = list(target[0])
            self._tail = int(target[1])
            self._win = collections.deque(maxlen=len(self._target))
        else:
            self._enter_join('sem-contexto')

    def _enter_join(self, reason, gate=True):
        self.mode = 'join'
        self.reason = reason
        self._join_started = _now()
        self._pcr_gate = bool(gate and self.last_pcr is not None)

    def _learn_pes(self, data, o):
        afc = (data[o + 3] >> 4) & 3

        if afc == 1:
            start = o + 4
        elif afc == 3:
            start = o + 5 + data[o + 4]
        else:
            return

        if start + 4 > o + TS_PACKET_SIZE:
            return

        if data[start] or data[start + 1] or data[start + 2] != 1:
            return

        sid = data[start + 3]

        if (0xC0 <= sid <= 0xEF or sid == 0xBD) and len(self._pes_pids) < 32:
            self._pes_pids.add(
                ((data[o + 1] & 0x1F) << 8) | data[o + 2]
            )

    def _accept_join(self, data, o):
        now = self._now

        if now < self._earliest_join:
            return False

        if (
            self._pcr_gate and
            self.cur_pcr is not None and
            _pcr_diff(self.cur_pcr, self.last_pcr) < -JOIN_PCR_SLACK
        ):
            return False

        waited = now - self._join_started

        if waited > KEYFRAME_WAIT * 2:
            return True

        if waited > KEYFRAME_WAIT:
            return _is_video_pes_start(data, o)

        return _is_keyframe_start(data, o)

    def _finish(self, data, index, result):
        self.finished = True
        self.result = result

        if result == 'join':
            self.mark_pids = set(self._pes_pids)

        return bytes(data[index * TS_PACKET_SIZE:])

    def feed(self, block):
        # `block`: pacotes inteiros alinhados (saída do TsBuffer). Devolve o
        # que deve ser entregue ao player (b'' enquanto ainda procura).
        if self.finished:
            return block

        if not block:
            return b''

        data = block
        total = len(data) // TS_PACKET_SIZE
        self._now = _now()

        if self.mode == 'search' and not self._matched:
            if (
                self._now - self.started > SUTURE_DEADLINE or
                self.skipped_packets * TS_PACKET_SIZE > SUTURE_MAX_SKIP
            ):
                self._enter_join('limite-de-busca', gate=False)

        for idx in range(total):
            o = idx * TS_PACKET_SIZE

            if data[o + 3] & 0x20:
                pcr = _pcr_at(data, o)

                if pcr is not None:
                    self.cur_pcr = pcr

                    if (
                        self.mode == 'search' and
                        not self._matched and
                        self.last_pcr is not None
                    ):
                        diff = _pcr_diff(pcr, self.last_pcr)

                        if diff > SUTURE_PCR_MARGIN:
                            self._enter_join('pcr-adiante')
                        elif diff < -SUTURE_PCR_MAX_BEHIND:
                            self._enter_join(
                                'timeline-reiniciada',
                                gate=False
                            )

            if data[o + 1] & 0x40:
                self._learn_pes(data, o)

            if self.mode == 'search':
                fp = _fingerprint_at(data, o)

                if self._matched:
                    # Pula o rabo não hashable que o player já tem.
                    if self._skip_left > 0 and fp is None:
                        self._skip_left -= 1
                        self.skipped_packets += 1

                        if self._skip_left == 0:
                            return self._finish(data, idx + 1, 'matched')

                        continue

                    return self._finish(data, idx, 'matched')

                if fp is not None:
                    win = self._win
                    win.append(fp)
                    self._seen += 1

                    if fp == self._target[-1]:
                        n = len(win)

                        if n == len(self._target):
                            hit = list(win) == self._target
                        elif n == self._seen and n >= SUTURE_MIN_MATCH:
                            # Conexão começou no meio do contexto.
                            hit = list(win) == self._target[-n:]
                        else:
                            hit = False

                        if hit:
                            self._matched = True
                            self._skip_left = self._tail
                            self.skipped_packets += 1

                            if self._skip_left == 0:
                                return self._finish(data, idx + 1, 'matched')

                            continue

                self.skipped_packets += 1
                continue

            # mode == 'join'
            if self._accept_join(data, o):
                return self._finish(data, idx, 'join')

            self.skipped_packets += 1

        return b''

    def clear(self):
        self.finished = False
        self.result = None
        self.skipped_packets = 0
        self._win = None
        self._seen = 0
        self._matched = False
        self._skip_left = 0


class _DiscontinuityMarker:
    # Depois de um corte sem overlap marca discontinuity_indicator no primeiro
    # pacote de cada PID de áudio/vídeo. Se o pacote já tem adaptation field o
    # bit é ligado no lugar; senão entra um pacote só-de-adaptation antes dele
    # (nenhum byte de payload é alterado ou perdido).

    def __init__(self):
        self._pending = set()
        self._budget = 0

    def arm(self, pids):
        self._pending = set(pids)
        self._budget = MARK_WINDOW_PACKETS

    def process(self, block):
        if not self._pending:
            return block

        data = bytearray(block)
        count = len(data) // TS_PACKET_SIZE
        out = None
        last = 0

        for idx in range(count):
            o = idx * TS_PACKET_SIZE
            pid = ((data[o + 1] & 0x1F) << 8) | data[o + 2]

            if pid not in self._pending:
                continue

            self._pending.discard(pid)
            afc = (data[o + 3] >> 4) & 3

            if afc in (2, 3) and data[o + 4] >= 1:
                data[o + 5] |= 0x80
            else:
                cc = data[o + 3] & 0x0F

                if afc & 1:
                    cc = (cc - 1) & 0x0F

                if out is None:
                    out = bytearray()

                out += data[last:o]
                out += _adaptation_marker(pid, cc)
                last = o

            if not self._pending:
                break

        self._budget -= count

        if self._budget <= 0:
            self._pending.clear()

        if out is None:
            return bytes(data)

        out += data[last:]

        return bytes(out)


# ============================================================
# ERROS HTTP
# ============================================================

class _HTTPStatusError(Exception):

    def __init__(self, status):
        super().__init__('HTTP {}'.format(status))
        self.status = status


# ============================================================
# SESSÃO (player -> proxy -> origem)
# ============================================================

class _StreamSession:

    def __init__(self, client_sock):
        self._client = client_sock
        self._lock = threading.Lock()
        self._response = None
        self.abort_event = threading.Event()
        self.done_event = threading.Event()

    @property
    def aborted(self):
        return self.abort_event.is_set()

    def wait(self, timeout):
        # Dorme até `timeout` ou até a sessão ser abortada.
        self.abort_event.wait(timeout)
        return self.abort_event.is_set()

    def set_response(self, response):
        with self._lock:
            self._response = response

        if self.abort_event.is_set():
            _force_close_response(response)

    def clear_response(self):
        with self._lock:
            self._response = None

    def abort(self, reason='', kill_client=False):
        self.abort_event.set()

        with self._lock:
            response = self._response

        if response is not None:
            _force_close_response(response)

        if kill_client:
            try:
                self._client.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass

        if reason:
            _log('Sessão abortada: {}'.format(reason))


class _LiveState:

    def __init__(self):
        self.played = False
        self.last_join = 0.0
        self.failures = 0
        self.last_status = None
        self.last_delivery = _now()


_sessions = {}
_sessions_lock = threading.Lock()


def _session_key(url):
    parsed = urllib.parse.urlparse(url)
    host = (parsed.hostname or parsed.netloc or '').lower()

    try:
        port = parsed.port
    except ValueError:
        port = None

    if not port:
        port = 443 if parsed.scheme == 'https' else 80

    return '{}:{}'.format(host, port)


def _register_session(key, session):
    # Uma sessão por host: a anterior fecha a conexão upstream antes de a
    # nova abrir (painéis de conexão única respondem HTTP 500/403 senão).
    with _sessions_lock:
        old = _sessions.get(key)
        _sessions[key] = session

    if old is None or old is session:
        return

    old.abort('substituída por nova requisição')

    if not old.done_event.wait(EVICT_WAIT):
        old.abort('encerramento forçado', kill_client=True)
        old.done_event.wait(EVICT_WAIT)


def _unregister_session(key, session):
    with _sessions_lock:
        if _sessions.get(key) is session:
            del _sessions[key]

    session.done_event.set()


def _abort_all_sessions():
    with _sessions_lock:
        items = list(_sessions.values())
        _sessions.clear()

    for item in items:
        item.abort('proxy encerrado', kill_client=True)


# ============================================================
# HANDLER HTTP
# ============================================================

class TSProxyHandler(http.server.BaseHTTPRequestHandler):

    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        _log(fmt % args)

    def _safe_write(self, data):
        if not data:
            return True

        try:
            self.wfile.write(data)
            self.wfile.flush()  # força envio — detecta cliente desconectado rápido
            return True
        except (
            BrokenPipeError,
            ConnectionResetError,
            ConnectionAbortedError,
            OSError
        ):
            return False
        except Exception:
            return False

    def _get_url(self):
        params = urllib.parse.parse_qs(
            urllib.parse.urlparse(self.path).query
        )

        return params.get('url', [None])[0]

    def _open_origin(
        self, url, method='GET', extra_headers=None, session=None
    ):
        current = url

        for _ in range(MAX_REDIRECT_HOPS + 1):
            parsed = urllib.parse.urlparse(current)
            hostname = parsed.hostname or parsed.netloc

            pool, _pool_lock = (
                _global_pool.get_session_for_host(hostname)
            )

            headers = {
                'User-Agent': (
                    self.headers.get('User-Agent') or 'Kodi/21'
                ),
                'Accept': '*/*',
                'Accept-Encoding': 'identity',
                'Connection': 'keep-alive',
                'Referer': url,
                'Host': _host_header(parsed)
            }

            if extra_headers:
                headers.update(extra_headers)

            try:
                response = pool.request(
                    method,
                    current,
                    headers=headers,
                    timeout=urllib3.Timeout(
                        connect=CONNECT_TIMEOUT,
                        read=READ_TIMEOUT
                    ),
                    preload_content=False,
                    redirect=False,
                    retries=False,
                    pool_timeout=CONNECT_TIMEOUT
                )
            except Exception:
                # Pool possivelmente com slot preso: descarta e recria.
                _global_pool.invalidate_host(hostname)
                raise

            if session is not None:
                session.set_response(response)

            if response.status not in (
                301, 302, 303, 307, 308
            ):
                return response, current

            location = response.headers.get('Location')
            _close_response(response)

            if session is not None:
                session.clear_response()

            if not location:
                raise Exception(
                    'Redirect sem Location'
                )

            current = urllib.parse.urljoin(
                current,
                location
            )

        raise Exception('Limite de redirects excedido')

    def _send_origin_headers(self, response):
        self.send_response(response.status)

        content_type = response.headers.get(
            'Content-Type',
            'video/mp2t'
        )

        self.send_header('Content-Type', content_type)

        for name in (
            'Content-Length',
            'Content-Range',
            'Accept-Ranges',
            'ETag',
            'Last-Modified'
        ):
            value = response.headers.get(name)

            if value:
                self.send_header(name, value)

        self.send_header('Cache-Control', 'no-cache')
        self.send_header('Connection', 'close')
        self.end_headers()

    def _relay_response(self, response, session=None):
        reader = _make_reader(response)

        while session is None or not session.aborted:
            try:
                block = reader(CHUNK_SIZE)
            except Exception:
                break

            if not block:
                break

            if not self._safe_write(block):
                break

    def _watch_client(self, session):
        # Detecta o player fechando a conexão mesmo sem nada para escrever e
        # derruba a origem na hora (read() bloqueado, backoff, reconexão).
        sock = self.connection

        while not session.done_event.is_set() and not session.aborted:
            try:
                readable = _wait_readable(sock, 0.5)
            except Exception:
                break

            if not readable:
                continue

            try:
                data = sock.recv(4096)
            except socket.timeout:
                continue
            except Exception:
                data = b''

            if not data:
                session.abort('player desconectou')
                return

    def do_HEAD(self):
        # Responde IMEDIATAMENTE 200 OK sem NENHUMA chamada externa.
        # Não parseia URL, não contacta upstream, não faz nada além de enviar
        # headers mínimos. Isso garante que o CCurlFile::Stat do Kodi retorne
        # instantaneamente, sem os 20s de timeout que congelavam o teardown.
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Accept-Ranges', 'none')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'close')
            self.end_headers()
        except Exception:
            pass

    def do_GET(self):
        url = self._get_url()

        if not url:
            self.send_error(400, 'Parâmetro url ausente')
            return

        try:
            self.connection.setsockopt(
                socket.IPPROTO_TCP,
                socket.TCP_NODELAY,
                1
            )
        except Exception:
            pass

        # Timeout de ESCRITA no socket do cliente: quando o usuário aperta STOP,
        # o Kodi para de ler do proxy. O proxy tenta escrever → bloqueia →
        # timeout em 3s → detecta desconexão → fecha conexão upstream →
        # o curl do Kodi recebe "connection reset" → player fecha instantâneo.
        # Sem este timeout, o proxy fica bloqueado por 20-67s nos timeouts do
        # curl, causando a "tela preta" ao apertar STOP.
        try:
            self.connection.settimeout(3)
        except Exception:
            pass

        # Range diferente de "0-" só faz sentido em arquivo finito. Em stream
        # ao vivo "bytes=0-" é o próprio início da reprodução.
        range_header = self.headers.get('Range')

        if range_header and not _RANGE_FROM_ZERO.match(
            range_header.strip()
        ):
            self._do_range(url, range_header)
            return

        self._do_stream(url)

    # --------------------------------------------------------
    # RANGE / SEEK (arquivos finitos)
    # --------------------------------------------------------
    def _do_range(self, url, range_header):
        extra = {'Range': range_header}

        if self.headers.get('If-Range'):
            extra['If-Range'] = self.headers.get('If-Range')

        response = None

        try:
            for attempt in range(3):
                try:
                    response, _ = self._open_origin(
                        url,
                        'GET',
                        extra
                    )
                except Exception as exc:
                    response = None
                    _log(
                        'Range falhou: {}'.format(exc),
                        xbmc.LOGWARNING
                    )
                    time.sleep(0.3 * (attempt + 1))
                    continue

                if response.status < 500:
                    break

                _close_response(response)
                response = None
                time.sleep(0.3 * (attempt + 1))

            if response is None:
                self.send_error(502, 'Falha na origem')
                return

            self._send_origin_headers(response)

            if response.status in (200, 206):
                self._relay_response(response)

        except Exception as exc:
            _log(
                'Range falhou: {}'.format(exc),
                xbmc.LOGWARNING
            )
        finally:
            _close_response(response)

    # --------------------------------------------------------
    # ABERTURA INICIAL
    # --------------------------------------------------------
    def _initial_open(self, url, session):
        deadline = _now() + INITIAL_OPEN_BUDGET
        failures = 0
        http_error = False

        while not session.aborted:
            response = None
            http_error = False

            try:
                response, _resolved = self._open_origin(
                    url,
                    'GET',
                    None,
                    session
                )

                if response.status < 400:
                    return response, failures

                http_error = True

                _log(
                    'Origem respondeu HTTP {}'.format(response.status),
                    xbmc.LOGWARNING
                )
            except Exception as exc:
                _log(
                    'Abertura falhou: {}'.format(str(exc)[:120]),
                    xbmc.LOGWARNING
                )

            _close_response(response)
            session.clear_response()
            failures += 1

            remaining = deadline - _now()

            if remaining <= 0:
                break

            delay = min(
                _backoff_delay(failures, http_error),
                remaining
            )

            if session.wait(delay):
                break

        return None, failures

    # --------------------------------------------------------
    # SESSÃO
    # --------------------------------------------------------
    def _do_stream(self, url):
        key = _session_key(url)
        session = _StreamSession(self.connection)

        _register_session(key, session)

        watcher = threading.Thread(
            target=self._watch_client,
            args=(session,),
            daemon=True
        )
        watcher.start()

        response = None

        try:
            response, failures = self._initial_open(url, session)

            if session.aborted:
                return

            if (
                response is not None and
                response.headers.get('Content-Length') is not None
            ):
                # Arquivo finito: não o transforma em stream infinito.
                # Preserva Content-Length para o Kodi identificar o fim e
                # pedir Range em seeks futuros.
                self._send_origin_headers(response)
                self._relay_response(response, session)
                return

            self._serve_live(url, response, session, failures)

        except Exception as exc:
            _log(
                'Falha na sessão: {}'.format(str(exc)[:120]),
                xbmc.LOGWARNING
            )
        finally:
            _close_response(response)
            session.clear_response()
            _unregister_session(key, session)

    # --------------------------------------------------------
    # STREAM CONTÍNUO
    # --------------------------------------------------------
    def _serve_live(self, url, response, session, failures=0):
        # O player recebe 200 agora e uma única resposta até desconectar.
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Accept-Ranges', 'none')
            self.send_header('Connection', 'close')
            self.end_headers()
        except Exception:
            _close_response(response)
            return

        ctx = _LiveState()
        ctx.failures = failures
        suture = SutureManager()
        marker = _DiscontinuityMarker()

        while not session.aborted:
            if response is None:
                response = self._reconnect(url, session, ctx)

                if response is None:
                    break

            received, _delivered = self._pump(
                response,
                session,
                ctx,
                suture,
                marker
            )

            # Fecha o socket de verdade ANTES de reabrir: a origem só pode
            # ver uma conexão nossa por vez.
            _close_response(response)
            response = None
            session.clear_response()

            if session.aborted:
                break

            if received >= HEALTHY_BYTES:
                ctx.failures = 0
                ctx.last_status = None
            else:
                ctx.failures += 1

            _log(
                'Origem encerrou ({} bytes); reconectando'.format(received),
                xbmc.LOGINFO
            )

        _close_response(response)

    def _reconnect(self, url, session, ctx):
        # Reabre a URL original (renova redirects/tokens). Qualquer erro é
        # absorvido aqui: o player nunca vê o status da origem.
        while not session.aborted:
            if (
                MAX_OUTAGE_SECONDS and
                _now() - ctx.last_delivery > MAX_OUTAGE_SECONDS
            ):
                _log(
                    'Origem sem dados por {}s; encerrando'.format(
                        int(MAX_OUTAGE_SECONDS)
                    ),
                    xbmc.LOGWARNING
                )
                return None

            delay = _backoff_delay(
                ctx.failures,
                ctx.last_status is not None
            )

            if delay > 0 and session.wait(delay):
                break

            response = None

            try:
                response, _resolved = self._open_origin(
                    url,
                    'GET',
                    None,
                    session
                )

                if response.status < 400:
                    return response

                ctx.last_status = response.status

                _log(
                    'Reconexão: HTTP {}'.format(response.status),
                    xbmc.LOGWARNING
                )

                if response.status in (401, 403):
                    _global_pool.invalidate_host(
                        urllib.parse.urlparse(url).hostname
                    )
            except Exception as exc:
                ctx.last_status = None

                _log(
                    'Reconexão falhou: {}'.format(str(exc)[:100]),
                    xbmc.LOGWARNING
                )

                _global_pool.invalidate_host(
                    urllib.parse.urlparse(url).hostname
                )

            _close_response(response)
            session.clear_response()
            ctx.failures += 1

        return None

    def _on_suture_done(self, search, ctx, suture, marker, started):
        elapsed = _now() - started

        if search.result == 'matched':
            _log(
                'Sutura encontrada: {} pacotes descartados em {:.1f}s'.format(
                    search.skipped_packets,
                    elapsed
                ),
                xbmc.LOGINFO
            )
            return

        # Sem overlap utilizável: o contexto antigo não vale mais.
        _log(
            'Sutura sem overlap ({}); retomada em keyframe após {:.1f}s '
            '({} pacotes descartados)'.format(
                search.reason,
                elapsed,
                search.skipped_packets
            ),
            xbmc.LOGWARNING
        )

        suture.clear()
        ctx.last_join = _now()

        if MARK_DISCONTINUITY:
            marker.arm(search.mark_pids)

    def _pump(self, response, session, ctx, suture, marker):
        reader = _make_reader(response)
        ts_buffer = TsBuffer()
        search = None

        if ctx.played:
            search = SutureSearchState(
                suture.get_target(),
                suture.get_last_pcr(),
                ctx.last_join + MIN_DISCONTINUITY_SPACING
            )

        received = 0
        delivered = 0
        started = _now()

        while not session.aborted:
            try:
                raw = reader(CHUNK_SIZE)
            except Exception as exc:
                if not session.aborted:
                    _log(
                        'Leitura da origem falhou: {}'.format(
                            str(exc)[:100]
                        ),
                        xbmc.LOGWARNING
                    )
                break

            if not raw:
                break

            received += len(raw)
            block = ts_buffer.feed(raw)

            if not block:
                if (
                    ts_buffer.total_out == 0 and
                    received > NO_SYNC_ABORT_BYTES
                ):
                    _log(
                        'Origem sem pacotes MPEG-TS válidos',
                        xbmc.LOGWARNING
                    )
                    break

                continue

            if search is not None:
                payload = search.feed(block)

                if search.finished:
                    self._on_suture_done(
                        search,
                        ctx,
                        suture,
                        marker,
                        started
                    )
                    search = None

                if not payload:
                    continue
            else:
                payload = block

            if not self._safe_write(marker.process(payload)):
                session.abort('player desconectou')
                break

            suture.add_played(payload)
            ctx.played = True
            ctx.last_delivery = _now()
            delivered += len(payload)

        return received, delivered


# ============================================================
# SERVIDOR E API PÚBLICA
# ============================================================

class ThreadingHTTPServer(
    socketserver.ThreadingMixIn,
    http.server.HTTPServer
):
    daemon_threads = True
    allow_reuse_address = True
    handle_error = _quiet_handle_error

    def server_bind(self):
        # HTTPServer.server_bind chama socket.getfqdn() (DNS reverso): no
        # Android/Termux isso pode pendurar a criação do servidor por segundos.
        # Pulamos direto para socketserver.TCPServer.server_bind().
        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = host
        self.server_port = port


_server_instance = None
_server_thread = None
_lock = threading.Lock()


def _ensure_server_running():
    global _server_instance, _server_thread

    with _lock:
        if _server_instance is None:
            _server_instance = ThreadingHTTPServer(
                ('127.0.0.1', 0),
                TSProxyHandler
            )

            _server_thread = threading.Thread(
                target=_server_instance.serve_forever,
                daemon=True
            )

            _server_thread.start()

            port = _server_instance.server_address[1]

            _log(
                'Servidor iniciado na porta {}'.format(port),
                xbmc.LOGINFO
            )

            return port

        return _server_instance.server_address[1]


def get_proxy_url(stream_url, port=None):
    if port is None:
        port = _ensure_server_running()

    encoded_url = urllib.parse.quote(
        stream_url,
        safe=''
    )

    return 'http://127.0.0.1:{}/?url={}'.format(
        port,
        encoded_url
    )


def shutdown_proxy():
    global _server_instance, _server_thread

    with _lock:
        server = _server_instance
        _server_instance = None
        _server_thread = None

    # Derruba as sessões ativas (e suas conexões upstream) imediatamente.
    _abort_all_sessions()

    if server:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass

    _global_pool.close_all()

    _log('Proxy encerrado', xbmc.LOGINFO)
