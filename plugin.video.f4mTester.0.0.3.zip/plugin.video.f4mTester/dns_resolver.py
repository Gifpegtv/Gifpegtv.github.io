# dns_resolver.py
try:
    import dns.resolver
    import dns.rdata
    import dns.rdataclass
    import dns.rdatatype
    import dns.flags
    import socket
    import ssl
    import time
    DNS_MODULE_AVAILABLE = True
except ModuleNotFoundError:
    print("Módulo 'dns' (dnspython) não encontrado. A resolução DNS-over-TLS será desativada.")
    DNS_MODULE_AVAILABLE = False
except Exception as e:
    print(f"Erro ao importar módulos DNS: {e}. A resolução DNS-over-TLS será desativada.")
    DNS_MODULE_AVAILABLE = False


# Servidores DNS-over-TLS da Cloudflare
CLOUDFLARE_DOT_RESOLVERS = [
    '1.1.1.1',
    '1.0.0.1'
]
CLOUDFLARE_DOT_PORT = 853 # Porta padrão para DNS-over-TLS
DOT_TIMEOUT = 5 # Timeout para consultas DoT

class DoTResolver:
    def __init__(self):
        if DNS_MODULE_AVAILABLE:
            self.resolver = dns.resolver.Resolver(configure=False)
            self.resolver.nameservers = CLOUDFLARE_DOT_RESOLVERS
            self.resolver.port = CLOUDFLARE_DOT_PORT
            self.resolver.lifetime = DOT_TIMEOUT # Timeout para cada tentativa
            # Para realmente fazer DoT com dnspython de forma simples, você confia que ele
            # fará a conexão segura se o servidor DNS estiver na porta 853.
            print(f"DoTResolver inicializado com servidores: {self.resolver.nameservers}")
        else:
            self.resolver = None
            print("DoTResolver não inicializado devido à falta do módulo 'dns'.")

    def resolve_with_dot(self, hostname):
        """
        Resolve um hostname para um endereço IPv4 usando DNS-over-TLS da Cloudflare.
        Retorna o primeiro IP encontrado ou None em caso de falha.
        """
        if not DNS_MODULE_AVAILABLE or self.resolver is None:
            print(f"Módulo 'dns' não disponível. Não é possível usar DoT para {hostname}.")
            return None # Não tenta resolver se o módulo não estiver disponível

        try:
            # Força o dnspython a usar a porta DoT
            self.resolver.port = CLOUDFLARE_DOT_PORT
            # Tenta resolver o hostname para endereços A (IPv4)
            answers = self.resolver.resolve(hostname, 'A')
            for rdata in answers:
                ip_address = rdata.address
                print(f"Hostname '{hostname}' resolvido para IP '{ip_address}' via DoT.")
                return ip_address
        except dns.resolver.NoAnswer:
            print(f"Nenhuma resposta A para '{hostname}' via DoT.")
        except dns.resolver.NXDOMAIN:
            print(f"Domínio '{hostname}' não existe (NXDOMAIN) via DoT.")
        except dns.resolver.Timeout:
            print(f"Tempo limite excedido ao resolver '{hostname}' via DoT.")
        except dns.exception.DNSException as e:
            print(f"Erro DNS ao resolver '{hostname}' via DoT: {e}")
        except Exception as e:
            print(f"Erro inesperado ao resolver '{hostname}': {e}")
        return None

# Instância global do resolvedor DoT
dot_resolver = DoTResolver()