# server.py (COM INTEGRAÇÃO DoT - AGORA COM FALLBACK PARA DNS PADRÃO)
import six
import threading
import socket
import requests
import time
import queue # Para buffering
import dns_resolver # Importa o novo módulo DoT

try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode # python 3
except ImportError:
    from urlparse import urlparse, parse_qs # python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode

if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import BaseHTTPRequestHandler, SimpleHTTPRequestHandler, HTTPServer

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 54321 # Ajustado para a porta 54321, conforme o log

global GLOBAL_HEADERS
global GLOBAL_URL
GLOBAL_HEADERS = {}
GLOBAL_URL = ''

# Configuração para buffering e delay
BUFFER_SIZE_TS = 5 * 1024 * 1024  # 5 MB de buffer para arquivos .ts
BUFFER_SIZE_M3U8_SEGMENTS = 3 # Pré-carregar 3 segmentos para .m3u8
CHUNK_SIZE = 1024 # Tamanho padrão do chunk para streaming
REQUEST_TIMEOUT = 10 # Timeout para requisições em segundos

class handler(SimpleHTTPRequestHandler):
    def basename(self, p):
        """Retorna o componente final de um caminho"""
        i = p.rfind('/') + 1
        return p[i:]

    def get_headers(self, url):
        global GLOBAL_HEADERS
        try:
            url_param = url.split('url=')[1]
        except IndexError:
            url_param = url

        data = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 'Connection': 'keep-alive'}

        # Extraindo cabeçalhos se presentes na URL
        if '|' in url_param or '&' in url_param or 'h123' in url_param:
            extracted_headers = {}
            for header_name in ['Referer', 'Origin', 'Cookie']:
                try:
                    header_value = url_param.split(f'{header_name}=')[1]
                    try:
                        header_value = header_value.split('&')[0]
                    except IndexError:
                        pass
                    extracted_headers[header_name] = unquote_plus(header_value)
                except IndexError:
                    pass

            data.update(extracted_headers)

        if not GLOBAL_HEADERS:
            GLOBAL_HEADERS = data

    def convert_to_m3u8(self, url):
        if '|' in url:
            url = url.split('|')[0]
        elif '&h123' in url:
            url = url.split('&h123')[0]

        if not '.m3u8' in url and not '/hl' in url and url.count(":") == 2 and url.count("/") > 4:
            parsed_url = urlparse(url)
            try:
                host_part1 = f'{parsed_url.scheme}://{parsed_url.netloc}'
                host_part2 = url.split(host_part1)[1]
                url = host_part1 + '/live' + host_part2
                file_name = self.basename(url)
                if '.ts' in file_name:
                    url = url.replace(file_name, file_name.replace('.ts', '.m3u8'))
                else:
                    url = url.replace(file_name, file_name + '.m3u8')
            except Exception as e:
                print(f"Erro ao converter para m3u8: {e}")
        return url

    def _make_request(self, method, url, headers, stream=False):
        """
        Função auxiliar para fazer requisições, com resolução DoT se disponível,
        ou fallback para DNS padrão.
        """
        parsed_url = urlparse(url)
        hostname = parsed_url.hostname
        ip_address = None

        if dns_resolver.DNS_MODULE_AVAILABLE and hostname: # Tenta DoT se o módulo está disponível
            ip_address = dns_resolver.dot_resolver.resolve_with_dot(hostname)

        if ip_address:
            # Monta a URL com o IP, e adiciona o cabeçalho Host original
            new_url = parsed_url._replace(netloc=f"{ip_address}:{parsed_url.port}" if parsed_url.port else ip_address).geturl()
            print(f"Requisição para: {new_url} (original: {url}) via DoT IP")
            if 'Host' not in headers:
                headers['Host'] = hostname # Garante que o cabeçalho Host correto seja enviado
            try:
                if method == 'get':
                    # verify=False é usado aqui porque estamos nos conectando diretamente a um IP,
                    # e o certificado TLS pode não ser válido para o IP, apenas para o hostname.
                    # ISSO PODE REDUZIR A SEGURANÇA. Idealmente, você validaria os certificados.
                    return requests.request(method, new_url, headers=headers, stream=stream, timeout=REQUEST_TIMEOUT, verify=False)
                elif method == 'head':
                    return requests.request(method, new_url, headers=headers, timeout=REQUEST_TIMEOUT, verify=False)
            except requests.exceptions.RequestException as e:
                print(f"Requisição (DoT IP) falhou para {url}: {e}")
                # Em caso de falha com IP, tenta com o nome de domínio original como fallback
                print(f"Tentando fallback para URL original (nome de domínio): {url}")
                try:
                    if method == 'get':
                        return requests.request(method, url, headers=headers, stream=stream, timeout=REQUEST_TIMEOUT)
                    elif method == 'head':
                        return requests.request(method, url, headers=headers, timeout=REQUEST_TIMEOUT)
                except requests.exceptions.RequestException as e_fallback:
                    print(f"Requisição (fallback) falhou para {url}: {e_fallback}")
                    raise # Re-levanta a exceção se o fallback também falhar
        else:
            print(f"Resolução DoT falhou ou não disponível para {hostname}. Tentando com URL original (DNS padrão).")
            # Se a resolução DoT falhar ou não estiver disponível, tenta com o nome de domínio original
            try:
                if method == 'get':
                    return requests.request(method, url, headers=headers, stream=stream, timeout=REQUEST_TIMEOUT)
                elif method == 'head':
                    return requests.request(method, url, headers=headers, timeout=REQUEST_TIMEOUT)
            except requests.exceptions.RequestException as e_fallback:
                print(f"Requisição (original) falhou para {url}: {e_fallback}")
                raise # Re-levanta a exceção se a requisição original também falhar

    def ts(self, url, headers, head=False):
        global GLOBAL_URL
        global GLOBAL_HEADERS

        if not headers:
            headers = GLOBAL_HEADERS

        if GLOBAL_URL and not url.startswith('http'):
            url = GLOBAL_URL + url

        if head:
            try:
                self._make_request('head', url, headers).close()
            except requests.exceptions.RequestException as e:
                print(f"Requisição HEAD falhou para {url}: {e}")
            return

        print(f"Tentando fazer stream TS: {url}")
        buffer = queue.Queue()
        buffer_fill_event = threading.Event()
        stop_streaming = threading.Event()

        def producer():
            nonlocal url # Garante que url é acessível
            for i in range(3):  # Tenta até 3 vezes
                try:
                    with self._make_request('get', url, headers, stream=True) as r:
                        if r.status_code == 200:
                            print(f"Stream TS conectado: {url}")
                            for chunk in r.iter_content(CHUNK_SIZE):
                                if stop_streaming.is_set():
                                    break
                                buffer.put(chunk)
                                if buffer.qsize() * CHUNK_SIZE >= BUFFER_SIZE_TS:
                                    buffer_fill_event.set() # Sinaliza que o buffer está suficientemente preenchido
                            print(f"Terminou de colocar chunks no buffer para {url}")
                            break # Sai do loop de retentativa em caso de sucesso
                        else:
                            print(f"Produtor recebeu status {r.status_code} para {url}. Retentando...")
                except requests.exceptions.RequestException as e:
                    print(f"Requisição do produtor falhou para {url} (tentativa {i+1}): {e}")
                time.sleep(1) # Pequeno atraso antes de retentar
            # Sinaliza o fim do stream
            buffer.put(None)
            buffer_fill_event.set() # Garante que o consumidor seja notificado mesmo se o stream terminar prematuramente

        producer_thread = threading.Thread(target=producer)
        producer_thread.start()

        # Espera o buffer encher até certo ponto ou o stream terminar
        print(f"Esperando o buffer encher para {url}...")
        buffer_fill_event.wait(timeout=REQUEST_TIMEOUT * 2) # Espera até 2x o timeout para o buffer encher

        if buffer.empty() and not producer_thread.is_alive():
            print(f"Falha ao obter dados para {url}. Enviando 404.")
            self.send_response(404)
            self.end_headers()
            self.shutdown_server()
            return

        try:
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            self.end_headers()

            while True:
                chunk = buffer.get()
                if chunk is None: # Sinal de fim de stream
                    break
                try:
                    self.wfile.write(chunk)
                except BrokenPipeError:
                    print(f"Cliente desconectado durante o streaming de {url}.")
                    stop_streaming.set()
                    break
                except Exception as e:
                    print(f"Erro ao escrever chunk para o cliente para {url}: {e}")
                    stop_streaming.set()
                    break
        except Exception as e:
            print(f"Erro durante o streaming TS para {url}: {e}")
        finally:
            stop_streaming.set()
            producer_thread.join(timeout=REQUEST_TIMEOUT) # Dá ao produtor uma chance de terminar

    def m3u8(self, url, headers, head=False):
        global GLOBAL_URL

        if head:
            try:
                self._make_request('head', url, headers).close()
            except requests.exceptions.RequestException as e:
                print(f"Requisição HEAD falhou para {url}: {e}")
            return

        print(f"Tentando buscar M3U8: {url}")
        for i in range(3): # Tenta até 3 vezes
            try:
                r = self._make_request('get', url, headers)
                if r.status_code == 200:
                    print(f"M3U8 buscado com sucesso: {url}")
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.end_headers()

                    text_ = r.text
                    r_parse = urlparse(r.url)
                    base_url = f"{r_parse.scheme}://{r_parse.netloc}"

                    # Reescreve as URLs na playlist M3U8 para apontar para o nosso proxy
                    if '.html' in text_ and 'http' in text_:
                        text_ = text_.replace('http', f'http://{HOST_NAME}:{PORT_NUMBER}/?url=http')
                    elif 'chunklist_' in text_ and not 'http' in text_:
                        file_name = self.basename(url)
                        # Lida com casos em que base_url pode precisar de ajuste
                        if file_name in url:
                            base_url_for_chunks = url.replace(file_name, '')
                        else:
                            base_url_for_chunks = base_url
                        if base_url_for_chunks.endswith('/'):
                            base_url_for_chunks = base_url_for_chunks[:-1]
                        text_ = text_.replace('chunklist_', f'http://{HOST_NAME}:{PORT_NUMBER}/?url={base_url_for_chunks}/chunklist_')
                    elif 'media_' in text_ and '.ts' in text_ and not 'http' in text_:
                        file_name = self.basename(url)
                        if file_name in url:
                            base_url_for_media = url.replace(file_name, '')
                        else:
                            base_url_for_media = base_url
                        if base_url_for_media.endswith('/'):
                            base_url_for_media = base_url_for_media[:-1]
                        text_ = text_.replace('media_', f'http://{HOST_NAME}:{PORT_NUMBER}/?url={base_url_for_media}/media_')
                    elif not '/hl' in text_ and not 'http' in text_:
                        file_name = self.basename(r.url)
                        base_url_actual = r.url.replace(file_name, '')
                        GLOBAL_URL = base_url_actual # Define a URL base global para caminhos relativos
                        # Pré-busca futuros segmentos
                        lines = text_.strip().split('\n')
                        updated_lines = []
                        for j, line in enumerate(lines):
                            if line.endswith('.ts') and not line.startswith('#'):
                                full_segment_url = f"{GLOBAL_URL}{line}"
                                # Opcionalmente, pré-busca segmentos em uma thread separada
                                if j < len(lines) - BUFFER_SIZE_M3U8_SEGMENTS:
                                    print(f"Pré-buscando segmento: {full_segment_url}")
                                    threading.Thread(target=self.ts, args=(full_segment_url, headers, True)).start()
                                updated_lines.append(f'http://{HOST_NAME}:{PORT_NUMBER}/?url={full_segment_url}')
                            elif line.startswith('/') and not line.startswith('#'): # Lida com caminhos relativos para playlists
                                full_playlist_url = f"{base_url}{line}"
                                updated_lines.append(f'http://{HOST_NAME}:{PORT_NUMBER}/?url={full_playlist_url}')
                            else:
                                updated_lines.append(line)
                        text_ = '\n'.join(updated_lines)

                    elif '/hl' in text_ and not 'http' in text_:
                        text_ = text_.replace('/hl', f'http://{HOST_NAME}:{PORT_NUMBER}/?url={base_url}/hl')
                    else:
                        text_ = text_.replace('http', f'http://{HOST_NAME}:{PORT_NUMBER}/?url=http')

                    self.wfile.write(text_.encode("utf-8"))
                    r.close()
                    return # Processado com sucesso, sai da função
                else:
                    print(f"Requisição M3U8 falhou com status {r.status_code} para {url}. Retentando...")
            except requests.exceptions.RequestException as e:
                print(f"Requisição M3U8 falhou para {url} (tentativa {i+1}): {e}")
            time.sleep(1) # Pequeno atraso antes de retentar

        print(f"Falha ao buscar M3U8 após várias tentativas para {url}. Enviando 404.")
        self.send_response(404)
        self.end_headers()
        self.shutdown_server()

    def shutdown_server(self):
        """Função auxiliar para desligar o servidor em uma thread separada."""
        def _shutdown(server):
            server.shutdown()
        t = threading.Thread(target=_shutdown, args=(self.server,))
        t.start()

    def do_HEAD(self):
        global GLOBAL_HEADERS
        global GLOBAL_URL
        try:
            url = self.path.split('url=')[1]
            url = unquote_plus(url)
            url = unquote(url)
        except IndexError:
            url = ''

        if url:
            self.get_headers(url)
            url = self.convert_to_m3u8(url)

        if self.path == '/check':
            self.send_response(200)
            self.end_headers()
        elif self.path == '/stop':
            self.send_response(200)
            self.end_headers()
            self.shutdown_server()
        elif url.startswith('http') and '/hl' in url and '.m3u8' in url:
            self.m3u8(url, GLOBAL_HEADERS, head=True)
        elif not url.startswith('http') and '.m3u8' in self.path:
            path_url = self.path[1:] if self.path.startswith('/') else self.path
            url = GLOBAL_URL + path_url
            self.m3u8(url, GLOBAL_HEADERS, head=True)
        elif not 'http' in url and not '/hl' in url and '.ts' in self.path:
            self.ts(self.path, GLOBAL_HEADERS, head=True)
        elif url.endswith(".ts") or ('/hl' in url and not url.endswith(".ts") and not url.endswith(".m3u8")):
            self.ts(url, GLOBAL_HEADERS, head=True)
        elif url.endswith(".html"):
            self.ts(url, GLOBAL_HEADERS, head=True)
        elif '.m3u8' in url:
            self.m3u8(url, GLOBAL_HEADERS, head=True)
        else: # Lida com caminhos desconhecidos
            self.send_response(404)
            self.end_headers()


    def do_GET(self):
        global GLOBAL_HEADERS
        global GLOBAL_URL
        try:
            url = self.path.split('url=')[1]
            url = unquote_plus(url)
            url = unquote(url)
        except IndexError:
            url = ''

        if url:
            self.get_headers(url)
            url = self.convert_to_m3u8(url)

        if self.path == '/check':
            self.send_response(200)
            self.end_headers()
        elif self.path == '/stop':
            self.send_response(200)
            self.end_headers()
            self.shutdown_server()
        elif url.startswith('http') and '/hl' in url and '.m3u8' in url:
            self.m3u8(url, GLOBAL_HEADERS)
        elif not url.startswith('http') and '.m3u8' in self.path:
            path_url = self.path[1:] if self.path.startswith('/') else self.path
            url = GLOBAL_URL + path_url
            self.m3u8(url, GLOBAL_HEADERS)
        elif not 'http' in url and not '/hl' in url and '.ts' in self.path:
            self.ts(self.path, GLOBAL_HEADERS)
        elif url.endswith(".ts") or ('/hl' in url and not url.endswith(".ts") and not url.endswith(".m3u8")):
            self.ts(url, GLOBAL_HEADERS)
        elif url.endswith(".html"):
            self.ts(url, GLOBAL_HEADERS)
        elif '.m3u8' in url:
            self.m3u8(url, GLOBAL_HEADERS)
        else: # Lida com caminhos desconhecidos
            self.send_response(404)
            self.end_headers()

httpd = None # Inicializa como None para ser criado na primeira chamada
httpd_lock = threading.Lock() # Protege a criação/acesso a httpd

def create_httpd():
    """Cria e retorna uma nova instância de HTTPServer."""
    global httpd
    with httpd_lock:
        if httpd is None or not httpd.is_serving(): # Verifica se o servidor não existe ou não está servindo
            try:
                # Tenta criar o servidor. Se a porta estiver em uso, pode levantar um OSError.
                httpd = HTTPServer(('', PORT_NUMBER), handler)
                print(f"Servidor HTTP criado em {HOST_NAME}:{PORT_NUMBER}")
            except socket.error as e:
                print(f"Erro ao criar servidor HTTP na porta {PORT_NUMBER}: {e}. A porta pode estar em uso.")
                httpd = None # Reseta para None se falhar na criação
            except Exception as e:
                print(f"Erro inesperado ao criar servidor HTTP: {e}")
                httpd = None
        return httpd


def serve_forever(httpd_instance):
    """Função para rodar o servidor HTTP indefinidamente."""
    if httpd_instance:
        print(f"Servidor iniciado em {HOST_NAME}:{PORT_NUMBER}")
        try:
            httpd_instance.serve_forever()
        except Exception as e:
            print(f"Servidor parado com um erro: {e}")
        finally:
            httpd_instance.server_close()
            print("Servidor fechado.")
    else:
        print("Não foi possível iniciar o servidor: instância httpd é None.")


class mediaserver:
    def __init__(self):
        self.server_thread = None

    def in_use(self):
        url = f'http://{HOST_NAME}:{PORT_NUMBER}/check'
        try:
            r = requests.head(url, timeout=1)
            return r.status_code == 200
        except requests.exceptions.RequestException:
            return False

    def start(self):
        global httpd
        # Tenta criar o servidor antes de iniciar a thread, se ainda não estiver criado
        if httpd is None:
            httpd = create_httpd()
            if httpd is None: # Se a criação falhou, não podemos prosseguir
                print("Não foi possível criar a instância do servidor HTTP. Não é possível iniciar.")
                return

        if not self.in_use():
            print("Iniciando servidor de mídia...")
            # Verifica se a thread já existe e está viva para evitar múltiplas threads
            if self.server_thread is None or not self.server_thread.is_alive():
                self.server_thread = threading.Thread(target=serve_forever, args=(httpd,))
                self.server_thread.daemon = True # Permite que o programa principal saia mesmo se a thread estiver rodando
                self.server_thread.start()
                # Dá um tempo para o servidor iniciar e ficar pronto
                time.sleep(3) # Aumentado o delay para 3 segundos

            # Loop de verificação para garantir que o servidor está realmente rodando
            max_attempts = 5
            attempts = 0
            while not self.in_use() and attempts < max_attempts:
                print(f"Aguardando servidor iniciar... ({attempts+1}/{max_attempts})")
                time.sleep(1)
                attempts += 1

            if not self.in_use():
                print("Servidor falhou ao iniciar ou está inacessível após várias tentativas.")
            else:
                print("Servidor de mídia iniciado com sucesso.")
        else:
            print("Servidor de mídia já em execução.")


    def stop(self):
        # Isso fará com que o loop serve_forever saia graciosamente
        if self.in_use():
            print("Tentando parar o servidor de mídia via requisição HTTP...")
            req_shutdown()
            # Dá um momento para o servidor desligar
            time.sleep(1)
            if self.server_thread and self.server_thread.is_alive():
                print("Esperando a thread do servidor terminar...")
                self.server_thread.join(timeout=5) # Espera a thread terminar
                if self.server_thread.is_alive():
                    print("A thread do servidor não terminou graciosamente.")
            print("Servidor de mídia parado.")
        else:
            print("Servidor de mídia não está rodando.")

def prepare_url(url):
    # Removida a chamada req_shutdown() daqui para evitar a corrida
    # O monitor() thread em default.py é responsável por chamar req_shutdown()
    # quando a reprodução termina.

    try:
        url = unquote_plus(url)
    except Exception as e:
        print(f"Erro ao decodificar (unquote_plus): {e}")
    try:
        url = unquote(url)
    except Exception as e:
        print(f"Erro ao decodificar (unquote): {e}")

    # Isso substitui '|' por '&h123=true&' que parece ser um separador de cabeçalho customizado.
    # Isso deve ser cuidadosamente revisado se causar problemas com URLs reais.
    # Uma forma mais robusta de passar cabeçalhos seria usar parâmetros de URL separados.
    url = url.replace('|', '&h123=true&')
    url = quote_plus(url)
    proxied_url = f'http://{HOST_NAME}:{PORT_NUMBER}/?url=' + url
    return proxied_url

def req_shutdown():
    url = f'http://{HOST_NAME}:{PORT_NUMBER}/stop'
    try:
        r = requests.get(url, timeout=2)
        r.close()
        print(f"Requisição de desligamento enviada para {url}")
    except requests.exceptions.RequestException as e:
        print(f"Falha ao enviar requisição de desligamento para {url}: {e}")

# Exemplo de uso (descomente para testar)
# if __name__ == '__main__':
#     server_instance = mediaserver()
#     server_instance.start()
#
#     # Simula a abertura de um canal
#     test_url = "http://example.com/playlist.m3u8"
#     prepared_test_url = prepare_url(test_url)
#     print(f"URL preparada para o cliente: {prepared_test_url}")
#
#     # Simula a abertura de outro canal após um atraso
#     # Isso deve acionar o desligamento do stream/servidor anterior se ativo
#     time.sleep(10)
#     another_test_url = "http://example.com/another_playlist.m3u8"
#     prepared_another_url = prepare_url(another_test_url)
#     print(f"URL preparada para o cliente (novo canal): {prepared_another_url}")
#
#     # Mantém a thread principal viva por um tempo para permitir que o servidor rode
#     try:
#         while True:
#             time.sleep(1)
#     except KeyboardInterrupt:
#         print("Ctrl+C detectado. Parando o servidor.")
#         server_instance.stop()
