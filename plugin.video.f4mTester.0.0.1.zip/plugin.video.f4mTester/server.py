import six
import os # Adicionado para os.path.basename
try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode  # Python 3
except ImportError:
    from urlparse import urlparse, parse_qs  # Python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
if six.PY3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler # HTTPServer já importado
    from SimpleHTTPServer import SimpleHTTPRequestHandler

import threading
import socket
import requests
import time
import json

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 55864
DOH_SERVER_URL = "https://mozilla.cloudflare-dns.com/dns-query" # Servidor DoH como constante
DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36' # Atualizado e constante

# Globais para estado do stream atual. Serão resetados para novos canais.
GLOBAL_HEADERS = {}
GLOBAL_URL = '' # Base URL para segmentos relativos

def query_doh(domain, record_type="A", doh_server=DOH_SERVER_URL):
    """Resolve um domínio usando DNS over HTTPS e retorna o endereço IP."""
    headers = {
        "Accept": "application/dns-json",
        "User-Agent": DEFAULT_USER_AGENT
    }
    params = {
        "name": domain,
        "type": record_type
    }
    
    try:
        response = requests.get(doh_server, headers=headers, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        if "Answer" in data:
            for answer in data["Answer"]:
                if answer["type"] == 1:  # Type 1 is A record
                    return answer["data"]  # Retorna o primeiro IP válido
        print(f"Nenhum registro A encontrado para {domain} via DoH.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Falha na resolução DoH para {domain}: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"Erro ao decodificar JSON da resposta DoH para {domain}: {e}")
        return None

class Handler(SimpleHTTPRequestHandler): # Nome da classe alterado para Handler (PEP8)
    # Sobrescreve log_message para silenciar logs no console ou personalizá-los
    def log_message(format, *args):
        # Comente a linha abaixo para reativar os logs HTTP padrão
        # super().log_message(format, *args)
        # Ou, para logs personalizados:
        # print(f"LOG: {format % args}")
        pass

    def _reset_stream_state(self):
        """Reseta o estado global para um novo stream."""
        global GLOBAL_HEADERS, GLOBAL_URL
        print("INFO: Resetando estado do stream global (headers e base URL).")
        GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}
        GLOBAL_URL = ''

    def _get_parsed_url_param(self):
        """Extrai e decodifica o parâmetro 'url' do caminho da requisição."""
        try:
            raw_param = self.path.split('url=', 1)[1]
            # Decodificar em etapas pode ser mais robusto para URLs duplamente codificadas
            decoded_param = unquote_plus(raw_param)
            decoded_param = unquote(decoded_param) # Adicional para casos sem o '+'
            return decoded_param
        except IndexError:
            return None # 'url=' não encontrado
        except Exception as e:
            print(f"Erro ao decodificar parâmetro URL '{self.path}': {e}")
            return None

    def get_headers_from_url_params(self, url_with_params):
        """
        Extrai cabeçalhos (Referer, Origin, Cookie) de uma string de URL que os contém como parâmetros.
        Retorna um dicionário com os cabeçalhos extraídos.
        """
        custom_headers = {}
        # Tenta extrair 'url=' para isolar os parâmetros de cabeçalho, se estiverem no valor do parâmetro 'url'
        try:
            # A URL real pode estar antes dos parâmetros de cabeçalho, ou os parâmetros podem estar sozinhos
            param_part = url_with_params
            if 'url=' in self.path: # Se 'url=' está no path, url_with_params é o valor desse 'url='
                 # Os parâmetros de cabeçalho estão dentro de url_with_params
                 pass # Não precisa fazer nada extra aqui
            
            # Verifica se os delimitadores de cabeçalho customizados estão presentes
            if '|' in param_part or '&h123' in param_part or any(k+'=' in param_part for k in ['Referer', 'Origin', 'Cookie']):
                params_qs = parse_qs(urlparse(f"http://dummy?{param_part.split('?',1)[-1]}").query)

                referer = params_qs.get('Referer', [None])[0] or params_qs.get('referer', [None])[0]
                origin = params_qs.get('Origin', [None])[0] or params_qs.get('origin', [None])[0]
                cookie = params_qs.get('Cookie', [None])[0] or params_qs.get('cookie', [None])[0]

                if referer:
                    custom_headers['Referer'] = unquote_plus(referer)
                if origin:
                    custom_headers['Origin'] = unquote_plus(origin)
                if cookie:
                    custom_headers['Cookie'] = unquote_plus(cookie)
        except Exception as e:
            print(f"DEBUG: Erro ao parsear cabeçalhos de '{url_with_params}': {e}")
            # Não faz nada, apenas não adiciona cabeçalhos customizados

        return custom_headers

    def convert_to_m3u8_url(self, url):
        """Converte uma URL de stream genérica para uma URL .m3u8 se aplicável."""
        if '|' in url:
            url = url.split('|')[0]
        elif '&h123' in url: # &h123 era usado para separar URL real de headers customizados
            url = url.split('&h123')[0]

        # Heurística para identificar URLs de stream que precisam ser convertidas para .m3u8
        # Ex: http://server:port/username/password/12345 (sem extensão .ts ou .m3u8)
        is_potential_livestream_url = not ('.m3u8' in url or '/hl' in url or '.ts' in url) and \
                                      url.count(":") == 2 and url.count("/") > 4
        
        if is_potential_livestream_url:
            try:
                parsed_url = urlparse(url)
                base_path = f"{parsed_url.scheme}://{parsed_url.netloc}"
                path_segment = url.split(base_path, 1)[1]
                
                # Adiciona /live/ se não estiver presente, comum em alguns IPTVs
                if not path_segment.startswith('/live/'):
                     path_segment = '/live' + path_segment # Garante que comece com /

                new_url = base_path + path_segment
                
                # Garante que termine com .m3u8
                if os.path.splitext(new_url)[1] != '.ts': # Se não for .ts, assume que deve ser .m3u8
                    filename = os.path.basename(new_url)
                    if '.' in filename: # Se já tem uma extensão, substitui por .m3u8
                        new_filename = os.path.splitext(filename)[0] + '.m3u8'
                    else: # Se não tem extensão, adiciona .m3u8
                        new_filename = filename + '.m3u8'
                    url = new_url.replace(filename, new_filename)
                else: # se for .ts, transforma em .m3u8
                    url = new_url.replace('.ts', '.m3u8')

                print(f"INFO: URL convertida para M3U8: {url}")
            except Exception as e:
                print(f"ERRO: Falha ao converter URL para M3U8 ({url}): {e}")
                pass # Retorna URL original em caso de falha
        return url

    def _make_request_with_doh(self, url, headers, stream=False, head=False, timeout=10):
        """Faz uma requisição HTTP(S), opcionalmente usando DoH e com retries."""
        parsed_original_url = urlparse(url)
        hostname = parsed_original_url.hostname
        
        # Tenta resolver com DoH
        ip = query_doh(hostname) if hostname else None
        
        req_url = url
        effective_headers = headers.copy()

        if ip:
            # Constrói a URL com o IP resolvido via DoH
            # Mantém o path, query e fragment originais
            req_url = parsed_original_url._replace(netloc=ip).geturl()
            effective_headers["Host"] = hostname  # Adiciona o Host header original
            print(f"INFO: Usando IP {ip} (via DoH) para {hostname}. URL: {req_url}")
        else:
            print(f"AVISO: Falha ao resolver {hostname} via DoH ou hostname ausente. Usando DNS do sistema para {url}.")

        max_retries = 3
        for attempt in range(max_retries):
            try:
                if head:
                    response = requests.head(req_url, headers=effective_headers, timeout=timeout)
                else:
                    response = requests.get(req_url, headers=effective_headers, stream=stream, timeout=timeout)
                response.raise_for_status() # Levanta exceção para status ruins (4xx, 5xx)
                return response
            except requests.exceptions.RequestException as e:
                print(f"ERRO na requisição para {req_url} (tentativa {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(0.5 * (attempt + 1)) # Backoff exponencial simples
                else:
                    raise # Re-levanta a exceção após a última tentativa

    def _handle_ts_request(self, target_url, current_headers):
        """Lida com requisições de segmentos .ts."""
        global GLOBAL_URL # Usado para resolver URLs relativas de segmentos
        
        if not target_url.startswith('http') and GLOBAL_URL:
            # Remove barras duplicadas se GLOBAL_URL terminar com / e target_url começar com /
            if GLOBAL_URL.endswith('/') and target_url.startswith('/'):
                full_url = GLOBAL_URL + target_url[1:]
            elif not GLOBAL_URL.endswith('/') and not target_url.startswith('/'):
                 full_url = GLOBAL_URL + '/' + target_url
            else:
                full_url = GLOBAL_URL + target_url
            print(f"INFO: Resolvendo URL relativa do TS: {target_url} -> {full_url}")
        else:
            full_url = target_url
        
        try:
            r = self._make_request_with_doh(full_url, current_headers, stream=True)
            self.send_response(200)
            self.send_header('Content-type', 'video/mp2t')
            # Adicionar cabeçalhos para permitir CORS se o player estiver em um domínio diferente
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            # Buffer de escrita para estabilizar a conexão
            # Lê em chunks e escreve, o buffer é gerenciado por iter_content e pela escrita no socket
            for chunk in r.iter_content(chunk_size=8192): # Tamanho do chunk pode ser ajustado
                if chunk: # Garante que o chunk não está vazio
                    try:
                        self.wfile.write(chunk)
                    except (socket.error, BrokenPipeError, ConnectionResetError) as e:
                        print(f"ERRO: Conexão interrompida ao enviar TS: {e}")
                        break # Para de enviar se o cliente desconectar
            r.close()
        except requests.exceptions.RequestException as e:
            print(f"ERRO: Falha ao buscar segmento TS {full_url}: {e}")
            self.send_error(404, f"Falha ao buscar TS: {e}")
        except Exception as e:
            print(f"ERRO inesperado ao processar TS {full_url}: {e}")
            self.send_error(500, f"Erro interno ao processar TS: {e}")


    def _handle_m3u8_request(self, target_url, current_headers):
        """Lida com requisições de playlists .m3u8."""
        global GLOBAL_URL # Será atualizado se o M3U8 tiver URLs relativas
        
        try:
            r = self._make_request_with_doh(target_url, current_headers, timeout=10) # Timeout maior para M3U8
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl') # ou 'audio/mpegurl'
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            playlist_content = r.text
            
            # Define a GLOBAL_URL base para URLs relativas na playlist
            # A GLOBAL_URL deve ser o caminho até o diretório que contém os segmentos
            parsed_response_url = urlparse(r.url) # Usa a URL de resposta, pode ter redirecionamentos
            
            # Tenta obter o caminho base da URL do M3U8
            path_parts = parsed_response_url.path.split('/')
            if len(path_parts) > 1 and ('.' in path_parts[-1] or path_parts[-1] == ''): # Se o último elemento é um arquivo ou termina com /
                base_path_for_segments = '/'.join(path_parts[:-1])
            else:
                base_path_for_segments = parsed_response_url.path

            # Garante que base_path_for_segments comece com / e não termine com / a menos que seja a raiz
            if not base_path_for_segments.startswith('/'):
                 base_path_for_segments = '/' + base_path_for_segments
            if len(base_path_for_segments) > 1 and base_path_for_segments.endswith('/'):
                 base_path_for_segments = base_path_for_segments[:-1]
            
            GLOBAL_URL = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{base_path_for_segments}"
            print(f"INFO: GLOBAL_URL base para segmentos definida como: {GLOBAL_URL}")

            processed_lines = []
            for line in playlist_content.splitlines():
                line = line.strip()
                if not line or line.startswith('#EXT-X-KEY'): # Mantém linhas de chave como estão por enquanto (podem precisar de proxy também)
                     # TODO: Se EXT-X-KEY URI for relativo, precisará ser proxyado também.
                     # Se URI for absoluto, verificar se precisa de proxy (se for outro domínio)
                    if line.startswith('#EXT-X-KEY') and 'URI="' in line and not '://' in line.split('URI="')[1].split('"')[0]:
                        key_uri_part = line.split('URI="')[1].split('"')[0]
                        # Constrói URL completa para a chave
                        if key_uri_part.startswith('/'):
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={parsed_response_url.scheme}://{parsed_response_url.netloc}{key_uri_part}"
                        else:
                            proxied_key_uri = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={GLOBAL_URL}/{key_uri_part}"
                        line = line.replace(f'URI="{key_uri_part}"', f'URI="{proxied_key_uri}"')
                        print(f"INFO: Chave URI proxyada: {line}")
                    processed_lines.append(line)
                elif line.startswith('#'): # Mantém outros comentários e tags HLS
                    processed_lines.append(line)
                elif line.startswith('http://') or line.startswith('https://'):
                    # URL absoluta, proxyar através do nosso servidor
                    proxied_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(line)}"
                    processed_lines.append(proxied_url)
                else:
                    # URL relativa, construir completa e proxyar
                    # Se a linha já começa com / (relativo à raiz do servidor original), não precisa de GLOBAL_URL (ou GLOBAL_URL já contém o host)
                    # O cliente HLS geralmente resolve URLs relativas (sem / no início) em relação à URL do M3U8.
                    # O proxy precisa garantir que essas URLs relativas sejam encaminhadas corretamente.
                    # A lógica de reescrita aqui é para que o player peça ao *nosso proxy* o segmento.
                    # Se GLOBAL_URL foi bem definida, o player requisitará ao nosso proxy:
                    # http://localhost:PORT/?url=segmento.ts  (se segmento.ts estava no m3u8)
                    # ou http://localhost:PORT/path/segmento.ts (se o m3u8 reescreveu para isso)
                    # Para URLs relativas (ex: "segment.ts", "sub/segment.ts")
                    # O player vai requisitar ao nosso proxy usando o caminho relativo ao M3U8 que ele acabou de buscar.
                    # Ex: Se o M3U8 foi buscado de /?url=http://origem/stream.m3u8
                    # e ele contém "video.ts", o player pode pedir /video.ts ou /?url=video.ts (depende do player)
                    # A nossa lógica de roteamento no do_GET/do_HEAD precisa pegar esse /video.ts e usar GLOBAL_URL.

                    # Para simplificar, vamos reescrever URLs relativas para serem absolutas para o nosso proxy.
                    # Se a linha for algo como 'segment1.ts' ou 'media/segment1.ts'
                    full_original_url = ""
                    if line.startswith('/'): # Relativo ao host original
                        full_original_url = f"{parsed_response_url.scheme}://{parsed_response_url.netloc}{line}"
                    else: # Relativo ao diretório do M3U8
                        full_original_url = f"{GLOBAL_URL}/{line}" # GLOBAL_URL deve ser o caminho do diretório
                    
                    proxied_url = f"http://{HOST_NAME}:{PORT_NUMBER}/?url={quote_plus(full_original_url)}"
                    processed_lines.append(proxied_url)
            
            final_playlist = "\n".join(processed_lines)
            self.wfile.write(final_playlist.encode("utf-8"))
            r.close()

        except requests.exceptions.RequestException as e:
            print(f"ERRO: Falha ao buscar M3U8 {target_url}: {e}")
            self.send_error(404, f"Falha ao buscar M3U8: {e}")
            # Considerar desligar o servidor em caso de falha ao buscar o M3U8 principal?
            # self._shutdown_server()
        except Exception as e:
            print(f"ERRO inesperado ao processar M3U8 {target_url}: {e}")
            self.send_error(500, f"Erro interno ao processar M3U8: {e}")

    def _handle_generic_request(self, target_url, current_headers):
        """Lida com requisições genéricas (ex: .html) como se fossem TS (tentativa de stream)."""
        print(f"AVISO: Lidando com requisição genérica {target_url} como se fosse TS.")
        self._handle_ts_request(target_url, current_headers) # Trata como TS por padrão

    def _shutdown_server(self):
        """Agenda o desligamento do servidor."""
        print("INFO: Agendando desligamento do servidor...")
        def actual_shutdown(server_instance):
            server_instance.shutdown()
            print("INFO: Servidor HTTP desligado.")
        
        # Usar o httpd global definido no final do script
        threading.Thread(target=actual_shutdown, args=(httpd,)).start()

    def _process_request(self, method_is_head=False):
        """Lida com a lógica principal da requisição GET ou HEAD."""
        global GLOBAL_HEADERS, GLOBAL_URL # Controla o estado do stream

        original_path = self.path # Salva o path original para referência

        # 1. Verifica se é um endpoint de controle
        if original_path == '/check':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return
            self.wfile.write(b"OK")
            return
        elif original_path == '/stop':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if method_is_head: return # Só envia headers para HEAD
            self.wfile.write(b"Stopping server...")
            self._shutdown_server()
            return

        # 2. Extrai e decodifica o parâmetro 'url'
        target_url_from_param = self._get_parsed_url_param() # URL real do stream/segmento
        
        current_headers = GLOBAL_HEADERS.copy() # Começa com os globais (que podem ter sido resetados)

        # 3. Lógica de "novo canal": se um novo M3U8 principal é requisitado via '/?url=', reseta o estado.
        if original_path.startswith('/?url=') and target_url_from_param:
            # Tenta converter para URL M3U8 para ver se é um M3U8 principal
            # A string original de target_url_from_param é usada para a conversão
            potential_m3u8_url = self.convert_to_m3u8_url(target_url_from_param)
            if '.m3u8' in potential_m3u8_url: # Se parece ser um M3U8
                print(f"INFO: Nova URL M3U8 principal detectada: {target_url_from_param}. Resetando estado.")
                self._reset_stream_state() # Reseta GLOBAL_HEADERS e GLOBAL_URL
                current_headers = GLOBAL_HEADERS.copy() # Pega os headers resetados
            
            # Atualiza current_headers com quaisquer cabeçalhos passados na URL do novo canal.
            # target_url_from_param pode conter algo como "http://...m3u8|Referer=..."
            # get_headers_from_url_params deve extrair esses cabeçalhos
            # e a URL real a ser buscada (target_url_for_fetching) não deve ter esses params.
            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
            
            # A URL real a ser buscada não deve conter os parâmetros de cabeçalho customizados
            if '|' in target_url_from_param or '&h123' in target_url_from_param:
                 # Remove a parte dos parâmetros de cabeçalho para obter a URL limpa
                 target_url_for_fetching = target_url_from_param.split('|')[0].split('&h123')[0]
            else:
                 target_url_for_fetching = target_url_from_param
        elif target_url_from_param: # É uma requisição com /?url= mas não um novo M3U8 (ex: segmento TS)
            target_url_for_fetching = target_url_from_param # Usa a URL do parâmetro
            # Para segmentos, os headers já devem estar em GLOBAL_HEADERS (do M3U8 pai)
            # Mas se houver headers na URL do segmento, eles podem ter prioridade (raro)
            custom_params_in_url = self.get_headers_from_url_params(target_url_from_param)
            current_headers.update(custom_params_in_url)
            if '|' in target_url_from_param or '&h123' in target_url_from_param:
                 target_url_for_fetching = target_url_from_param.split('|')[0].split('&h123')[0]
        else: # Não é /?url=, então é uma URL relativa (ex: /segment.ts)
            target_url_for_fetching = original_path # Usa o path diretamente
            # Headers já devem estar em GLOBAL_HEADERS

        # 4. Converte para M3U8 se necessário (aplica-se principalmente a URLs de entrada)
        # Se target_url_from_param existia, target_url_for_fetching é essa URL (limpa).
        # Se não, é original_path.
        # Só converte se for uma URL http, não um path local
        if target_url_for_fetching.startswith('http'):
            processed_target_url = self.convert_to_m3u8_url(target_url_for_fetching)
        else: # Para paths locais (ex: /segmento.ts), não tenta converter para m3u8 aqui
            processed_target_url = target_url_for_fetching
        
        # Se após o processamento inicial não temos uma URL http e GLOBAL_URL está vazia,
        # e não é um path de controle, não há o que servir.
        if not processed_target_url.startswith('http') and not GLOBAL_URL and not original_path.startswith('/'):
            self.send_error(400, "URL base não definida para caminho relativo e sem parâmetro 'url'.")
            return

        # 5. Roteamento da requisição
        # Se for um HEAD request, apenas preparamos a resposta e retornamos
        # (as funções _handle_* precisam saber se é HEAD) - Por enquanto, trataremos HEAD de forma simples
        # ou deixaremos que as funções _handle_* decidam (elas não estão preparadas para HEAD ainda).
        # Para simplificar, HEAD requests não são totalmente suportados para M3U8/TS aqui.

        # Prioriza M3U8
        if '.m3u8' in processed_target_url:
            print(f"DEBUG: Roteando para M3U8: {processed_target_url}")
            if method_is_head: self.send_response(200); self.send_header('Content-Type', 'application/vnd.apple.mpegurl'); self.end_headers(); return
            self._handle_m3u8_request(processed_target_url, current_headers)
        # Em seguida, TS ou algo que se pareça com HLS (contém /hl e não é M3U8)
        elif '.ts' in processed_target_url or ('/hl' in processed_target_url and not processed_target_url.endswith(".m3u8")):
            print(f"DEBUG: Roteando para TS: {processed_target_url}")
            if method_is_head: self.send_response(200); self.send_header('Content-type', 'video/mp2t'); self.end_headers(); return
            self._handle_ts_request(processed_target_url, current_headers)
        # Se a URL original (do parâmetro 'url') termina com .html, trata como genérico (tentará como TS)
        elif target_url_from_param and target_url_from_param.endswith(".html"):
            print(f"DEBUG: Roteando para genérico (original .html): {processed_target_url}")
            if method_is_head: self.send_response(200); self.end_headers(); return # Tipo de conteúdo desconhecido para HEAD
            self._handle_generic_request(processed_target_url, current_headers)
        # Se o path original (sem ?url=) contém .m3u8 ou .ts (requisição relativa)
        elif not target_url_from_param and ('.m3u8' in original_path or '.ts' in original_path):
            # processed_target_url aqui seria igual a original_path
            if '.m3u8' in original_path:
                print(f"DEBUG: Roteando para M3U8 (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-Type', 'application/vnd.apple.mpegurl'); self.end_headers(); return
                self._handle_m3u8_request(original_path, current_headers) # Passa o path original
            elif '.ts' in original_path:
                print(f"DEBUG: Roteando para TS (path relativo): {original_path}")
                if method_is_head: self.send_response(200); self.send_header('Content-type', 'video/mp2t'); self.end_headers(); return
                self._handle_ts_request(original_path, current_headers) # Passa o path original
        else:
            # Se chegou aqui, pode ser uma URL base que não foi convertida (ex: http://site.com/stream/)
            # ou um path desconhecido.
            if target_url_from_param: # Se havia um ?url=
                 print(f"AVISO: Tipo de URL não explicitamente tratado via ?url=: {target_url_from_param}. Tentando como genérico.")
                 if method_is_head: self.send_response(200); self.end_headers(); return
                 self._handle_generic_request(processed_target_url, current_headers) # Tenta como genérico
            else:
                 print(f"ERRO: Path não reconhecido: {original_path}")
                 self.send_error(404, "Recurso não encontrado ou tipo não suportado.")


    def do_HEAD(self):
        self._process_request(method_is_head=True)
    
    def do_GET(self):
        self._process_request(method_is_head=False)

# Inicializa GLOBAL_HEADERS com valores padrão. Será resetado para cada novo canal M3U8.
GLOBAL_HEADERS = {'User-Agent': DEFAULT_USER_AGENT, 'Connection': 'keep-alive'}

httpd = None # Será inicializado em mediaserver.start()

def _serve_forever_wrapper(server_instance):
    """Wrapper para server_forever para facilitar o gerenciamento de threads."""
    try:
        print(f"INFO: Servidor HTTP iniciado em {HOST_NAME}:{PORT_NUMBER}")
        server_instance.serve_forever()
    except KeyboardInterrupt:
        print("\nINFO: Desligamento solicitado pelo usuário (KeyboardInterrupt).")
    except Exception as e:
        print(f"ERRO CRÍTICO: Falha no loop principal do servidor: {e}")
    finally:
        server_instance.server_close()
        print("INFO: Servidor HTTP finalizado.")

class MediaServer: # Nome da classe alterado para MediaServer (PEP8)
    def __init__(self):
        self.server_thread = None
        self.httpd_instance = None

    def is_in_use(self):
        """Verifica se a porta do servidor está em uso."""
        if not self.httpd_instance or not self.server_thread or not self.server_thread.is_alive():
            # Tenta uma conexão rápida para ver se algo está ouvindo
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.1) # Timeout curto
            try:
                s.connect((HOST_NAME, PORT_NUMBER))
                s.close()
                # Se conectou, pode ser este servidor ou outro processo
                # Para ter certeza que é *este* servidor, checa a thread
                if self.httpd_instance and self.server_thread and self.server_thread.is_alive():
                    return True
                print(f"AVISO: Porta {PORT_NUMBER} em uso, mas não pelo servidor gerenciado ou estado inconsistente.")
                return True # Assume que está em uso se a porta estiver ocupada
            except (socket.timeout, socket.error):
                return False # Não conseguiu conectar, porta livre ou servidor não responde
            finally:
                s.close()
        return True # Se a thread e a instância existem e estão vivas

    def start(self):
        global httpd # Para que a instância do HTTPServer seja acessível globalmente (para shutdown)
        if not self.is_in_use():
            print("INFO: Iniciando servidor HTTP MediaServer...")
            self.httpd_instance = HTTPServer(('', PORT_NUMBER), Handler)
            httpd = self.httpd_instance # Atribui à variável global para que _shutdown_server funcione
            
            self.server_thread = threading.Thread(target=_serve_forever_wrapper, args=(self.httpd_instance,))
            self.server_thread.daemon = True  # Permite que o programa principal saia mesmo se a thread estiver rodando
            self.server_thread.start()
            time.sleep(0.5) # Pequeno delay para o servidor iniciar
            if self.server_thread.is_alive():
                print("INFO: MediaServer iniciado com sucesso.")
            else:
                print("ERRO: Falha ao iniciar MediaServer.")
                self.httpd_instance = None
                httpd = None
        else:
            print("INFO: MediaServer já está em execução ou a porta está ocupada.")

    def stop(self):
        """Para o servidor HTTP se estiver em execução."""
        global httpd
        print("INFO: Solicitando parada do MediaServer...")
        if self.httpd_instance:
            self.httpd_instance.shutdown() # Sinaliza para o serve_forever parar
            self.httpd_instance.server_close() # Fecha o socket do servidor
            print("INFO: Aguardando thread do servidor finalizar...")
            if self.server_thread and self.server_thread.is_alive():
                 self.server_thread.join(timeout=5) # Espera a thread terminar
            if self.server_thread and not self.server_thread.is_alive():
                 print("INFO: Thread do servidor finalizada.")
            else:
                 print("AVISO: Timeout ao esperar thread do servidor, ou thread não encontrada.")

            self.httpd_instance = None
            httpd = None
            self.server_thread = None
            print("INFO: MediaServer parado.")
        else:
            print("INFO: MediaServer não estava em execução (instância httpd não encontrada).")
            # Tenta forçar o fechamento se outro processo estiver usando a porta (via /stop endpoint)
            try:
                requests.get(f'http://{HOST_NAME}:{PORT_NUMBER}/stop', timeout=0.5)
            except:
                pass


def prepare_url(url_to_proxy, custom_headers_dict=None):
    """
    Prepara a URL para ser usada com o servidor proxy local.
    Adiciona cabeçalhos customizados à URL de forma codificada.
    """
    try:
        # Decodifica a URL base primeiro, caso já venha codificada
        url_to_proxy = unquote_plus(url_to_proxy)
        url_to_proxy = unquote(url_to_proxy)
    except Exception as e:
        print(f"AVISO: Erro ao decodificar URL de entrada '{url_to_proxy}': {e}")
        pass # Prossegue com a URL como está

    # Adiciona cabeçalhos customizados como parâmetros, usando '|' como delimitador principal
    # Isso é um legado do código original, pode ser simplificado para usar apenas query string
    header_params = []
    if custom_headers_dict:
        for key, value in custom_headers_dict.items():
            header_params.append(f"{quote_plus(key)}={quote_plus(value)}")
    
    if header_params:
        # Usa '&h123=true' como um marcador para separar a URL original dos parâmetros de cabeçalho,
        # ou simplesmente anexa como query string se for mais limpo.
        # A lógica original usava '|' e '&h123=true&'. Vamos simplificar.
        # A URL final para o proxy será: http://HOST:PORT/?url=URL_ORIGINAL&Header1=Value1&Header2=Value2...
        # A função get_headers_from_url_params precisa ser capaz de extrair isso.
        
        # Limpa a URL original de query strings existentes para evitar conflitos
        parsed_original = urlparse(url_to_proxy)
        url_base_original = parsed_original._replace(query='', fragment='').geturl()
        
        # Adiciona os parâmetros de cabeçalho à URL base
        # Não precisamos mais de '|' ou '&h123'. Os cabeçalhos serão parâmetros na URL do proxy.
        # O parâmetro 'url' conterá a URL real a ser buscada.
        # Os cabeçalhos customizados serão parâmetros adicionais na mesma query string.
        # Ex: /?url=http://example.com/stream&Referer=http://my.site
        
        # A URL que o proxy recebe é: http://127.0.0.1:PORT/?url=<URL_CODIFICADA_DO_STREAM_EXTERNO_COM_SEUS_PARAMETROS_DE_HEADER>
        # Onde <URL_CODIFICADA_DO_STREAM_EXTERNO_COM_SEUS_PARAMETROS_DE_HEADER> é a URL original + &Chave=Valor
        
        if parsed_original.query: # Se a URL original já tem query params
            effective_url_to_proxy = f"{url_base_original}?{parsed_original.query}"
        else:
            effective_url_to_proxy = url_base_original

        if header_params:
            # Adiciona os parâmetros de cabeçalho à URL que será o valor do parâmetro 'url'
            # Isso mantém a compatibilidade com a extração de headers em get_headers_from_url_params
            # que espera os headers dentro da string da URL.
            separator = '&' if '?' in effective_url_to_proxy else '?'
            effective_url_to_proxy += separator + '&'.join(header_params)

    else:
        effective_url_to_proxy = url_to_proxy

    # Codifica a URL final (que pode incluir os cabeçalhos) para ser o valor do parâmetro 'url'
    encoded_target_url = quote_plus(effective_url_to_proxy)
    
    final_proxy_url = f'http://{HOST_NAME}:{PORT_NUMBER}/?url={encoded_target_url}'
    return final_proxy_url


# Exemplo de uso:
if __name__ == '__main__':
    # Cria e inicia o servidor
    media_server = MediaServer()
    media_server.start()

    # Simula a solicitação de um canal
    # Use uma URL M3U8 de teste válida aqui
    # test_m3u8_url = "URL_DO_SEU_STREAM_M3U8_AQUI"
    # test_m3u8_url_com_referer = "URL_DO_SEU_STREAM_M3U8_AQUI|Referer=http://www.sitedoreferer.com"
    
    # Exemplo com um M3U8 público de teste (Big Buck Bunny)
    # test_m3u8_url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    # proxied_url = prepare_url(test_m3u8_url)
    # print(f"URL do Proxy para o cliente (ex: VLC, Kodi): {proxied_url}")

    # print("\nPara testar outro canal (simulando 'clicar em outro canal'):")
    # print("O servidor deve resetar o estado para o novo M3U8.")
    # test_m3u8_url_2 = "https://moctobpltc-i.akamaihd.net/hls/live/571329/
    #                  ल्यूडामिलापुतिना/master.m3u8" # Outro M3U8 de teste
    # proxied_url_2 = prepare_url(test_m3u8_url_2, custom_headers_dict={"Referer": "http://test.com"})
    # print(f"Nova URL do Proxy: {proxied_url_2}")
    # print("Faça uma requisição para esta nova URL. O servidor deve tratar como um novo stream.")

    print(f"\nServidor rodando. Acesse http://{HOST_NAME}:{PORT_NUMBER}/check para verificar.")
    print(f"Para parar o servidor, acesse http://{HOST_NAME}:{PORT_NUMBER}/stop ou pressione Ctrl+C.")

    # Mantém o script principal rodando enquanto o servidor estiver ativo
    try:
        while media_server.is_in_use() and media_server.server_thread and media_server.server_thread.is_alive() :
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nINFO: Interrupção de teclado no script principal. Parando o servidor...")
    finally:
        media_server.stop()
        print("INFO: Script principal finalizado.")