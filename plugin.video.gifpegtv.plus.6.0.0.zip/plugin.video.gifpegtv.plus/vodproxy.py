import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver

# importa o requests real com alias para usar adapters/exceptions internamente
import requests as _requests
from requests.adapters import HTTPAdapter
from requests.exceptions import RequestException, ConnectionError, HTTPError, Timeout
from urllib3.util.retry import Retry
from urllib3.exceptions import IncompleteRead

# importa o wrapper DoH (script.module.netunblock) — substitui o requests padrão do script
# conforme README/doh_client.py: from doh_client import requests
from doh_client import requests

import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------

MAX_SEGMENT_RETRIES = 1
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 15
STREAM_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 1024 * 32
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
LOG_FILE = "vod_proxy.log"
MAX_RECONNECTION_ATTEMPTS = 1
CLIENT_CHECK_TIMEOUT = 1.0
BUFFER_SIZE = 512 * 1024
THROTTLE_RATE_KBPS = 0

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILS ----------------

def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s',
                            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')])
    except Exception as e:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
        logging.error(f"Erro ao configurar o logging para o arquivo: {e}")

# ---------------- PROXY LOGIC ----------------

class VODProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    # usamos o requests do doh_client (script.module.netunblock)
    # nele, doh_client.requests.session é um requests.Session() real
    session = requests.session  # session já é um objeto Session criado no doh_client
    retry_strategy = Retry(
        total=MAX_SEGMENT_RETRIES,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=[429, 500, 502, 503, 504]
    )
    # montamos adapters no Session real (session é um requests.Session)
    try:
        session.mount('http://', HTTPAdapter(max_retries=retry_strategy))
        session.mount('https://', HTTPAdapter(max_retries=retry_strategy))
    except Exception:
        # em alguns ambientes a montagem pode falhar — falhamos silenciosamente
        pass

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    def do_HEAD(self):
        try:
            if '?url=' not in self.path: self.send_error(404); return
            url = urllib.parse.unquote_plus(self.path.split('?url=')[1])
            headers = {'User-Agent': USER_AGENT}
            if 'Range' in self.headers: headers['Range'] = self.headers['Range']
            r = self.session.head(url, headers=headers, stream=True, timeout=CONNECTION_TIMEOUT, allow_redirects=True, verify=False)
            self.send_response(r.status_code)
            for header, value in r.headers.items(): self.send_header(header, value)
            self.end_headers()
        except Exception as e:
            logging.error(f"Erro no HEAD para {self.path}: {e}")
            self.send_error(502)

    def do_GET(self):
        try:
            if '?url=' not in self.path: self.send_error(404); return
            params = urllib.parse.parse_qs(self.path.split('?')[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            if not url: self.send_error(400); return
            headers = {'User-Agent': USER_AGENT}
            range_header = self.headers.get('Range', None)
            if range_header: headers['Range'] = range_header
            self._handle_progressive_stream(url, headers)
        except (IndexError, ValueError) as e:
            logging.error(f"Erro de parâmetro: {e}")
            self.send_error(400)
        except Exception as e:
            logging.error(f"Erro inesperado no GET para {self.path}: {e}")
            self.send_error(500)

    def _handle_progressive_stream(self, url, headers):
        retries = 0; start_byte = 0
        if 'range' in headers:
            start_byte_str = headers['range'].split('=')[-1].split('-')[0]
            if start_byte_str: start_byte = int(start_byte_str)
        buffer = bytearray(); buffer_size = 0
        while retries < MAX_RECONNECTION_ATTEMPTS:
            try:
                if not self.check_client_connection(): logging.warning("Cliente desconectado"); return
                if start_byte > 0: headers['Range'] = f"bytes={start_byte}-"
                with self.session.get(url, headers=headers, stream=True, timeout=STREAM_TIMEOUT, verify=False) as r:
                    r.raise_for_status()
                    if start_byte > 0 and r.status_code == 200:
                        self.send_response(206)
                        content_range = r.headers.get('Content-Range')
                        if content_range: self.send_header('Content-Range', content_range)
                        else:
                            total_size = r.headers.get('Content-Length')
                            self.send_header('Content-Range', f"bytes {start_byte}-{start_byte + len(r.content) - 1}/{total_size or '*'}")
                    else: self.send_response(r.status_code)
                    for header, value in r.headers.items():
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                            self.send_header(header, value)
                    self.end_headers()
                    last_client_check = time.time()
                    try:
                        for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                            current_time = time.time()
                            if current_time - last_client_check > CLIENT_CHECK_TIMEOUT:
                                if not self.check_client_connection(): logging.warning("Cliente desconectado"); return
                                last_client_check = current_time
                            if not chunk: continue
                            buffer.extend(chunk); buffer_size += len(chunk)
                            if buffer_size >= BUFFER_SIZE:
                                self.wfile.write(buffer); buffer.clear(); buffer_size = 0; start_byte += len(chunk)
                    except (ConnectionError, BrokenPipeError, OSError) as write_error:
                        logging.warning(f"Conexão do cliente quebrada. Tentando reconectar. {write_error}"); raise write_error
                    if buffer_size > 0: self.wfile.write(buffer); buffer.clear(); buffer_size = 0
                    logging.info(f"Stream VOD para {url} transmitido com sucesso."); return
            except (RequestException, ConnectionError, OSError, IncompleteRead) as e:
                logging.warning(f"Erro ao transmitir arquivo progressivo para {url}: {e}. Tentativa {retries+1}/{MAX_RECONNECTION_ATTEMPTS}")
                retries += 1; wait_time = min(2 ** retries, 5); time.sleep(wait_time); continue
        logging.error(f"Falha ao transmitir o stream após {MAX_RECONNECTION_ATTEMPTS} tentativas."); self.send_error(502)

    def check_client_connection(self):
        try: self.wfile.flush(); return True
        except: return False

class VODProxyManager:
    def __init__(self):
        self.server = None; self.server_thread = None; self.active_port = None; self._is_running = False
    def is_running(self): return self._is_running
    def start(self):
        if self.is_running(): return True
        self.stop()
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), VODProxyRequestHandler)
                self.server.daemon_threads = True
                self.server_thread = threading.Thread(target=self.server.serve_forever); self.server_thread.daemon = True
                self.server_thread.start(); self.active_port = port; self._is_running = True
                logging.info(f"Proxy VOD iniciado em {self.active_port}"); return True
            except OSError: continue
        return False
    def stop(self):
        if self.server:
            try: self.server.shutdown(); self.server.server_close()
            except: pass
        if self.server_thread:
            try: self.server_thread.join(1)
            except: pass
        self.server = None; self.server_thread = None; self._is_running = False

class VODAddon:
    def __init__(self, handle): self.handle = handle; self.proxy = VODProxyManager()
    def play_stream(self, url, stype, title=None):
        if not self.proxy.start(): return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        li = xbmcgui.ListItem(path=proxy_url, label=title or "Proxy VOD")
        li.setProperty("IsPlayable", "true")
        if url.lower().endswith(('.mp4', '.mkv', '.avi')): li.setMimeType("video/mp4")
        xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    try:
        h = int(sys.argv[1]); addon = VODAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]
        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]; stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]; addon.play_stream(stream_url, stream_type, title)
        else: xbmcplugin.endOfDirectory(h)
    except Exception as e: logging.error(f"Erro no main do VOD Proxy: {e}")

if __name__ == '__main__':
    main()