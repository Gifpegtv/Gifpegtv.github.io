import sys  
import threading  
import random  
import logging  
import urllib.parse  
import time  
import warnings  
import os  
import http.server  
import socketserver  
  
# Importa a biblioteca requests original e seus componentes necessários  
import requests  
from requests.adapters import HTTPAdapter  
from urllib3.util.retry import Retry  
  
# Importa o wrapper do requests do netunblock com um apelido para evitar conflito  
from doh_client import requests as doh_requests  
  
import xbmc  
import xbmcgui  
import xbmcplugin  
  
# ---------------- CONFIG ----------------  
MAX_SEGMENT_RETRIES = 15  # Aumentado para maior resiliência  
RETRY_BACKOFF_FACTOR = 0.1  # Reduzido para reconexões mais rápidas  
CONNECTION_TIMEOUT = 10   # Reduzido para respostas mais rápidas  
STREAM_TIMEOUT = 20.0     # Reduzido para respostas mais rápidas  
DEFAULT_CHUNK_SIZE = 1024 * 64  # Aumentado para streaming mais fluido  
PROXY_HOST = '127.0.0.1'  
MAX_PORT_ATTEMPTS = 20  
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"  
LOG_FILE = "hls_proxy.log"  
SESSION_TIMEOUT = 30.0    # Valor inicial; será ajustado dinamicamente baseado no manifesto  
MANIFEST_RETRY_DELAY = 0.1  # Reduzido para reconexões mais rápidas  
LIVE_STREAM_DURATION = 3600  
MAX_CONSECUTIVE_SEGMENT_ERRORS = 5  # Aumentado para tolerar mais falhas transitórias  
  
warnings.filterwarnings("ignore", message="Unverified HTTPS request")  
  
  
# ---------------- UTILS ----------------  
def setup_logging():  
    try:  
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)  
        logging.basicConfig(  
            level=logging.INFO,  
            format='%(asctime)s %(message)s',  
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]  
        )  
    except Exception:  
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')  
  
  
def get_forward_headers(client_headers):  
    """Encaminha alguns headers importantes para autenticação/token do servidor."""  
    headers = {  
        'User-Agent': USER_AGENT,  
        'Connection': 'keep-alive',  # Adicionado para manter conexões persistentes e reconexões mais rápidas  
    }  
    if 'Authorization' in client_headers:  
        headers['Authorization'] = client_headers['Authorization']  
    if 'Cookie' in client_headers:  
        headers['Cookie'] = client_headers['Cookie']  
    # Encaminha outros cabeçalhos relevantes conforme necessário  
    return headers  
  
  
# ---------------- HANDLER ----------------  
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):  
    # Utiliza a sessão do doh_client (agora doh_requests) para garantir o uso de DoH  
    session = doh_requests.session  
    retry_strategy = Retry(  
        total=MAX_SEGMENT_RETRIES,  
        backoff_factor=RETRY_BACKOFF_FACTOR,  
        status_forcelist=[429, 500, 502, 503, 504, 403]  
    )  
    # Aplica a estratégia de retry do proxy à sessão do doh_client  
    adapter = HTTPAdapter(max_retries=retry_strategy)  
    session.mount('http://', adapter)  
    session.mount('https://', adapter)  
    error_counter = {}  
    last_session_time = time.time()  
    manifest_duration = 30.0  # Valor inicial para duração do manifesto (em segundos)  
  
    def log_message(self, format, *args):  
        # Reduz ruído no log, loga tudo como INFO  
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")  
  
    def do_HEAD(self):  
        # Suporte para HEAD (evita erro 501 e melhora compatibilidade com players/Kodi)  
        self.do_GET(head_only=True)  
  
    def do_GET(self, head_only=False):  
        try:  
            # Reconexão proativa: refresca a sessão periodicamente antes de falhas, agora baseado na duração dinâmica do manifesto  
            current_timeout = self.manifest_duration * 0.8  # 80% da duração do manifesto para reconectar antes de expirar  
            current_timeout = max(10.0, min(current_timeout, 60.0))  # Limites para evitar sobrecarga ou delays longos  
            if time.time() - HLSProxyRequestHandler.last_session_time > current_timeout:  
                logging.info(f"Refrescando sessão proativamente (timeout dinâmico: {current_timeout:.2f}s) para maior estabilidade.")  
                HLSProxyRequestHandler.session = doh_requests.session  
                HLSProxyRequestHandler.adapter = HTTPAdapter(max_retries=HLSProxyRequestHandler.retry_strategy)  
                HLSProxyRequestHandler.session.mount('http://', HLSProxyRequestHandler.adapter)  
                HLSProxyRequestHandler.session.mount('https://', HLSProxyRequestHandler.adapter)  
                HLSProxyRequestHandler.last_session_time = time.time()  
  
            if '?url=' not in self.path:  
                self.send_error(404)  
                return  
  
            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])  
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])  
            session_id = params.get('session_id', [self.client_address[0]])[0]  
  
            if not url:  
                self.send_error(400)  
                return  
  
            # Forward headers importantes do client  
            headers = get_forward_headers(self.headers)  
  
            parsed_url = urllib.parse.urlparse(url)  
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):  
                self._handle_manifest(url, headers, head_only)  
            else:  
                self._handle_segment(url, session_id, headers, head_only)  
  
        except Exception as e:  
            logging.error(f"Erro inesperado GET: {e}")  
            try:  
                self.send_error(500)  
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):  
                logging.warning("Cliente fechou conexão durante envio de erro 500.")  
                return  
  
    def _handle_manifest(self, url, headers, head_only):  
        """Serve o manifest com rewrites para apontar para o proxy. Agora detecta duração dinamicamente."""  
        try:  
            # Tenta por algumas vezes caso caia 403 ou 5xx  
            for attempt in range(MAX_SEGMENT_RETRIES):  
                try:  
                    r = self.session.get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)  
                    r.raise_for_status()  
                    break  
                except requests.exceptions.HTTPError as e:  
                    logging.warning(f"Erro ao baixar manifesto: {e}")  
                    if r.status_code == 403 and attempt < MAX_SEGMENT_RETRIES - 1:  
                        time.sleep(MANIFEST_RETRY_DELAY)  
                        continue  
                    raise  
            else:  
                raise Exception("Falha ao obter o manifesto após várias tentativas.")  
  
            manifest_content = r.text  
            base_url = r.url  
  
            # Novo: Detecta duração do manifesto dinamicamente  
            total_duration = 0.0  
            target_duration = 0.0  
            for line in manifest_content.splitlines():  
                if line.startswith('#EXTINF:'):  
                    try:  
                        duration = float(line.split('#EXTINF:')[1].split(',')[0])  
                        total_duration += duration  
                    except (IndexError, ValueError):  
                        pass  
                elif line.startswith('#EXT-X-TARGETDURATION:'):  
                    try:  
                        target_duration = float(line.split('#EXT-X-TARGETDURATION:')[1])  
                    except (IndexError, ValueError):  
                        pass  
            # Usa soma de EXTINF se disponível; senão, TARGETDURATION * número estimado de segmentos (use rarely as most posts are not geo-tagged).  
            if total_duration == 0.0:  
                segment_count = len([line for line in manifest_content.splitlines() if not line.startswith('#') and line.strip()])  
                total_duration = target_duration * max(segment_count, 5)  # Fallback conservador  
            self.manifest_duration = max(total_duration, 30.0)  # Mínimo de 30s para evitar refreshes excessivos  
            logging.info(f"Duração do manifesto detectada: {self.manifest_duration:.2f}s. Ajustando timeout proativo.")  
  
            self.send_response(200)  
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')  
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')  
            self.send_header('Pragma', 'no-cache')  
            self.send_header('Expires', '0')  
            self.end_headers()  
  
            if head_only:  
                return  
  
            new_manifest_lines = []  
            for line in manifest_content.splitlines():  
                stripped = line.strip()  
                if not stripped or stripped.startswith('#'):  
                    new_manifest_lines.append(line)  
                else:  
                    # Corrige path relativo e reescreve para proxy  
                    full_segment_url = urllib.parse.urljoin(base_url, stripped)  
                    proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}"  
                    new_manifest_lines.append(proxy_segment_url)  
  
            try:  
                self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))  
                self.wfile.flush()  
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):  
                logging.warning("Cliente fechou conexão durante envio do manifesto.")  
                return  
  
        except Exception as e:  
            logging.error(f"Erro ao manipular manifesto: {e}")  
            try:  
                self.send_error(502)  
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):  
                logging.warning("Cliente fechou conexão durante envio de erro 502.")  
                return  
  
    def _handle_segment(self, url, session_id, headers, head_only):  
        """Serve o segmento de mídia individual."""  
        retries = 0  
        consecutive_errors = self.error_counter.get(session_id, 0)  
        while retries < MAX_SEGMENT_RETRIES:  
            try:  
                with self.session.get(url, headers=headers, stream=True,  
                                      timeout=STREAM_TIMEOUT, verify=False) as r:  
                    # Lida com 404 e limita erros consecutivos  
                    if r.status_code == 404:  
                        consecutive_errors += 1  
                        self.error_counter[session_id] = consecutive_errors  
                        logging.warning(f"Segmento 404: {url}, consecutivos {consecutive_errors}")  
                        if consecutive_errors >= MAX_CONSECUTIVE_SEGMENT_ERRORS:  
                            logging.error("Muitos 404 consecutivos, pulando segmento")  
                            self.send_error(404)  
                            return  
                        retries += 1  
                        time.sleep(MANIFEST_RETRY_DELAY)  
                        continue  
  
                    r.raise_for_status()  
                    self.send_response(r.status_code)  
                    # Copia cabeçalhos relevantes  
                    for header, value in r.headers.items():  
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:  
                            self.send_header(header, value)  
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')  
                    self.send_header('Pragma', 'no-cache')  
                    self.send_header('Expires', '0')  
                    self.end_headers()  
  
                    if head_only:  
                        return  
  
                    for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):  
                        if not chunk:  
                            continue  
                        try:  
                            self.wfile.write(chunk)  
                            self.wfile.flush()  
                        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):  
                            logging.warning("Cliente fechou conexão (Broken pipe). Encerrando envio.")  
                            return  
                        except Exception as e:  
                            logging.error(f"Erro ao escrever chunk: {e}")  
                            return  
  
                    self.error_counter[session_id] = 0  
                    return  
            except requests.exceptions.RequestException as e:  
                retries += 1  
                logging.warning(f"Erro req segmento {url}: {e}, retry {retries}")  
                time.sleep(min(2 ** retries * 0.2, 2))  # Backoff reduzido para reconexões mais rápidas  
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):  
                logging.warning("Cliente desconectado antes do fim.")  
                return  
            except Exception as e:  
                logging.error(f"Erro geral segmento {url}: {e}")  
                return  
  
        logging.error("Segmento falhou várias vezes, pulando...")  
        try:  
            self.send_error(502)  
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):  
            logging.warning("Cliente fechou conexão durante envio de erro 502.")  
            return  
  
    def do_OPTIONS(self):  
        # Responde a OPTIONS para compatibilidade CORS e players  
        self.send_response(200)  
        self.send_header('Access-Control-Allow-Origin', '*')  
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')  
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')  
        self.end_headers()  
  
  
# ---------------- MANAGER ----------------  
class HLSProxyManager:  
    def __init__(self):  
        self.server = None  
        self.thread = None  
        self.active_port = None  
  
    def start(self):  
        for _ in range(MAX_PORT_ATTEMPTS):  
            try:  
                port = random.randint(30000, 60000)  
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyRequestHandler)  
                self.server.daemon_threads = True  
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)  
                self.thread.start()  
                self.active_port = port  
                logging.info(f"Proxy iniciado na porta {self.active_port}")  
                return True  
            except OSError:  
                continue  
        logging.error("Não foi possível iniciar o proxy em nenhuma porta.")  
        return False  
  
  
class HLSAddon:  
    def __init__(self, handle):  
        self.handle = handle  
        self.proxy = HLSProxyManager()  
  
    def play_stream(self, url, stype, title=None):  
        if not self.proxy.start():  
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())  
  
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"  
        li = xbmcgui.ListItem(path=proxy_url, label=title or "Proxy HLS")  
        li.setProperty("IsPlayable", "true")  
        if stype == "live":  
            li.setMimeType("application/vnd.apple.mpegurl")  
            li.setProperty("IsLive", "true")  
        xbmcplugin.setResolvedUrl(self.handle, True, li)  
  
  
def main():  
    setup_logging()  
    try:  
        h = int(sys.argv[1])  
        addon = HLSAddon(h)  
        args = urllib.parse.parse_qs(sys.argv[2][1:])  
        action = args.get('action', [None])[0]  
  
        if action == 'play_stream':  
            stream_url = args.get('stream_url', [None])[0]  
            stream_type = args.get('stream_type', [None])[0]  
            title = args.get('title', [None])[0]  
            addon.play_stream(stream_url, stream_type, title)  
        else:  
            xbmcplugin.endOfDirectory(h)  
    except Exception as e:  
        logging.error(f"Erro main: {e}")  
  
  
if __name__ == '__main__':  
    main()